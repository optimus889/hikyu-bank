const fs = require("fs"),
  path = require("path");
const e = (x) =>
  String(x ?? "").replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
  );
function time(value) {
  if (value === null || value === undefined || value === "")
    return "<span>Not available</span>";
  const d = new Date(value);
  return Number.isFinite(d.getTime())
    ? /* HTML */ `
        <time datetime="${e(d.toISOString())}">
          ${e(d.toISOString().replace("T", " ").replace(".000Z", " UTC"))}
        </time>
      `
    : "<span>Not available</span>";
}
function form(name, req, command, id, fields, label) {
  const fid = `v8-${command}-${id}`;
  return /* HTML */ `
    <form id="${e(fid)}" method="post" action="/view/${e(name)}" data-v8-action="${e(command)}">
      <input type="hidden" name="_csrf" value="${e(req.csrfToken())}" />
      <input type="hidden" name="command" value="${e(command)}" />
      ${fields}
      <div
        id="${e(fid)}-feedback"
        class="v8-form-feedback"
        data-form-feedback
        role="status"
        aria-live="polite"
        tabindex="-1"
      ></div>
      <button class="btn btn-primary v8-submit" type="submit">${e(label)}</button>
    </form>
  `;
}
const hidden = (name, value) => /* HTML */ `
  <input type="hidden" name="${e(name)}" value="${e(value)}" />
`;
function shell(mode, inner) {
  return `
    <section class="hikyu-v8" data-v8-root="${e(mode)}">
      <nav class="v8-nav" aria-label="Support navigation">
        <a href="/page/support-inbox">Support Inbox</a>
        <a href="/page/support-requests">Transaction Support Review</a>
        <a href="/page/case-synchronization">Outcome Synchronization</a>
      </nav>
      <div
        class="v8-page-feedback"
        data-page-feedback
        role="status"
        aria-live="polite"
        tabindex="-1"
      ></div>
      ${inner}
    </section>
    <style>
      ${fs.readFileSync(path.join(__dirname, "styles.css"), "utf8")}
    </style>
    <script>
      ${fs.readFileSync(path.join(__dirname, "controller.js"), "utf8")}
    </script>
  `;
}
module.exports = { e, time, form, hidden, shell };
