const V8_ROOT = process.env.V6_ROOT;
if (!V8_ROOT)
  throw new Error("Start the application through its generated runtime configuration.");
const { db } = require(require("path").join(V8_ROOT, "backend/saltcorn/sdk.cjs")),
  bank = require(require("path").join(V8_ROOT, "backend/saltcorn/banking.cjs")),
  crypto = require("crypto");
const transactionsPage = require(require("path").join(V8_ROOT, "backend/v9/transactions.cjs"));
const e = (x) =>
  String(x ?? "").replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
  );
const dollars = (n) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(
    Number(n || 0) / 100,
  );
const input = (n, l, type = "text", value = "", required = false) => /* HTML */ `
  <label class="d-block my-2">
    ${e(l)}
    <input
      name="${e(n)}"
      type="${type}"
      value="${e(value)}"
      ${required ? "required" : ""}
      class="form-control"
    />
  </label>
`;
const options = (n, l, rows) => /* HTML */ `
  <label class="d-block my-2">
    ${e(l)}
    <select name="${n}" class="form-control">
      ${rows
        .map(
          ([v, l]) => /* HTML */ `
            <option value="${e(v)}">${e(l)}</option>
          `,
        )
        .join("")}
    </select>
  </label>
`;
const form = (name, req, command, body, button) => /* HTML */ `
  <form method="post" action="/view/${name}" class="v6-panel">
    <input type="hidden" name="_csrf" value="${e(req.csrfToken())}" />
    <input type="hidden" name="command" value="${command}" />
    ${body}
    <button type="submit" class="btn btn-primary">${button}</button>
  </form>
`;
async function finance(name, req, kind) {
  const accounts = (
    await db.query("SELECT * FROM accounts WHERE owner_id=$1 AND status='active' ORDER BY id", [
      req.user.id,
    ])
  ).rows;
  const deposits = accounts.filter((a) => ["checking", "savings"].includes(a.account_type)),
    cards = accounts.filter((a) => ["checking", "credit"].includes(a.account_type));
  const choices = (a) => a.map((x) => [x.id, x.name + " · " + dollars(x.balance_cents)]);
  let fields =
    /* HTML */ `<input type="hidden" name="kind" value="${kind}"><input type="hidden" name="request_key" value="v6-${crypto.randomUUID()}">` +
    options("source", "From account", choices(kind === "purchase" ? cards : deposits));
  if (["transfer", "repayment"].includes(kind))
    fields += options(
      "target",
      "To account",
      choices(
        kind === "repayment" ? accounts.filter((a) => a.account_type === "credit") : deposits,
      ),
    );
  if (kind === "peer") fields += input("recipient", "Recipient username", "text", "", true);
  if (kind === "bill") {
    const payees = (
      await db.query(
        "SELECT * FROM saved_payees WHERE owner_id=$1 AND kind='biller' AND deleted=false",
        [req.user.id],
      )
    ).rows;
    fields += options(
      "payee",
      "Saved demo biller",
      payees.map((p) => [p.id, p.alias + " · " + p.reference]),
    );
  }
  if (kind === "purchase")
    fields +=
      input("merchant", "Merchant", "text", "", true) +
      options(
        "category",
        "Category",
        bank.CATEGORIES.map((x) => [x, x]),
      );
  fields +=
    input("amount", "Amount (USD)", "text", "", true) +
    input("note", "Note") +
    options("method", "Verification method", [
      ["sms", "SMS"],
      ["email", "Email"],
    ]);
  if (kind !== "transfer") fields += input("pin", "Permanent card PIN", "password", "", true);
  return form(name, req, "issue", fields, "Review and request verification code");
}
async function renderTransactions(req) {
  const rows = (
    await db.query(
      "SELECT * FROM transactions WHERE owner_id=$1 ORDER BY posted_date DESC,id DESC LIMIT 100",
      [req.user.id],
    )
  ).rows;
  return /* HTML */ `
    <table class="table">
      <thead>
        <tr>
          <th>Transaction</th>
          <th>Category</th>
          <th>Date</th>
          <th>Amount</th>
        </tr>
      </thead>
      <tbody>
        ${rows
          .map(
            (r) => /* HTML */ `
              <tr>
                <td>${e(r.name)}</td>
                <td>${e(r.category)}</td>
                <td>${e(new Date(r.posted_date).toISOString().slice(0, 10))}</td>
                <td>${dollars(r.amount_cents)}</td>
              </tr>
            `,
          )
          .join("")}
      </tbody>
    </table>
  `;
}
module.exports = {
  name: "Hikyu Banking",
  tableless: false,
  display_state_form: false,
  get_state_fields: async () =>
    ["kind", "search", "from", "to", "account", "category", "sort", "page"].map((name) => ({
      name,
      type: "String",
      required: false,
      attributes: {},
    })),
  configuration_workflow: () => null,
  run: async (t, name, c, state, { req }) => {
    if (!req.user?.id) return "<p>Please sign in.</p>";
    const accounts = (
      await db.query("SELECT * FROM accounts WHERE owner_id=$1 ORDER BY id", [req.user.id])
    ).rows;
    const opts = accounts.map((a) => [a.id, a.name]);
    let out = "";
    const mode = c.mode;
    if (["overview", "accounts"].includes(mode)) {
      out += /* HTML */ `
        <h1 class="v6-title">
          ${mode === "overview" ? "Your money, in focus" : "Accounts & Cards"}
        </h1>
        <p>Your accounts. One clear view.</p>
        <section style="display:flex;gap:22px;flex-wrap:wrap">
          ${accounts
            .map(
              (a) => /* HTML */ `
                <article class="v6-panel" style="min-width:265px">
                  <strong>${e(a.name)}</strong>
                  <p>•••• ${e(a.suffix)}</p>
                  <h2>${dollars(a.balance_cents)}</h2>
                  <p>${e(a.status)}</p>
                  <a href="/page/transactions?account=${a.id}">View account transactions</a>
                </article>
              `,
            )
            .join("")}
        </section>
      `;
      if (mode === "accounts") {
        const cards = (
          await db.query(
            "SELECT c.*,a.name FROM card_controls c JOIN accounts a ON a.id=c.account_id WHERE c.owner_id=$1",
            [req.user.id],
          )
        ).rows;
        for (const card of cards)
          out += form(
            name,
            req,
            "card",
            /* HTML */ `
              <h3>${e(card.name)}</h3>
              <p>Card status: ${card.locked ? "Locked" : "Unlocked"}</p>
              <input type="hidden" name="account_id" value="${card.account_id}" />
              <input type="hidden" name="locked" value="${!card.locked}" />
            `,
            card.locked ? "Unlock card" : "Lock card",
          );
        out += "<h2>Credit repayment</h2>" + (await finance(name, req, "repayment"));
      } else out += "<h2>Recent transactions</h2>" + (await renderTransactions(req));
    }
    if (mode === "transactions")
      out +=
        transactionsPage.render() +
        form(
          name,
          req,
          "statement",
          input("from", "From date", "date", "", true) +
            input("to", "To date", "date", "", true),
          "Export a CSV statement",
        );
    if (mode === "pay") {
      out +=
        '<h1 class="v6-title">Pay & Transfer</h1><nav><a href="?kind=transfer">Between my accounts</a> · <a href="?kind=peer">To another person</a> · <a href="?kind=bill">Bill Pay</a></nav>';
      const kind = ["transfer", "peer", "bill"].includes(state.kind) ? state.kind : "transfer";
      out += await finance(name, req, kind);
      const payees = (
        await db.query("SELECT * FROM saved_payees WHERE owner_id=$1 AND deleted=false", [
          req.user.id,
        ])
      ).rows;
      out +=
        "<h2>Saved recipients</h2>" +
        payees
          .map(
            (p) => /* HTML */ `
              <p>${e(p.alias)} · ${e(p.kind)} · ${e(p.identifier)}</p>
            `,
          )
          .join("");
      out += form(
        name,
        req,
        "payee",
        options("kind", "Recipient type", [
          ["peer", "Hikyu user"],
          ["biller", "Demo biller"],
        ]) +
          input("identifier", "Username or biller code") +
          input("alias", "Nickname") +
          input("reference", "Bill reference"),
        "Save recipient",
      );
      out +=
        "<p>Demo biller codes: electric, internet, water, rent. No external payment occurs.</p>";
    }
    if (mode === "purchase")
      out +=
        '<h1 class="v6-title">Demo Tools</h1><h2>Simulate purchase</h2><p>No real money is moved.</p>' +
        (await finance(name, req, "purchase"));
    if (mode === "insights") {
      const month = new Date().toISOString().slice(0, 7);
      const budgets = (
        await db.query(
          "SELECT b.*,COALESCE((SELECT -sum(x.amount_cents) FROM transactions x WHERE x.owner_id=b.owner_id AND x.category=b.category AND x.kind IN ('expense','peer_transfer') AND x.amount_cents<0 AND x.posted_date>=b.month AND x.posted_date<b.month+interval '1 month'),0) spent FROM budgets b WHERE b.owner_id=$1 ORDER BY month DESC",
          [req.user.id],
        )
      ).rows;
      out +=
        '<h1 class="v6-title">Financial Insights</h1><h2>Budgets</h2>' +
        budgets
          .map(
            (b) => /* HTML */ `
              <article class="v6-panel">
                <strong>${e(b.category)}</strong>
                <p>
                  Limit: ${dollars(b.limit_cents)} · Spent: ${dollars(b.spent)} · Remaining:
                  ${dollars(b.limit_cents - b.spent)}${b.spent > b.limit_cents
                    ? " · Over budget"
                    : ""}
                </p>
              </article>
            `,
          )
          .join("") +
        form(
          name,
          req,
          "budget",
          input("month", "Month", "month", month, true) +
            options(
              "category",
              "Category",
              [...bank.CATEGORIES, "Peer transfer"].map((c) => [c, c]),
            ) +
            input("limit", "Monthly limit (USD)"),
          "Save budget",
        ) +
        '<h2>AI-assisted support</h2><p>The local classifier categorizes transaction-support requests during workflow execution. It does not make financial decisions.</p><a href="/page/support-requests">Open transaction support</a>';
    }
    if (mode === "settings")
      out +=
        '<h1 class="v6-title">Settings</h1>' +
        form(
          name,
          req,
          "nickname",
          options("account_id", "Account", opts) + input("name", "New account nickname"),
          "Save nickname",
        );
    const notes = (
      await db.query(
        "SELECT * FROM notifications WHERE owner_id=$1 ORDER BY created_at DESC LIMIT 10",
        [req.user.id],
      )
    ).rows;
    out +=
      '<section class="v6-panel"><h2>Alert inbox</h2>' +
      notes
        .map(
          (n) => /* HTML */ `
            <p>
              <strong>${e(n.title)}</strong>
              · ${e(n.body)}
            </p>
          `,
        )
        .join("") +
      "</section>";
    return out;
  },
  runPost: async (t, name, c, state, b, { req, res }) => {
    try {
      if (!req.user?.id) throw new Error("Please sign in.");
      let result;
      if (b.command === "statement") {
        const csv = await bank.statement(req.user, b);
        res.set("Content-Type", "text/csv; charset=utf-8");
        res.set("Content-Disposition", "attachment; filename=hikyu-statement.csv");
        return res.send(csv);
      }
      if (b.command === "issue") result = await bank.issue(req.user, b, req.sessionID);
      else if (b.command === "execute") result = await bank.execute(req.user, b, req.sessionID);
      else result = await bank.update(req.user, b);
      if (req.get("Accept") === "application/json") return res.json({ ok: true, result });
      if (b.command === "issue") {
        const clean = { ...b };
        delete clean.pin;
        delete clean._csrf;
        clean.command = "execute";
        clean.challenge_id = result.challenge_id;
        const inner =
          Object.entries(clean)
            .filter(([k]) => k !== "command")
            .map(
              ([k, v]) => /* HTML */ `
                <input type="hidden" name="${e(k)}" value="${e(v)}" />
              `,
            )
            .join("") +
          /* HTML */ `
            <h2>Review simulated payment</h2>
            <p>Amount: ${e(b.amount)} USD</p>
            <p>
              Demo verification code:
              <strong>${result.demo_code}</strong>
            </p>
            <p>${e(result.message)}</p>
          ` +
          input("code", "Six-digit verification code", "text", "", true) +
          (b.kind !== "transfer"
            ? input("pin", "Permanent card PIN", "password", "", true)
            : "");
        return res.send(
          "<h1>Confirm payment</h1>" + form(name, req, "execute", inner, "Confirm payment"),
        );
      }
      res.redirect(
        303,
        "/page/" +
          ({
            overview: "overview",
            accounts: "accounts-cards",
            pay: "pay-transfer",
            purchase: "demo-tools",
            insights: "insights",
            settings: "settings",
            transactions: "transactions",
          }[c.mode] || "overview"),
      );
    } catch (e) {
      res
        .status(e.code || 400)
        .json({ error: e.code ? e.message : "Banking operation failed." });
    }
  },
};
