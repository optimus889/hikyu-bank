const { e, time, form, hidden } = require("./common.cjs");
function render({ name, req, actor, staff, requester, targets, transactions, rows }) {
  let html =
    '<h1>Support Inbox</h1><p class="v8-note">External requests are unverified drafts. A source address or external transaction reference does not prove ownership. An assigned requester must sign in and confirm their own transaction.</p>';
  for (const r of rows) {
    const id = `v8-draft-${r.id}`,
      identity = hidden("id", r.id) + hidden("expected_version", r.draft_version);
    html += `
      <article
        class="v8-card v7-draft"
        data-draft-id="${e(r.id)}"
        data-version="${e(r.draft_version)}"
      >
        <h2>${e(r.subject)}</h2>
        <span class="v8-badge">Draft status: ${e(r.draft_status)}</span>
        <dl class="v8-meta">
          <div>
            <dt>Source</dt>
            <dd>${e(r.source_type)}</dd>
          </div>
          <div>
            <dt>Submitted</dt>
            <dd>${time(r.submitted_at)}</dd>
          </div>
          <div>
            <dt>Source event</dt>
            <dd>${e(r.source_event_id)}</dd>
          </div>
          <div>
            <dt>Source collection</dt>
            <dd>${e(r.source_namespace)}</dd>
          </div>
          <div>
            <dt>Case number</dt>
            <dd>${e(r.case_business_id)}</dd>
          </div>
          <div>
            <dt>Draft version</dt>
            <dd>${e(r.draft_version)}</dd>
          </div>
        </dl>
        <h3>Original issue description</h3>
        <p class="v8-description">${e(r.description)}</p>
    `;
    if (staff && ["NEW", "ASSIGNED"].includes(r.draft_status))
      html += form(
        name,
        req,
        "assign",
        r.id,
        identity +
          /* HTML */ `
            <div class="v8-field">
              <label for="${id}-assignee">Assign to requester</label>
              <select id="${id}-assignee" name="assigned_user_id" required>
                ${targets
                  .map(
                    (u) => /* HTML */ `
                      <option
                        value="${e(u.id)}"
                        ${r.assigned_user_id === u.id ? "selected" : ""}
                      >
                        ${e(u.key)}
                      </option>
                    `,
                  )
                  .join("")}
              </select>
            </div>
          `,
        "Assign draft",
      );
    if (requester && r.assigned_user_id === actor.id && r.draft_status === "ASSIGNED")
      html += form(name, req, "claim", r.id, identity, "Claim assigned draft");
    if (
      requester &&
      r.claimed_by === actor.id &&
      ["CLAIMED", "SUBMISSION_FAILED"].includes(r.draft_status)
    ) {
      const frozen = r.draft_status === "SUBMISSION_FAILED",
        tx = frozen
          ? transactions.filter((t) => t.id === r.selected_transaction_id)
          : transactions;
      html += form(
        name,
        req,
        "submit_draft",
        r.id,
        identity +
          /* HTML */ `
            ${frozen
              ? '<p class="v8-warning">A previous submission could not be confirmed. Retry the originally confirmed details; changing them is blocked by the server.</p>'
              : ""}
            <div class="v8-fields">
              <div class="v8-field">
                <label for="${id}-transaction">Your transaction</label>
                <select
                  id="${id}-transaction"
                  name="transaction_id"
                  required
                  aria-describedby="${id}-transaction-help ${id}-transaction-error"
                >
                  <option value="">Choose one of your transactions</option>
                  ${tx
                    .map(
                      (t) => /* HTML */ `
                        <option
                          value="${e(t.id)}"
                          ${r.selected_transaction_id === t.id ? "selected" : ""}
                        >
                          ${e(t.name)}
                        </option>
                      `,
                    )
                    .join("")}
                </select>
                <span id="${id}-transaction-help" class="v8-helper">
                  Only transactions owned by your signed-in account are offered.
                </span>
                <div
                  id="${id}-transaction-error"
                  class="v8-field-error"
                  data-field-error="transaction_id"
                ></div>
              </div>
              <div class="v8-field">
                <label for="${id}-description">Confirmed description</label>
                <textarea
                  id="${id}-description"
                  name="description"
                  required
                  minlength="3"
                  maxlength="2000"
                  ${frozen ? "readonly" : ""}
                  aria-describedby="${id}-description-help ${id}-description-count ${id}-description-error"
                >${e(r.confirmed_description || r.description)}</textarea>
                <span id="${id}-description-help" class="v8-helper">
                  Enter 3–2000 characters after trimming. Use synthetic information only.
                </span>
                <output
                  id="${id}-description-count"
                  class="v8-counter"
                  data-description-counter
                  for="${id}-description"
                >
                  ${String(r.confirmed_description || r.description || "").trim().length} / 2000
                  characters after trimming
                </output>
                <div
                  id="${id}-description-error"
                  class="v8-field-error"
                  data-field-error="description"
                ></div>
              </div>
            </div>
            <p>
              Confirm that this is your own transaction. Submission uses the existing
              Transaction Support Review workflow.
            </p>
          `,
        "Confirm ownership and submit",
      );
    }
    if (r.draft_status === "SUBMITTED")
      html +=
        '<p class="v8-note">Submission recorded. Follow <a href="/page/support-requests">Transaction Support Review</a> for the actual persisted business stage.</p>';
    if (r.error_code)
      html += /* HTML */ `
        <p class="v8-error-summary" role="alert">
          Previous submission error: ${e(r.error_code)}. Your confirmed details are retained.
        </p>
      `;
    html += "</article>";
  }
  if (!rows.length)
    html +=
      '<p class="v8-note">No drafts are available in your authorized view. Staff can assign new drafts; requesters see only their assigned drafts.</p>';
  return html;
}
module.exports = { render };
