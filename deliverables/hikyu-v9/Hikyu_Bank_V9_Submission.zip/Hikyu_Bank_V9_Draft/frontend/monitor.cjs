const { e, time, form, hidden } = require("./common.cjs");
const ERRORS = {
  EXTERNAL_WRITE_FAILED:
    "The external case table could not be written. Staff can replay after the cause is fixed.",
  AUTH_FAILED:
    "The external connection rejected authentication. Correct its secure configuration before replay.",
  RELAY_AUTH_REQUIRED:
    "The relay requires valid authentication. Check the secure connection configuration.",
  RELAY_NETWORK_FAILURE:
    "The relay could not be reached. A recoverable transport attempt may be retried.",
  NETWORK_FAILURE: "The network delivery failed. Check connectivity and the retry state.",
  CASE_VERSION_CONFLICT:
    "The external row has conflicting data for the same version. Staff review is required.",
  OUTCOME_SUPERSEDED: "A newer business version exists; this old delivery cannot be replayed.",
};
function render({ name, req, staff, rows, transport, monitor, stats, events }) {
  const statuses = [...new Set(rows.map((r) => String(r.sync_status || "UNKNOWN")))].sort();
  let html =
    '<h1>Support Case Outcome Synchronization</h1><p class="v8-note">Business state is authoritative. Synchronization state describes delivery and receipts only. A recorded SYNCED receipt does not independently verify a live Zapier or Google run.</p>';
  if (/^http:\/\/(127\.0\.0\.1|localhost)(:|\/)/.test(transport.relay_url || ""))
    html +=
      '<p class="v8-warning">Local contract emulator configured. This is not a Zapier or Google Sheets end-to-end run.</p>';
  html += /* HTML */ `
    <p>
      Displayed scope: up to 100 records loaded for your authorized role. Summary and filters
      apply only to these
      <strong data-loaded-count>${rows.length}</strong>
      records, not all database records.
    </p>
    <div
      class="v8-summary"
      data-status-summary
      aria-label="Loaded synchronization status summary"
    ></div>
    <div class="v8-controls">
      <div class="v8-field">
        <label for="v8-sync-filter">Synchronization status</label>
        <select id="v8-sync-filter" data-sync-filter>
          <option value="">All loaded statuses</option>
          ${statuses
            .map(
              (s) => /* HTML */ `
                <option value="${e(s)}">${e(s)}</option>
              `,
            )
            .join("")}
        </select>
      </div>
      <div class="v8-field">
        <label for="v8-sync-search">Find case number</label>
        <input
          id="v8-sync-search"
          type="search"
          data-case-search
          placeholder="Search loaded case numbers"
        />
      </div>
      <button
        type="button"
        id="v8-sync-refresh"
        class="btn btn-secondary v8-refresh"
        data-v8-refresh
      >
        Refresh authorized records
      </button>
    </div>
    <p data-filter-result role="status" aria-live="polite">
      ${rows.length} of ${rows.length} loaded records shown.
    </p>
    <p data-empty-filter class="v8-note" ${rows.length ? "hidden" : ""}>
      No records match the selected filters in this authorized view.
    </p>
  `;
  for (const r of rows) {
    html += `
      <article
        class="v8-card v7-sync"
        data-case-id="${e(r.case_id)}"
        data-sync-state="${e(r.sync_status || "UNKNOWN")}"
        data-version="${e(r.state_version)}"
      >
        <h2 class="v8-case-id">${e(r.case_id)}</h2>
        <div class="v8-summary">
          <span>
            Business state:
            <strong>${e(r.business_state)}</strong>
          </span>
          <span>
            Synchronization:
            <strong class="sync-state">${e(r.sync_status || "UNKNOWN")}</strong>
          </span>
          <span>Business version: ${e(r.state_version)}</span>
        </div>
        <dl class="v8-meta">
          <div>
            <dt>Last attempt</dt>
            <dd>${time(r.last_attempt_at)}</dd>
          </div>
          <div>
            <dt>Receipt synchronization time</dt>
            <dd>${time(r.synced_at)}</dd>
          </div>
          <div>
            <dt>External record identifier</dt>
            <dd>${e(r.external_record_id || "Not available")}</dd>
          </div>
          <div>
            <dt>Attempt count</dt>
            <dd>${e(r.attempts ?? 0)}</dd>
          </div>
        </dl>
        <p class="v8-error-summary">
          ${r.error_code
            ? `Error: ${e(ERRORS[r.error_code] || "The integration reported an error. Authorized staff can inspect its correlation audit before recovery.")} Code: ${e(r.error_code)}`
            : "Error: none recorded."}
        </p>
    `;
    if (r.sync_status === "SYNCED")
      html +=
        '<p class="v8-helper">A matching receipt was stored. Its execution environment is not independently verified by this record.</p>';
    if (staff && !["ACKNOWLEDGED", "OBSOLETE"].includes(r.job_status))
      html += form(
        name,
        req,
        "replay",
        r.outbox_id,
        hidden("id", r.outbox_id),
        "Replay outcome safely",
      );
    html += "</article>";
  }
  if (staff) {
    html +=
      /* HTML */ `<h2>Relay transport</h2><p>State: ${e(monitor.state || "Not checked")} · Error: ${e(monitor.error_code || "None")} · Checked: ${time(monitor.checked_at)}</p><h2>Staff outbox queue totals</h2><p>These separate queue totals cover the staff outbox, not the filtered case cards above.</p>` +
      stats
        .map(
          (s) => /* HTML */ `
            <p>${e(s.job_status)}: ${e(s.total)}</p>
          `,
        )
        .join("");
    html +=
      '<h2>Recent correlation events</h2><p>At most 25 recent audit metadata rows. No full payload or credential is displayed.</p><div class="v8-table-scroll" tabindex="0" role="region" aria-label="Recent integration audit table"><table><thead><tr><th scope="col">Correlation</th><th scope="col">Operation</th><th scope="col">Result</th><th scope="col">Time</th></tr></thead><tbody>' +
      events
        .map(
          (v) => /* HTML */ `
            <tr>
              <td>${e(v.correlation_id)}</td>
              <td>${e(v.event_kind)}</td>
              <td>${e(v.result_code)}</td>
              <td>${time(v.occurred_at)}</td>
            </tr>
          `,
        )
        .join("") +
      "</tbody></table></div>";
  }
  return html;
}
module.exports = { render, ERRORS };
