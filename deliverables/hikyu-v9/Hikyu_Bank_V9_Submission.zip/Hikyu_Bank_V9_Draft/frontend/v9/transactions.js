const panel = document.querySelector(".v9-transactions");
const form = panel.querySelector("form");
const status = panel.querySelector("#v9-status");
const errorMessage = panel.querySelector("#v9-error");
const retry = panel.querySelector("[data-retry]");
const previous = panel.querySelector("[data-prev]");
const next = panel.querySelector("[data-next]");
const navigation = panel.querySelector("nav");
const table = panel.querySelector("table");
const body = table.tBodies[0];
const currency = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" });
const typeLabels = new Map([...form.elements.type.options].map(option => [option.value, option.text]));
let activeRequest;
let filters = new URLSearchParams();
let page = 1;

function showError(message, recoverable) {
  errorMessage.textContent = message;
  errorMessage.hidden = false;
  retry.hidden = !recoverable;
  status.textContent = "";
}

function renderRows(rows) {
  const fragment = document.createDocumentFragment();
  for (const row of rows) {
    const tr = document.createElement("tr");
    const fields = [row.name, row.category, typeLabels.get(row.kind) ?? row.kind,
      row.date, currency.format(row.amount_cents / 100)];
    for (const value of fields) {
      const cell = tr.insertCell();
      cell.textContent = value ?? "—";
    }
    fragment.append(tr);
  }
  body.replaceChildren(fragment);
}

async function load() {
  activeRequest?.abort();
  const controller = new AbortController();
  activeRequest = controller;
  const timeout = setTimeout(() => controller.abort(), 10000);
  errorMessage.hidden = retry.hidden = table.hidden = navigation.hidden = true;
  form.elements.to.removeAttribute("aria-invalid");
  const from = filters.get("from");
  const to = filters.get("to");
  if (from && to && from > to) {
    clearTimeout(timeout);
    form.elements.to.setAttribute("aria-invalid", "true");
    showError("End date must be on or after start date.", false);
    form.elements.to.focus();
    return;
  }
  const query = new URLSearchParams(filters);
  query.set("page", String(page));
  status.textContent = "Loading transactions…";
  try {
    const response = await fetch(`/hikyu-v9/transactions?${query}`, {
      signal: controller.signal,
      headers: { Accept: "application/json" },
    });
    if (activeRequest !== controller) return;
    if (!response.ok) {
      const data = await response.json().catch(() => ({}));
      if (activeRequest !== controller) return;
      showError(data.error || "Transactions could not be loaded. Try again.", response.status >= 500);
      return;
    }
    const data = await response.json();
    if (activeRequest !== controller) return;
    renderRows(data.rows);
    table.hidden = data.rows.length === 0;
    navigation.hidden = page === 1 && !data.hasNext;
    previous.disabled = page === 1;
    next.disabled = !data.hasNext;
    status.textContent = data.rows.length
      ? `Page ${data.page} · ${data.rows.length} ${data.rows.length === 1 ? "transaction" : "transactions"} shown.`
      : "No transactions match these filters.";
  } catch {
    if (activeRequest === controller) {
      showError("Transactions could not be loaded. Check your connection and retry.", true);
    }
  } finally {
    clearTimeout(timeout);
  }
}

form.addEventListener("submit", event => {
  event.preventDefault();
  filters = new URLSearchParams(new FormData(form));
  page = 1;
  void load();
});
form.addEventListener("reset", () => {
  filters = new URLSearchParams();
  page = 1;
  void load();
});
previous.addEventListener("click", () => { page -= 1; void load(); });
next.addEventListener("click", () => { page += 1; void load(); });
retry.addEventListener("click", () => { void load(); });
void load();
