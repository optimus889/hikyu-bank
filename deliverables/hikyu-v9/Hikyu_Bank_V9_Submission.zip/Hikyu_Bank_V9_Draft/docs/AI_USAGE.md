# AI use and authorship

Codex was the AI coding assistant for the V9 work. It inspected the available V8 checkout, drafted the use case before changing code, wrote the native UI and endpoint, adjusted the local packaging path and ran and reviewed the tests. The V9 additions, test scripts and documentation are AI-assisted. This record does not attribute the implementation, code review or tests to the student.

| Actual task or accurate prompt summary | Adopted work and verification |
| --- | --- |
| Inspect the attached project and prefer combined date, type and keyword filters if absent. Document the existing behavior and test requirements first. | Source inspection found a fixed latest-100 table and a separate CSV export. The initial repository archive exceeded the transfer limit. When the lean V8 source arrived, the assistant reviewed the uploaded code and recorded the use case on that exact baseline before applying the V9 changes. |
| Rebuild a real workflow in native HTML, CSS and JavaScript while keeping session permissions and the database. | The assistant reused the Transactions route and the signed-in Saltcorn session. It added an owner-scoped JSON read route using bound parameters, a static HTML template, CSS and a JS module. It used runtime schema inspection to choose UTC handling for PostgreSQL timestamps. |
| Validate real interaction, errors and a legacy flow while protecting data. | The assistant used Chromium and synthetic PostgreSQL fixtures. It exercised pagination, filter boundaries, no matches, denial, retry and CSV export. It used one browser-intercepted 503 to test recovery, then retried against the real API. |
| Provide reproducible files and a factual reflection. | The assistant preserved the uploaded Maven Wrapper and its license headers, checked the archive, and marked personal reflection as pending student review. |

Alternatives considered and omitted: client-only filtering would miss rows outside the previous latest-100 view. A mock ledger would not exercise the real session or database. SQL wildcard matching was replaced in the design by literal substring matching so percent and underscore have no wildcard meaning. No new framework or runtime AI service was added. No measured productivity gain is claimed.

## External sources and retained tooling

No external code snippet was copied into the new filters or browser module. The Maven Wrapper shell script and distribution settings are retained from the project baseline for build use. The script carries the Apache Software Foundation notice and Apache License 2.0 terms. Existing Saltcorn, Flowable, PostgreSQL and Playwright dependencies retain their upstream notices and existing configuration. See [external sources](EXTERNAL_SOURCES.md).

## Student review to complete

1. In `frontend/v9/transactions.html`, revise the help sentence with ID `v9-help` in your own words. Keep its ID and explain that the keyword matches transaction name or category and that dates use UTC.
2. Open the running Transactions page and refresh. The runtime reads the template from disk. Use Tab to move through the form and Enter to apply an inclusive date range and one keyword. Verify that the revised help appears and filtering still works.
3. Run the browser test command in the [README](../README.md). Record your exact wording change, reasoning, observed result and experience compared with AI assistance in [MANUAL_REVIEW.md](MANUAL_REVIEW.md). Update the reflection with confirmed personal observations and keep it within 100–200 English words.

The student exercise and personal observations are pending. The preceding execution record describes Codex activity.
