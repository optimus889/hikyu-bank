# V9 use case — Find a transaction

A signed-in customer wants to find a particular transaction without scanning a long list or opening a CSV. For example, they may remember part of a merchant name and the week an expense posted.

The inspected V8 Transactions page loads the latest 100 owner-scoped rows. It also offers a separate date-based CSV export. Its view advertises some state fields, but the listing query does not consume them. V8 has no combined date, type and keyword filtering in this installed Saltcorn view.

1. Open Transactions as a signed-in customer.
2. Optionally enter a start date, an end date, a transaction type and a keyword. Select Apply filters.
3. Review the matching rows. Use Previous or Next for another page, or Clear filters to return to the unfiltered list.
4. If no rows match or the request fails, adjust the filters or retry without re-entering them.

Acceptance criteria:

- Each supplied condition narrows the same query. Dates are inclusive UTC posting dates. Keywords match literal, case-insensitive substrings in transaction name or category. A date bound may be omitted.
- Results cover the signed-in owner's dataset, including rows beyond the former latest-100 window. Pages show up to 25 rows ordered newest first, with ID as a stable tie-breaker. Foreign users' rows are excluded before filtering.
- Invalid dates and reversed ranges produce readable errors. Loading, no matches, retries and reset have distinct feedback. Form controls are labelled and keyboard accessible, and the results fit narrow viewports.
- The existing date-only CSV export and other banking flows retain their behavior. Viewing and filtering write no transaction or account data.
