# External sources

- Apache Maven Wrapper 3.3.4 and Maven 3.9.11. The unchanged shell wrapper and distribution settings come from the project baseline. The wrapper retains its ASF notice and Apache License 2.0 header. [Maven Wrapper](https://maven.apache.org/wrapper/) · [License](https://www.apache.org/licenses/LICENSE-2.0)
- Saltcorn and Flowable are inherited runtime dependencies. The existing npm lockfile and Maven POM declare the versions. [Saltcorn](https://github.com/saltcorn/saltcorn) · [Flowable](https://github.com/flowable/flowable-engine)
- PostgreSQL is inherited via the Compose definition. [PostgreSQL license](https://www.postgresql.org/about/licence/)
- Playwright is an inherited test dependency. Its lockfile pins the tools used for the browser suite. [Playwright](https://github.com/microsoft/playwright)
