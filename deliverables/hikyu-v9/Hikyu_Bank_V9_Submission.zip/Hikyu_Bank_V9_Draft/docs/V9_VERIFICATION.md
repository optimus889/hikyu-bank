# V9 baseline and verification

## Inspected baseline

The baseline is the newly supplied `Hikyu_Bank_V8.zip` (75 entries, SHA-256 `4124613d6fc3dc0e3d73e49715e2a0f1decf7b6524326544eec754215ae2979d`). Its contents were recorded at local baseline commit `378ef96`. Source inspection found V8's separate `frontend/` and `backend/` layout, unlike the earlier provisional checkout. V9 was applied to that uploaded layout on an independent feature branch. The V8 archive remains unchanged.

The reference `Hikyu_Bank_V5.zip` contains a Spring Boot local launcher, PostgreSQL Compose configuration, Flyway migrations and an API controller for transactions under `/api/v1/transactions`. Its README also documents an optional Supabase database configuration. V5 was inspected as the local deployment reference and was not launched. No V5 application files were copied into V9.

The uploaded V8 includes a local classifier used during the Flowable support process and separately configurable Google relay and Zapier adapters for integration. Their presence in source establishes that they are packaged. External account connectivity was not exercised.

The inspected application uses Saltcorn sessions and native views backed by PostgreSQL, plus a loopback Flowable service for support reviews. Pages cover accounts, transfers and payments, transactions and CSV, insights, demo tools, settings, support requests, inbox and synchronization. The existing Transactions view checks the session, queries by owner, orders by date/ID and limits the list to 100. Only the separate CSV handler consumes a date range. The account link's query parameter was already ignored by the old table and is outside this V9 use case. External relay execution was outside this run.

The original V8 setup booted in a new local database with generated synthetic users. The database inspection found `posted_date` is `timestamp with time zone` and `kind` is text. The SQL applies UTC date boundaries explicitly.

## Commands and recorded results

| Command | Result | Scope |
| --- | --- | --- |
| `V6_DB_PORT=55626 python3 backend/prepare_v8.py` | Pass | Fresh baseline setup with local ports 8696/8697 and PostgreSQL port 55626, Saltcorn and Flowable ready, 6 Flowable build tests passed. |
| `node backend/saltcorn/test_csv.cjs` on V8 | Pass, 5 checks | Actual CSV route and Chromium before the feature. |
| `V6_DB_PORT=55636 python3 backend/prepare_v9.py` | Pass | Fresh V9 setup from the uploaded source layout with local ports 8796/8797. |
| `node backend/v9/tests/transactions.cjs` | Pass, 9 checks | Real Chromium at 375 px, signed-in Saltcorn, PostgreSQL and synthetic fixtures. One intercepted 503 exercises UI recovery. |
| `node backend/saltcorn/test_csv.cjs` on V9 | Pass, 5 checks | Original route, inclusive dates, invalid range handling, formula neutralization and ownership. |
| `node --test backend/v8/tests/unit.cjs` | Pass, 14 tests | Inherited support and synchronization renderer checks. |
| Signed-in V8 browser smoke | Pass | Transaction rows and CSV form present, combined filter form absent. |
| `python3 backend/test_workflow_http.py` on V9 | Pass, 9 tests | Local Flowable HTTP regression, including classifier, role checks and branch/state behavior. |
| Flowable build tests during V9 startup | Pass, 6 tests | Real Flowable engine suite on the uploaded V8 runtime with V9 changes. |
| Real Zapier and Google execution | Not run | External relay remains disabled. |
| Student manual edit and reflection confirmation | Pending | See the separate manual review record. |

## Browser suite coverage

1. Unauthenticated API requests return 401.
2. The live page loads exactly 25 results and Previous and Next reach the expected pages.
3. Keyboard submission finds an expense older than the newest 100 rows. It excludes the other type, the next UTC day and the other user. Percent and underscore are literal, and the keyword is case-insensitive.
4. Reversed dates show a labelled error.
5. The server rejects an impossible date, unknown type, invalid page and duplicate keywords. A request parameter cannot select another owner.
6. An injected 503 retains the selected filters. Retry succeeds against the live API.
7. No matches and clear/reset show the expected states.
8. The panel fits the mobile viewport, keyboard Tab reaches Apply filters and the browser reports no script errors.
9. The rows used in the assertions are unchanged after browsing and filtering.

The tests use the environment's Chromium and recorded outcomes. The controlled 503 does not imply an actual backend outage. The V9 route performs only SELECT queries.

The final archive passed ZIP integrity and local Markdown link checks. The final ZIP contains the source used in the fresh V9 setup. Extracted files were compared with this tested worktree. Setup structure and internal documentation links were also checked in the extracted folder. The Reflection.docx was read back with its original paragraphs and rendered as one page. The body contains 174 English words.

## Startup update

A fresh local installation with the revised scripts completed npm setup, Saltcorn initialization and the Maven build. All six Flowable build tests passed. An in-place rebuild of an existing demo also completed. After stopping both application services in the fresh demo, the default V9 command skipped npm and Maven and restarted both in 8.007 seconds in the Linux cloud environment. The readiness checks and nine V9 browser/API checks passed after that restart. macOS was not available for runtime testing. The macOS JDK lookup uses the system java_home utility when JAVA_HOME is unset.

## Source readability update

The V9 application source uses two-space indentation for JavaScript, HTML, CSS and Java, and four-space indentation for Python. Compressed statements and nested UI templates were expanded into readable blocks. Dependency lockfiles, vendored scripts and the BPMN workflow definition were retained. The browser authorization test now falls back to Saltcorn's page CSRF token when a view has no form. This is a test-helper change.

After rebuilding the formatted application, the six Flowable build tests, nine V9 browser/API checks, five CSV checks, fourteen banking browser checks, fourteen V8 unit tests, nine workflow HTTP tests and eighteen support UI browser checks passed. The support suite used local synthetic fixtures. No external Zapier or Google run was performed.

## Local PostgreSQL password recovery

A copied test installation was intentionally given a different generated password while its Docker data volume was retained. The startup check reported 28P01 before dependency installation. The explicit repair aligned the local demo role, and a second repair invocation verified the existing password. The transaction fingerprint was unchanged. After restarting both local services, all nine V9 browser/API checks passed. Verification used Linux Docker and did not access the user's Mac.

The duplicate demo-account recovery path was tested on an isolated existing database by temporarily removing its generated account credential file. Setup reused all six synthetic account IDs and regenerated working passwords. The existing requester transactions remained available and all nine V9 browser/API checks passed.

The requester login diagnostic was tested on an isolated V9 installation by changing only the stored local requester password to simulate a mismatch. The check rejected the stale password. The explicit reset restored login with the new password and preserved the requester ID, transaction ownership and all other account passwords. All nine browser/API checks passed after recovery. The oversized user attachment could not be inspected.

## Saltcorn restart after database repair

The starter checks the Saltcorn database client through the host PostgreSQL port in addition to the Compose check. A mismatched local password stopped the restart before the running process was signalled. A test with an unrelated PID in the local runtime record also stopped safely. With an intentionally invalid shell `DATABASE_URL`, `python3 backend/start-services.py --restart-web` verified the generated host connection, restarted the tracked Saltcorn process and loaded the signed-in Transactions page in Chromium. All nine V9 browser/API checks passed after the restart. These tests used the isolated Linux Docker demo. Verification on the affected Mac is pending.
