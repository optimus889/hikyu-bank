const fs = require("fs"),
  path = require("path"),
  crypto = require("crypto"),
  { chromium } = require("playwright");
const { ROOT, APP_URL } = require("../runtime.cjs"),
  { init, db } = require("../../saltcorn/sdk.cjs"),
  I = require("../../v7/integration/inbox.cjs");
(async () => {
  await init();
  const users = JSON.parse(fs.readFileSync(ROOT + "/private/saltcorn-accounts.json")),
    user = (k) => users.find((u) => u.key === k),
    output = path.join(ROOT, "evidence/v8/final");
  const d = await I.importEvent({
    source_type: "form",
    source_namespace: "v8-curated-synthetic-form",
    source_event_id: crypto.randomUUID(),
    subject: "Help with a synthetic card transaction",
    description:
      "My synthetic card is locked. Please help me understand the transaction status.",
    submitted_at: new Date().toISOString(),
  });
  await I.assign(user("service_agent"), d.draft_id, user("requester").id, 1);
  await I.claim(user("requester"), d.draft_id, 2);
  const b = await chromium.launch({
      executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium",
      args: ["--no-sandbox"],
    }),
    c = await b.newContext({ viewport: { width: 1440, height: 1050 } }),
    p = await c.newPage();
  const a = user("requester");
  await p.goto(APP_URL + "/auth/login");
  await p.locator("[name=email]").fill(a.email);
  await p.locator("[name=password]").fill(a.password);
  await p.locator("button[type=submit]").click();
  await p.goto(APP_URL + "/page/support-inbox");
  const card = p.locator('.v7-draft[data-draft-id="' + d.draft_id + '"]');
  await card.screenshot({ path: output + "/inbox-card-desktop.png" });
  await p.setViewportSize({ width: 375, height: 900 });
  await card
    .locator("form[data-v8-action=submit_draft]")
    .screenshot({ path: output + "/inbox-form-mobile.png" });
  fs.writeFileSync(
    output + "/capture-metadata.json",
    JSON.stringify(
      {
        time: new Date().toISOString(),
        kind: "Actual native browser screenshots of a fresh synthetic claimed draft; no added test count; no external run",
        draft_id: d.draft_id,
        case_id: d.case_id,
      },
      null,
      2,
    ),
  );
  await b.close();
  await db.close();
})();
