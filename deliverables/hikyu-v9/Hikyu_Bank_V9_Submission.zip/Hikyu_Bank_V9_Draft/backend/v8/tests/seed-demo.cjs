const crypto = require("crypto"),
  { init, db } = require("../../saltcorn/sdk.cjs"),
  I = require("../../v7/integration/inbox.cjs");
(async () => {
  await init();
  const r = await I.importEvent({
    source_type: "form",
    source_namespace: "v8-local-synthetic-demo",
    source_event_id: crypto.randomUUID(),
    subject: "Synthetic card transaction question",
    description: "My synthetic card is locked and I need help understanding a transaction.",
    submitted_at: new Date().toISOString(),
  });
  console.log(
    JSON.stringify({
      kind: "Local adapter demo; not an external platform run",
      draft_id: r.draft_id,
      case_id: r.case_id,
    }),
  );
  await db.close();
})();
