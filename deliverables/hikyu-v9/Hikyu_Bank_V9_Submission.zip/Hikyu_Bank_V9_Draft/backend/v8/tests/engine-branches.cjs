const fs = require("fs"),
  path = require("path"),
  crypto = require("crypto"),
  assert = require("assert/strict"),
  { spawnSync } = require("child_process"),
  { chromium } = require("playwright");
const { ROOT, APP_URL, WORKFLOW_URL } = require("../runtime.cjs"),
  { init, db } = require("../../saltcorn/sdk.cjs"),
  core = require("../../saltcorn/integration.cjs");
const accounts = JSON.parse(fs.readFileSync(ROOT + "/private/saltcorn-accounts.json")),
  user = (key) => accounts.find((a) => a.key === key),
  results = [],
  output = path.join(ROOT, "evidence/v8/branches");
fs.mkdirSync(output, { recursive: true });
const delay = (ms) => new Promise((r) => setTimeout(r, ms));
let browser;
async function restart(extra = {}) {
  const pid = JSON.parse(fs.readFileSync(ROOT + "/private/service-pids.json")).workflow;
  try {
    process.kill(-pid, "SIGTERM");
  } catch (e) {
    if (e.code !== "ESRCH") throw e;
  }
  for (let i = 0; i < 40; i++) {
    try {
      await fetch(WORKFLOW_URL + "/health", { signal: AbortSignal.timeout(300) });
      await delay(100);
    } catch {
      break;
    }
  }
  const env = { ...process.env, ...extra };
  if (!Object.hasOwn(extra, "V6_AI_SCRIPT")) delete env.V6_AI_SCRIPT;
  if (!Object.hasOwn(extra, "V6_REVIEW_TIMEOUT")) delete env.V6_REVIEW_TIMEOUT;
  const r = spawnSync("python3", [ROOT + "/backend/start-services.py"], {
    env,
    encoding: "utf8",
    timeout: 40000,
  });
  if (r.status !== 0) throw Error("V8 workflow restart failed; inspect private local logs");
}
async function view(role, bid) {
  const c = await browser.newContext({ viewport: { width: 1440, height: 1050 } }),
    p = await c.newPage(),
    a = user(role);
  await p.goto(APP_URL + "/auth/login");
  await p.locator("[name=email]").fill(a.email);
  await p.locator("[name=password]").fill(a.password);
  await p.locator("button[type=submit]").click();
  await p.goto(APP_URL + "/page/support-requests");
  const card = p.locator('[data-business-id="' + bid + '"]');
  await card.waitFor();
  return { page: p, card, context: c };
}
async function submit() {
  const tx = (
    await db.query("SELECT id FROM transactions WHERE owner_id=$1 LIMIT 1", [
      user("requester").id,
    ])
  ).rows[0].id;
  return core.submit(user("requester"), {
    business_id: "v6-" + crypto.randomUUID(),
    transaction_id: tx,
    description: "My synthetic card is locked and purchases are blocked",
  });
}
async function test(name, fn) {
  try {
    const detail = await fn();
    results.push({
      name,
      status: "Pass",
      kind: "Actual local Flowable + native browser; controlled fault/SLA test; synthetic roles simulated by one operator",
      detail,
    });
    console.log("PASS " + name);
  } catch (e) {
    results.push({ name, status: "Fail", error: e.message });
    console.error("FAIL " + name + ": " + e.message);
  }
}
(async () => {
  await init();
  browser = await chromium.launch({
    executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium",
    args: ["--no-sandbox"],
  });
  try {
    await test("Actual manual triage branch after malformed classifier output", async () => {
      const file = ROOT + "/private/v8-malformed-classifier.py";
      fs.writeFileSync(file, "print('{\"invalid_synthetic_output\":true}')\n", { mode: 0o600 });
      await restart({ V6_AI_SCRIPT: file });
      let r = await submit();
      assert.equal(r.state, "MANUAL_TRIAGE");
      const ui = await view("service_agent", r.business_id);
      assert.equal(
        await ui.card.locator("[data-v8-progress]").getAttribute("data-stage"),
        "MANUAL_TRIAGE",
      );
      await ui.card.screenshot({ path: output + "/manual-triage.png" });
      await core.decide(user("service_agent"), {
        id: r.id,
        expected_sequence: r.sequence,
        decision: "continue",
        comment: "Synthetic manual routing confirmed",
      });
      r = (await db.query("SELECT * FROM support_requests WHERE id=$1", [r.id])).rows[0];
      assert.equal(r.state, "SERVICE_REVIEW");
      await ui.context.close();
      return {
        case_id: r.business_id,
        process_instance_id: r.process_instance_id,
        manual_route:
          "Malformed classifier output injected through V6_AI_SCRIPT in the actual child process; no successful AI output claimed",
        result: r.state,
      };
    });
    await test("Actual review timeout escalates to supervisor and completes persistently", async () => {
      await restart({ V6_REVIEW_TIMEOUT: "PT2S" });
      let r = await submit();
      assert.equal(r.state, "SERVICE_REVIEW");
      await core.decide(user("service_agent"), {
        id: r.id,
        expected_sequence: r.sequence,
        decision: "continue",
        comment: "Synthetic service review; timer branch test",
      });
      const until = Date.now() + 45000;
      while (Date.now() < until) {
        r = (await db.query("SELECT * FROM support_requests WHERE id=$1", [r.id])).rows[0];
        await core.syncRow(r);
        r = (await db.query("SELECT * FROM support_requests WHERE id=$1", [r.id])).rows[0];
        if (r.state === "ESCALATED") break;
        await delay(300);
      }
      assert.equal(r.state, "ESCALATED");
      const ui = await view("supervisor", r.business_id);
      assert.equal(
        await ui.card.locator("[data-v8-progress]").getAttribute("data-stage"),
        "ESCALATED",
      );
      await ui.card.screenshot({ path: output + "/timeout-escalated.png" });
      const escalatedVersion = r.sequence;
      await core.decide(user("supervisor"), {
        id: r.id,
        expected_sequence: r.sequence,
        decision: "complete",
        comment: "Synthetic overdue review completed by supervisor",
      });
      const requester = await view("requester", r.business_id);
      await requester.page.reload();
      assert.equal(
        await requester.card.locator("[data-v8-progress]").getAttribute("data-stage"),
        "COMPLETED",
      );
      await requester.card.screenshot({ path: output + "/completed-after-escalation.png" });
      await ui.context.close();
      await requester.context.close();
      return {
        case_id: r.business_id,
        process_instance_id: r.process_instance_id,
        escalated_version: escalatedVersion,
        test_sla: "PT2S",
        normal_sla_restored: "PT24H",
        kind: "Actual timer boundary execution; no invented stage history displayed",
      };
    });
  } finally {
    try {
      await restart();
    } catch (e) {
      results.push({
        name: "Restore default workflow configuration",
        status: "Fail",
        error: e.message,
      });
    }
    await browser.close();
    await db.close();
    fs.writeFileSync(
      output + "/results.json",
      JSON.stringify(
        { time: new Date().toISOString(), results, real_external_execution: false },
        null,
        2,
      ),
    );
    if (results.some((r) => r.status === "Fail")) process.exitCode = 1;
  }
})().catch((e) => {
  console.error(e.stack);
  process.exit(1);
});
