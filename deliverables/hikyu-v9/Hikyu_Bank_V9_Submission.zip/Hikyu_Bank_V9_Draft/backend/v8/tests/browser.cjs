const fs = require("fs"),
  path = require("path"),
  crypto = require("crypto"),
  assert = require("assert/strict");
const { chromium } = require("playwright");
const { ROOT, APP_URL } = require("../runtime.cjs"),
  { init, db } = require("../../saltcorn/sdk.cjs"),
  I = require("../../v7/integration/inbox.cjs"),
  O = require("../../v7/integration/outcomes.cjs"),
  core = require("../../saltcorn/integration.cjs");
const round = process.env.V8_TEST_ROUND || "final",
  output = path.join(ROOT, "evidence/v8", round);
fs.mkdirSync(output, { recursive: true });
const accounts = JSON.parse(fs.readFileSync(ROOT + "/private/saltcorn-accounts.json")),
  account = (k) => accounts.find((a) => a.key === k),
  results = [],
  sessions = {},
  errors = [],
  consoleErrors = [];
let browser, mainDraft, mainCase, replayRow;
const marker = "v8-" + Date.now();
async function test(
  name,
  steps,
  expected,
  fn,
  kind = "Actual local native browser + PostgreSQL/Flowable, synthetic accounts, one-person role simulation",
) {
  const before = Date.now();
  try {
    const actual = await fn();
    results.push({
      name,
      status: "Pass",
      kind,
      steps,
      expected,
      actual: actual || "Assertions satisfied",
      duration_ms: Date.now() - before,
    });
    console.log("PASS " + name);
  } catch (e) {
    results.push({
      name,
      status: "Fail",
      kind,
      steps,
      expected,
      error: e.message,
      duration_ms: Date.now() - before,
    });
    console.error("FAIL " + name + ": " + e.message);
  }
}
async function page(role) {
  if (sessions[role]) return sessions[role];
  const c = await browser.newContext({ viewport: { width: 1440, height: 1050 } }),
    p = await c.newPage(),
    a = account(role);
  p.on("pageerror", (e) => errors.push({ role, message: e.message }));
  p.on("console", (m) => {
    if (m.type() === "error")
      consoleErrors.push({ role, message: m.text(), url: m.location().url });
  });
  await p.goto(APP_URL + "/auth/login");
  await p.locator("[name=email]").fill(a.email);
  await p.locator("[name=password]").fill(a.password);
  await p.locator("button[type=submit]").click();
  await p.waitForURL((url) => !url.pathname.includes("/auth/login"));
  sessions[role] = p;
  return p;
}
async function go(role, view) {
  const p = await page(role);
  await p.goto(APP_URL + "/page/" + view);
  await p.locator("[data-v8-root]").waitFor();
  return p;
}
async function claimed(
  role = "requester",
  description = "My synthetic card is locked and purchases are blocked.",
) {
  const e = {
    source_type: "form",
    source_namespace: marker,
    source_event_id: crypto.randomUUID(),
    subject: "Synthetic support " + marker,
    description,
    submitted_at: new Date().toISOString(),
    source_reference: "",
  };
  const r = await I.importEvent(e);
  await I.assign(account("service_agent"), r.draft_id, account(role).id, 1);
  await I.claim(account(role), r.draft_id, 2);
  return (await db.query("SELECT * FROM support_inbox WHERE id=$1", [r.draft_id])).rows[0];
}
const card = (p, draft) => p.locator('.v7-draft[data-draft-id="' + draft.id + '"]');
async function transaction(role = "requester") {
  return (
    await db.query("SELECT id FROM transactions WHERE owner_id=$1 ORDER BY id LIMIT 1", [
      account(role).id,
    ])
  ).rows[0].id;
}
async function rawPost(p, view, data, csrf = true) {
  return p.evaluate(
    async ({ view, data, csrf }) => {
      if (csrf) {
        const token =
          document.querySelector("input[name=_csrf]")?.value || window._sc_globalCsrf;
        if (!token) throw new Error("Authenticated browser page is missing a CSRF token.");
        data._csrf = token;
      }
      const r = await fetch("/view/" + view, {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          Accept: "application/json",
        },
        body: new URLSearchParams(data),
      });
      return { status: r.status, redirected: r.redirected, pathname: new URL(r.url).pathname };
    },
    { view, data, csrf },
  );
}
async function shot(p, name) {
  await p.screenshot({ path: path.join(output, name), fullPage: false });
}
async function syncFixture(owner, state, syncStatus, index) {
  const bid = "v6-" + crypto.randomUUID();
  const r = (
    await db.query(
      "INSERT INTO support_requests(owner_id,business_id,transaction_id,description,state,sequence,\"current_role\",created_at,updated_at,request_hash,retry_attempts,next_retry_at) VALUES($1,$2,$3,$4,$5,1,$6,now(),now(),$7,0,now()+interval '7 days') RETURNING *",
      [
        owner.id,
        bid,
        await transaction(owner.key),
        "Synthetic V8 display-only integration fixture " + index,
        state,
        "none",
        crypto.randomUUID(),
      ],
    )
  ).rows[0];
  await O.captureTerminals();
  const out = (await db.query("SELECT * FROM v7_outbox WHERE case_id=$1", [bid])).rows[0];
  if (!out) throw Error("Fixture terminal outbox missing");
  await db.query(
    "UPDATE v7_outbox o SET next_attempt_at=now()+interval '7 days' FROM support_requests r WHERE r.id=o.support_request_id AND (r.description LIKE 'Synthetic V8 display-only integration fixture %' OR r.description LIKE 'V8 display-only state fixture %')",
  );
  await db.query(
    "UPDATE v7_case_sync SET sync_status=$1,last_attempt_at=now(),error_code=$2,external_record_id=$3,synced_at=$4 WHERE case_id=$5",
    [
      syncStatus,
      syncStatus === "FAILED" ? "EXTERNAL_WRITE_FAILED" : null,
      syncStatus === "SYNCED" ? "synthetic-local-record:" + bid : null,
      syncStatus === "SYNCED" ? new Date() : null,
      bid,
    ],
  );
  await db.query("UPDATE v7_outbox SET job_status=$1 WHERE id=$2", [
    syncStatus === "FAILED" ? "FAILED" : syncStatus === "SYNCED" ? "ACKNOWLEDGED" : "PENDING",
    out.id,
  ]);
  return { case: r, out };
}
(async () => {
  await init();
  const transactionsBefore = (await db.query("SELECT * FROM transactions ORDER BY id")).rows,
    accountsBefore = (await db.query("SELECT * FROM accounts ORDER BY id")).rows;
  browser = await chromium.launch({
    executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium",
    headless: true,
    args: ["--no-sandbox"],
  });
  try {
    await test(
      "Source content is escaped and metadata is readable",
      "Persist a claimed synthetic draft with markup; open native Inbox",
      "Text is displayed without executing markup; source/status/time/labels present",
      async () => {
        mainDraft = await claimed(
          "requester",
          'My synthetic card is locked. <img src=x onerror="window.v8Injected=true">',
        );
        await db.query("UPDATE support_inbox SET subject=$1 WHERE id=$2", [
          "Synthetic <script>window.v8Injected=true</script>",
          mainDraft.id,
        ]);
        const p = await go("requester", "support-inbox"),
          c = card(p, mainDraft);
        assert.equal(await c.locator("img,script").count(), 0);
        assert.equal(await p.evaluate(() => window.v8Injected), undefined);
        assert.match(await c.innerText(), /Source event|Source collection/);
        assert.equal(await c.locator("label[for]").count(), 2);
        await shot(p, "01-inbox-desktop.png");
        return { draft_id: mainDraft.id, case_id: mainDraft.case_business_id };
      },
    );
    await test(
      "Draft required and trimmed-length validation is linked and server-consistent",
      "Submit empty transaction, blank text, 2/3/2000/2001 trimmed characters; observe POST count",
      "Invalid fields have associated errors; valid boundaries reach API; invalid values create no POST",
      async () => {
        const p = await go("requester", "support-inbox"),
          c = card(p, mainDraft);
        let posts = 0;
        await p.route("**/view/V7_inbox", async (r) => {
          posts++;
          await r.fulfill({
            status: 503,
            contentType: "application/json",
            body: '{"ok":false,"error":{"code":"SYNTHETIC_UNAVAILABLE"}}',
          });
        });
        await c.getByRole("button", { name: "Confirm ownership and submit" }).click();
        assert.equal(
          await c.locator("[name=transaction_id]").getAttribute("aria-invalid"),
          "true",
        );
        assert.equal(posts, 0);
        await c.locator("[name=transaction_id]").selectOption(String(await transaction()));
        for (const [value, valid] of [
          ["   ", false],
          ["ab", false],
          [" abc ", true],
          ["x".repeat(2000), true],
          ["x".repeat(2001), false],
        ]) {
          await c.locator("[name=description]").evaluate((e, v) => {
            e.value = v;
            e.dispatchEvent(new Event("input", { bubbles: true }));
          }, value);
          const before = posts;
          await c.getByRole("button", { name: "Confirm ownership and submit" }).click();
          await p.waitForTimeout(80);
          assert.equal(posts - before, valid ? 1 : 0);
          assert.match(
            await c.locator("[data-description-counter]").innerText(),
            new RegExp("^" + value.trim().length + " / 2000"),
          );
        }
        assert.match(
          await c.locator("[name=description]").getAttribute("aria-describedby"),
          /description-error/,
        );
        await p.unroute("**/view/V7_inbox");
      },
    );
    await test(
      "API failure keeps edited inputs and displays a readable English error",
      "Inject one HTTP 500 after entering synthetic values",
      "Inputs remain unchanged and the pending state clears with error feedback",
      async () => {
        const p = await go("requester", "support-inbox"),
          c = card(p, mainDraft),
          text = "Edited synthetic description retained after failure.";
        await c.locator("[name=transaction_id]").selectOption(String(await transaction()));
        await c.locator("[name=description]").fill(text);
        await p.route("**/view/V7_inbox", (r) =>
          r.fulfill({ status: 500, contentType: "text/html", body: "Synthetic server error" }),
        );
        await c.getByRole("button", { name: "Confirm ownership and submit" }).click();
        await c.locator("[data-form-feedback][data-feedback-kind=error]").waitFor();
        assert.equal(await c.locator("[name=description]").inputValue(), text);
        assert.equal(
          await c.locator("[name=transaction_id]").inputValue(),
          String(await transaction()),
        );
        assert.match(await c.locator("[data-form-feedback]").innerText(), /kept|confirmed/);
        assert.equal(await c.locator("button[type=submit]").isEnabled(), true);
        await shot(p, "02-input-retained-after-error.png");
        await p.unroute("**/view/V7_inbox");
      },
      "Actual browser with deliberately intercepted HTTP 500; no real external failure",
    );
    await test(
      "Repeated enhancement binding produces one POST and no polling",
      "Execute controller three extra times, submit once against a 409 fixture, then wait idle",
      "One request only; no controller-generated background polling",
      async () => {
        const p = await go("requester", "support-inbox"),
          c = card(p, mainDraft);
        for (let i = 0; i < 3; i++)
          await p.addScriptTag({
            content: fs.readFileSync(path.join(ROOT, "frontend/controller.js"), "utf8"),
          });
        await c.locator("[name=transaction_id]").selectOption(String(await transaction()));
        await c.locator("[name=description]").fill("Synthetic repeated mount validation");
        let posts = 0;
        await p.route("**/view/V7_inbox", (r) => {
          posts++;
          return r.fulfill({
            status: 409,
            contentType: "application/json",
            body: '{"ok":false}',
          });
        });
        await c.getByRole("button", { name: "Confirm ownership and submit" }).click();
        await c.locator("[data-feedback-kind=error]").waitFor();
        assert.equal(posts, 1);
        let background = 0;
        const listen = (r) => {
          if (r.url().includes("/page/") || r.url().includes("/view/")) background++;
        };
        p.on("request", listen);
        await p.waitForTimeout(650);
        p.off("request", listen);
        assert.equal(background, 0);
        await p.unroute("**/view/V7_inbox");
      },
    );
    await test(
      "Pending draft blocks duplicate clicks and submits to actual Flowable",
      "Delay one actual POST, attempt a second native form submit, then let server complete",
      "One POST, disabled pending controls, one persisted support link and refreshed SUBMITTED card",
      async () => {
        const p = await go("requester", "support-inbox"),
          c = card(p, mainDraft);
        await c.locator("[name=transaction_id]").selectOption(String(await transaction()));
        await c
          .locator("[name=description]")
          .fill("My card is locked and purchases are blocked");
        let posts = 0;
        await p.route("**/view/V7_inbox", async (r) => {
          posts++;
          await new Promise((ok) => setTimeout(ok, 350));
          await r.continue();
        });
        await c.getByRole("button", { name: "Confirm ownership and submit" }).click();
        await p.waitForTimeout(80);
        assert.equal(await c.locator("button[type=submit]").isDisabled(), true);
        await c
          .locator("form[data-v8-action]")
          .evaluate((f) =>
            f.dispatchEvent(new Event("submit", { bubbles: true, cancelable: true })),
          );
        await p.waitForFunction(
          (id) =>
            document
              .querySelector('.v7-draft[data-draft-id="' + id + '"]')
              ?.textContent.includes("Draft status: SUBMITTED"),
          mainDraft.id,
        );
        assert.equal(posts, 1);
        mainDraft = (await db.query("SELECT * FROM support_inbox WHERE id=$1", [mainDraft.id]))
          .rows[0];
        mainCase = (
          await db.query("SELECT * FROM support_requests WHERE id=$1", [
            mainDraft.support_request_id,
          ])
        ).rows[0];
        assert.equal(mainCase.state, "SERVICE_REVIEW");
        assert.equal(mainCase.ai_category, "card_access");
        assert.match(await p.locator("[data-page-feedback]").innerText(), /SUBMITTED/);
        await p.unroute("**/view/V7_inbox");
        await p.reload();
        assert.match(await card(p, mainDraft).innerText(), /SUBMITTED/);
        return {
          case_id: mainCase.business_id,
          process_instance_id: mainCase.process_instance_id,
        };
      },
    );
    await test(
      "Native permissions, transaction ownership and CSRF remain enforced",
      "Use another account and forged posts for assignment, foreign transaction and missing CSRF",
      "Other user cannot see draft; backend rejects 403; CSRF omission rejected",
      async () => {
        const foreign = await claimed("other_requester"),
          p = await go("other_requester", "support-inbox");
        assert.equal(await card(p, mainDraft).count(), 0);
        let r = await rawPost(p, "V7_inbox", {
          command: "assign",
          id: foreign.id,
          assigned_user_id: account("other_requester").id,
          expected_version: 3,
        });
        assert.equal(r.status, 403);
        r = await rawPost(p, "V7_inbox", {
          command: "submit_draft",
          id: foreign.id,
          expected_version: 3,
          transaction_id: await transaction(),
          description: "Synthetic foreign transaction attempt",
        });
        assert.equal(r.status, 403);
        r = await rawPost(
          p,
          "V7_inbox",
          {
            command: "submit_draft",
            id: foreign.id,
            expected_version: 3,
            transaction_id: await transaction("other_requester"),
            description: "Synthetic CSRF rejection probe",
          },
          false,
        );
        assert.equal(r.redirected, true);
        assert.notEqual(r.pathname, "/view/V7_inbox");
        assert.equal(
          (
            await db.query("SELECT support_request_id FROM support_inbox WHERE id=$1", [
              foreign.id,
            ])
          ).rows[0].support_request_id,
          null,
        );
      },
    );
    await test(
      "Progress reflects real return and rejection branches after refresh",
      "Agent returns the real case; requester resubmits; agent rejects; reload each stage",
      "RETURNED and REJECTED appear as persisted states with no invented intermediate history",
      async () => {
        await core.decide(account("service_agent"), {
          id: mainCase.id,
          expected_sequence: mainCase.sequence,
          decision: "return",
          comment: "Synthetic clarification requested",
        });
        let p = await go("requester", "support-requests"),
          progress = p.locator('[data-v8-progress="' + mainCase.business_id + '"]');
        assert.equal(await progress.getAttribute("data-stage"), "RETURNED");
        let r = (await db.query("SELECT * FROM support_requests WHERE id=$1", [mainCase.id]))
          .rows[0];
        await core.decide(account("requester"), {
          id: r.id,
          expected_sequence: r.sequence,
          decision: "continue",
          description: "My synthetic card is still locked",
          comment: "Synthetic details added",
        });
        r = (await db.query("SELECT * FROM support_requests WHERE id=$1", [r.id])).rows[0];
        await core.decide(account("service_agent"), {
          id: r.id,
          expected_sequence: r.sequence,
          decision: "reject",
          comment: "Synthetic case rejected; no financial decision",
        });
        await p.reload();
        assert.equal(await progress.getAttribute("data-stage"), "REJECTED");
        assert.equal(await progress.locator("li").count(), 2);
        assert.match(await progress.innerText(), /Earlier stage history/);
        await shot(p, "03-persisted-rejected-progress.png");
        return {
          case_id: mainCase.business_id,
          kind: "Actual Flowable return/resubmission/rejection, one-person role simulation",
        };
      },
    );
    await test(
      "All branch states, unknown state and missing history render safely in native browser",
      "Insert clearly labelled display-only persisted fixtures for all state codes plus unknown; read native page",
      "Eight states and unknown handled; no fake history, dates or universal linear path; unknown is not final",
      async () => {
        for (const state of [
          "SUBMITTED",
          "MANUAL_TRIAGE",
          "SERVICE_REVIEW",
          "RETURNED",
          "REVIEWER_REVIEW",
          "ESCALATED",
          "COMPLETED",
          "REJECTED",
          "FUTURE_UNKNOWN",
        ]) {
          await db.query(
            "INSERT INTO support_requests(owner_id,business_id,transaction_id,description,state,sequence,\"current_role\",request_hash,next_retry_at) VALUES($1,$2,$3,$4,$5,1,$6,$7,now()+interval '7 days')",
            [
              account("requester").id,
              "v6-" + crypto.randomUUID(),
              await transaction(),
              "V8 display-only state fixture " + state,
              state,
              "none",
              crypto.randomUUID(),
            ],
          );
        }
        const p = await go("requester", "support-requests");
        for (const state of [
          "SUBMITTED",
          "MANUAL_TRIAGE",
          "SERVICE_REVIEW",
          "RETURNED",
          "REVIEWER_REVIEW",
          "ESCALATED",
          "COMPLETED",
          "REJECTED",
          "FUTURE_UNKNOWN",
        ])
          assert.ok(await p.locator('[data-stage="' + state + '"]').count());
        const unknown = p.locator('[data-stage="FUTURE_UNKNOWN"]').first();
        assert.equal(await unknown.getAttribute("data-stage-kind"), "unknown");
        assert.equal(await unknown.locator("time").count(), 0);
        assert.match(await unknown.innerText(), /Completion cannot be confirmed/);
        assert.equal(await unknown.locator("li").count(), 1);
        await shot(p, "04-unknown-progress-fallback.png");
      },
      "Actual native browser with explicit persisted UI fixtures; these fixtures do not claim engine branch execution",
    );
    await test(
      "Synchronization filters and counts are limited to authorized loaded records",
      "Create 104 local display fixtures with separate owners and varied sync states; inspect staff and requester views",
      "Staff loads 100 maximum, sums equal loaded count; requester cannot see other owner records; filtering/empty states work",
      async () => {
        for (let i = 0; i < 104; i++)
          replayRow = await syncFixture(
            account(i < 3 ? "requester" : "other_requester"),
            i % 2 ? "REJECTED" : "COMPLETED",
            ["FAILED", "PENDING", "WAITING_ZAPIER", "SYNCED"][i % 4],
            i,
          );
        await db.query(
          "UPDATE v7_case_sync SET sync_status='FAILED',error_code=$1,external_record_id=$2 WHERE case_id=$3",
          [
            "SYNTHETIC_LONG_ERROR_" + "x".repeat(2000),
            "synthetic-local-record-" + "y".repeat(500),
            replayRow.case.business_id,
          ],
        );
        await db.query("UPDATE v7_outbox SET job_status='FAILED' WHERE id=$1", [
          replayRow.out.id,
        ]);
        await I.audit(
          "synthetic-correlation-" + "x".repeat(300),
          "SYNTHETIC_UI_AUDIT",
          "DISPLAY_FIXTURE",
        );
        const p = await go("service_agent", "case-synchronization");
        assert.equal(await p.locator(".v7-sync").count(), 100);
        assert.match(await p.locator("[data-filter-result]").innerText(), /100 of 100/);
        assert.match(await p.locator("[data-v8-root]").innerText(), /not all database records/);
        await p.locator("[data-sync-filter]").selectOption("FAILED");
        const expected = await p.locator('.v7-sync[data-sync-state="FAILED"]').count();
        assert.equal(await p.locator(".v7-sync:visible").count(), expected);
        await p.locator("[data-case-search]").fill("no-such-synthetic-case");
        assert.equal(await p.locator(".v7-sync:visible").count(), 0);
        assert.equal(await p.locator("[data-empty-filter]").isVisible(), true);
        await p.locator("[data-case-search]").fill("");
        await p.locator("[data-sync-filter]").selectOption("");
        await shot(p, "05-sync-monitor-desktop.png");
        const u = await go("requester", "case-synchronization");
        assert.equal(
          await u
            .locator('.v7-sync[data-case-id="' + replayRow.case.business_id + '"]')
            .count(),
          0,
        );
        assert.equal(await u.getByRole("button", { name: "Replay outcome safely" }).count(), 0);
        assert.equal(await u.locator(".v8-table-scroll").count(), 0);
        return {
          staff_loaded: 100,
          scope: "At most 100 authorized rows; local fixture statuses, no external runs",
        };
      },
      "Actual browser/DB with explicitly synthetic sync-display fixtures; not external synchronization evidence",
    );
    await test(
      "Replay authorization and backend failure keep real business state",
      "Ordinary user forges replay; staff action receives injected 503",
      "Backend denies ordinary user and staff sees an error without changing terminal business state",
      async () => {
        const u = await go("requester", "support-inbox");
        assert.equal(
          (await rawPost(u, "V7_sync", { command: "replay", id: replayRow.out.id })).status,
          403,
        );
        const p = await go("service_agent", "case-synchronization"),
          c = p.locator('.v7-sync[data-case-id="' + replayRow.case.business_id + '"]');
        await p.route("**/view/V7_sync", (r) =>
          r.fulfill({ status: 503, contentType: "application/json", body: '{"ok":false}' }),
        );
        await c.getByRole("button", { name: "Replay outcome safely" }).click();
        await c.locator("[data-feedback-kind=error]").waitFor();
        assert.equal(
          await c.getByRole("button", { name: "Replay outcome safely" }).isEnabled(),
          true,
        );
        assert.equal(
          (
            await db.query("SELECT state FROM support_requests WHERE id=$1", [
              replayRow.case.id,
            ])
          ).rows[0].state,
          replayRow.case.state,
        );
        await p.unroute("**/view/V7_sync");
      },
    );
    await test(
      "Refresh failure is visible and preserves the current monitor",
      "Fail one user-requested page refresh while records are loaded",
      "Failure feedback shown; existing cards and filters retained",
      async () => {
        const p = await go("service_agent", "case-synchronization");
        await p.locator("[data-case-search]").fill("v6-");
        const before = await p.locator(".v7-sync").count();
        await p.route("**/page/case-synchronization", (r) =>
          r.fulfill({
            status: 503,
            contentType: "text/html",
            body: "Synthetic refresh unavailable",
          }),
        );
        await p.locator("[data-v8-refresh]").click();
        await p.locator("[data-page-feedback][data-feedback-kind=error]").waitFor();
        assert.equal(await p.locator(".v7-sync").count(), before);
        assert.equal(await p.locator("[data-case-search]").inputValue(), "v6-");
        assert.equal(await p.locator("[data-v8-refresh]").isEnabled(), true);
        await p.unroute("**/page/case-synchronization");
      },
      "Actual browser with explicit local HTTP failure injection",
    );
    await test(
      "Stale refresh cannot overwrite a newer replay result",
      "Hold an old real GET response, replay the failed case, then release old response",
      "One replay; latest card remains PENDING; stale response cannot restore FAILED",
      async () => {
        const p = await go("service_agent", "case-synchronization");
        let held = false;
        await p.route("**/page/case-synchronization", async (r) => {
          if (!held) {
            held = true;
            const response = await r.fetch();
            await new Promise((ok) => setTimeout(ok, 500));
            await r.fulfill({ response }).catch(() => {});
          } else await r.continue();
        });
        await p.locator("[data-v8-refresh]").click();
        await p.waitForTimeout(100);
        const c = p.locator('.v7-sync[data-case-id="' + replayRow.case.business_id + '"]');
        let posts = 0;
        const listener = (r) => {
          if (r.url().endsWith("/view/V7_sync") && r.method() === "POST") posts++;
        };
        p.on("request", listener);
        await c.getByRole("button", { name: "Replay outcome safely" }).click();
        await p.waitForFunction(
          (id) =>
            document.querySelector('.v7-sync[data-case-id="' + id + '"] .sync-state')
              ?.textContent === "PENDING",
          replayRow.case.business_id,
        );
        await p.waitForTimeout(650);
        assert.equal(
          await p
            .locator('.v7-sync[data-case-id="' + replayRow.case.business_id + '"] .sync-state')
            .innerText(),
          "PENDING",
        );
        assert.equal(posts, 1);
        p.off("request", listener);
        await p.unroute("**/page/case-synchronization");
        await shot(p, "06-replay-refresh-race.png");
      },
    );
    await test(
      "Desktop/mobile, long content and keyboard focus are usable",
      "Inspect a fresh claimed draft and long monitor data at 375px and desktop; tab through controls",
      "No page horizontal overflow, labels/errors associated, visible keyboard focus, scoped audit scrolling",
      async () => {
        const d = await claimed(),
          p = await go("requester", "support-inbox");
        await p.setViewportSize({ width: 375, height: 900 });
        const c = card(p, d);
        await c.locator("[name=transaction_id]").focus();
        await p.keyboard.press("Tab");
        assert.equal(
          await c.locator("[name=description]").evaluate((el) => el === document.activeElement),
          true,
        );
        assert.equal(
          await c
            .locator("[name=description]")
            .evaluate((el) => getComputedStyle(el).outlineStyle),
          "solid",
        );
        assert.ok(
          await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 2),
        );
        await shot(p, "07-inbox-mobile.png");
        const staff = await go("service_agent", "case-synchronization");
        await staff.setViewportSize({ width: 375, height: 900 });
        assert.ok(
          await staff.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 2),
        );
        assert.equal(await staff.locator(".v8-table-scroll").getAttribute("tabindex"), "0");
        await shot(staff, "08-sync-mobile-long-content.png");
        await p.setViewportSize({ width: 1440, height: 1050 });
        await staff.setViewportSize({ width: 1440, height: 1050 });
      },
    );
    await test(
      "Keyboard focus is retained after a successful claim and monitor refresh",
      "Claim an assigned draft with the keyboard, then activate monitor refresh",
      "Focus moves to the updated card or its first editable field; refreshed monitor retains refresh control focus",
      async () => {
        const e = {
          source_type: "form",
          source_namespace: marker,
          source_event_id: crypto.randomUUID(),
          subject: "Synthetic keyboard claim",
          description: "Synthetic keyboard focus support request",
          submitted_at: new Date().toISOString(),
        };
        const d = await I.importEvent(e);
        await I.assign(account("service_agent"), d.draft_id, account("requester").id, 1);
        const p = await go("requester", "support-inbox"),
          c = p.locator('.v7-draft[data-draft-id="' + d.draft_id + '"]');
        await c.getByRole("button", { name: "Claim assigned draft" }).focus();
        await p.keyboard.press("Enter");
        await c.locator("[name=transaction_id]").waitFor();
        assert.equal(
          await c.evaluate((el) => el.contains(document.activeElement)),
          true,
          "Focus after successful claim",
        );
        const staff = await go("service_agent", "case-synchronization");
        await staff.locator("[data-v8-refresh]").focus();
        await staff.keyboard.press("Enter");
        await staff.locator("[data-page-feedback][data-feedback-kind=success]").waitFor();
        assert.equal(
          await staff
            .locator("[data-v8-refresh]")
            .evaluate((el) => el === document.activeElement),
          true,
          "Focus after monitor refresh",
        );
      },
    );
    await test(
      "Support progress remains within a narrow mobile viewport",
      "Open persisted progress records at 375px",
      "Case identifiers and progress metadata wrap without document-wide horizontal scrolling",
      async () => {
        const p = await go("requester", "support-requests");
        await p.setViewportSize({ width: 375, height: 900 });
        assert.ok(
          await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 2),
        );
        await shot(p, "09-progress-mobile.png");
        await p.setViewportSize({ width: 1440, height: 1050 });
      },
    );
    await test(
      "Manual refresh keeps filter/search selections and shows truthful receipt provenance",
      "Filter to SYNCED, refresh actual native view, inspect recorded-receipt note",
      "Selections persist; records do not claim verified live Zapier/Google execution",
      async () => {
        const p = await go("service_agent", "case-synchronization");
        await p.locator("[data-sync-filter]").selectOption("SYNCED");
        await p.locator("[data-case-search]").fill("v6-");
        await p.locator("[data-v8-refresh]").click();
        await p.locator("[data-page-feedback][data-feedback-kind=success]").waitFor();
        assert.equal(await p.locator("[data-sync-filter]").inputValue(), "SYNCED");
        assert.equal(await p.locator("[data-case-search]").inputValue(), "v6-");
        assert.match(
          await p.locator("[data-v8-root]").innerText(),
          /does not independently verify a live Zapier or Google run/,
        );
        assert.ok((await p.locator(".v7-sync:visible").count()) > 0);
      },
    );
    await test(
      "Repeated page entry produces no unhandled JavaScript errors",
      "Enter each integrated page repeatedly in authenticated sessions",
      "Zero pageerror events and no unexpected non-injected console errors",
      async () => {
        const p = await page("requester");
        for (let i = 0; i < 2; i++)
          for (const view of ["support-inbox", "support-requests", "case-synchronization"])
            await p.goto(APP_URL + "/page/" + view);
        assert.deepEqual(errors, []);
        const unexpected = consoleErrors.filter(
          (e) =>
            !/(Failed to load resource.*(403|409|500|503)|net::ERR_ABORTED)/.test(e.message),
        );
        assert.deepEqual(unexpected, []);
        return {
          page_errors: errors.length,
          expected_fault_injection_console_errors: consoleErrors.length,
        };
      },
    );
    await test(
      "Financial records are unchanged by all support UI operations",
      "Compare original account and transaction rows after all cases",
      "Every original account balance and transaction value is identical",
      async () => {
        assert.deepEqual(
          (await db.query("SELECT * FROM accounts ORDER BY id")).rows,
          accountsBefore,
        );
        assert.deepEqual(
          (await db.query("SELECT * FROM transactions ORDER BY id")).rows,
          transactionsBefore,
        );
      },
    );
  } finally {
    await browser.close();
    await db.close();
    const report = {
      time: new Date().toISOString(),
      round,
      kind: "Actual local native application browser tests. HTTP errors/delays and synthetic display fixtures are labelled per test. No real Zapier/Google execution.",
      results,
      page_errors: errors,
      console_errors: consoleErrors,
    };
    fs.writeFileSync(
      path.join(output, "browser-results.json"),
      JSON.stringify(report, null, 2),
    );
    console.log(
      "Results: " +
        results.filter((t) => t.status === "Pass").length +
        " Pass, " +
        results.filter((t) => t.status === "Fail").length +
        " Fail",
    );
    if (results.some((t) => t.status === "Fail")) process.exitCode = 1;
  }
})().catch((e) => {
  console.error(e.stack);
  process.exit(1);
});
