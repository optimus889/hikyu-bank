const test = require("node:test"),
  assert = require("node:assert/strict");
const P = require("../../../frontend/progress.cjs"),
  I = require("../../../frontend/inbox.cjs"),
  M = require("../../../frontend/monitor.cjs"),
  C = require("../../../frontend/common.cjs");
const req = { csrfToken: () => "synthetic-unit-placeholder" },
  base = {
    id: 1,
    business_id: "v6-synthetic",
    state: "SERVICE_REVIEW",
    sequence: 2,
    created_at: "2026-11-10T10:00:00Z",
    updated_at: "2026-11-10T10:01:00Z",
    current_role: "service_agent",
    last_comment: "Synthetic latest comment",
  };
for (const state of Object.keys(P.STAGES))
  test("Progress: " + state, () => {
    const html = P.render({ ...base, state });
    assert.ok(html.includes('data-stage="' + state + '"'));
    assert.ok(html.includes(P.STAGES[state].label));
    assert.ok(html.includes("Earlier stage history"));
    assert.equal((html.match(/<li[ >]/g) || []).length, 2);
    assert.equal(P.model({ ...base, state }).kind === "final", state === "COMPLETED");
  });
test("Unknown state stays neutral and escapes all text", () => {
  const html = P.render({
    ...base,
    state: "<script>unknown</script>",
    last_comment: "<img src=x onerror=alert(1)>",
  });
  assert.ok(html.includes('data-stage-kind="unknown"'));
  assert.ok(html.includes("Completion cannot be confirmed"));
  assert.ok(!html.includes("<img"));
  assert.ok(!html.includes("<script>"));
  assert.ok(!html.includes("Final outcome:"));
});
test("Missing and invalid timestamps never become epoch or invented history", () => {
  const html = P.render({ ...base, created_at: null, updated_at: "invalid" });
  assert.equal((html.match(/Not available/g) || []).length, 1);
  assert.equal((html.match(/<li[ >]/g) || []).length, 1);
  assert.ok(html.includes("No creation timestamp"));
  assert.ok(!html.includes("<time"));
  assert.ok(!html.includes("1970"));
  assert.equal(C.time(""), "<span>Not available</span>");
});
test("Draft renderer keeps native CSRF, versions, field labels, limits and escaping", () => {
  const html = I.render({
    name: "V7_inbox",
    req,
    actor: { id: 10 },
    staff: false,
    requester: true,
    targets: [],
    transactions: [{ id: 1, name: "Synthetic owned transaction" }],
    rows: [
      {
        id: 2,
        subject: "<script>bad</script>",
        description: "Synthetic issue",
        draft_status: "CLAIMED",
        claimed_by: 10,
        assigned_user_id: 10,
        draft_version: 3,
      },
    ],
  });
  assert.ok(html.includes('name="_csrf"'));
  assert.ok(html.includes('name="expected_version" value="3"'));
  assert.ok(html.includes('maxlength="2000"'));
  assert.ok(html.includes('minlength="3"'));
  assert.ok(html.includes('value="">Choose one'));
  assert.ok(html.includes('for="v8-draft-2-description"'));
  assert.ok(!html.includes("<script>bad"));
});
test("Monitor states scope and receipt provenance honestly; ordinary user has no replay", () => {
  const html = M.render({
    name: "V7_sync",
    req,
    staff: false,
    rows: [
      {
        case_id: "<x>",
        sync_status: "SYNCED",
        business_state: "COMPLETED",
        job_status: "ACKNOWLEDGED",
      },
    ],
    transport: {},
    monitor: {},
    stats: [],
    events: [],
  });
  assert.ok(html.includes("up to 100 records loaded"));
  assert.ok(html.includes("not independently verified"));
  assert.ok(html.includes("does not independently verify"));
  assert.ok(!html.includes("Replay outcome safely"));
  assert.ok(!html.includes("<x>"));
});
test("Scoped stylesheet never declares an unqualified body selector", () => {
  const fs = require("fs"),
    path = require("path"),
    css = fs.readFileSync(path.join(__dirname, "../../../frontend/styles.css"), "utf8");
  assert.ok(!/(^|\})\s*(body|html|button|input)\s*[{,]/.test(css));
  assert.ok(css.includes(":focus-visible"));
});

test("Valid creation with missing current timestamp displays only sourced time", () => {
  const html = P.render({ ...base, updated_at: null });
  assert.equal((html.match(/<li[ >]/g) || []).length, 2);
  assert.equal((html.match(/<time/g) || []).length, 1);
  assert.ok(html.includes('data-complete-history="unavailable"'));
});
