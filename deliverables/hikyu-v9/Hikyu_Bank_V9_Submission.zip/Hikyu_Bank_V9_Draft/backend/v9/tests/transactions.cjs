const assert = require("node:assert/strict");
const fs = require("node:fs");
const crypto = require("node:crypto");
const { chromium } = require("playwright");
const { APP_URL, ROOT } = require("../../v8/runtime.cjs");
const { db } = require("../../saltcorn/sdk.cjs");

async function main() {
  const accounts = JSON.parse(fs.readFileSync(ROOT + "/private/saltcorn-accounts.json"));
  const owner = accounts.find(a => a.key === "requester");
  const other = accounts.find(a => a.key === "other_requester");
  const tag = "V9 " + crypto.randomUUID().slice(0, 10);
  const inserted = [];
  let browser;
  const checks = [];
  function pass(label) {
    checks.push(label);
    console.log("PASS " + label);
  }

  async function seed(user, name, date, kind, copies = 1) {
    const account = (await db.query("SELECT id FROM accounts WHERE owner_id=$1 LIMIT 1", [user.id])).rows[0];
    const result = await db.query(
      `INSERT INTO transactions(owner_id,account_id,name,category,posted_date,amount_cents,kind)
       SELECT $1,$2,$3,'Other',$4,0,$5 FROM generate_series(1,$6::int) RETURNING id`,
      [user.id, account.id, name, date, kind, copies],
    );
    inserted.push(...result.rows.map(row => row.id));
    return result.rows[0].id;
  }

  try {
    const match = tag + " Café%_";
    const inRange = await seed(owner, match, "2025-01-02T23:59:59Z", "expense");
    await seed(owner, tag + " Cafe normal", "2025-01-02T10:00:00Z", "expense");
    await seed(owner, match + " midnight", "2025-01-03T00:00:00Z", "expense");
    await seed(owner, match + " income", "2025-01-02T12:00:00Z", "income");
    await seed(other, match + " foreign", "2025-01-02T12:00:00Z", "expense");
    await seed(owner, tag + " Recent", "2025-03-03T12:00:00Z", "expense", 105);
    const before = (await db.query("SELECT * FROM transactions WHERE id = ANY($1::int[]) ORDER BY id", [inserted])).rows;
    assert.ok(before.some(row => row.id === inRange));

    browser = await chromium.launch({
      executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium",
      args: ["--no-sandbox"],
    });
    const page = await browser.newPage({ viewport: { width: 375, height: 900 } });
    const endpoint = "/hikyu-v9/transactions";
    const authless = await page.request.get(APP_URL + endpoint);
    assert.equal(authless.status(), 401);
    pass("Unauthenticated JSON request returns 401");

    const browserErrors = [];
    page.on("pageerror", error => browserErrors.push(error.message));
    await page.goto(APP_URL + "/auth/login");
    await page.locator("[name=email]").fill(owner.email);
    await page.locator("[name=password]").fill(owner.password);
    await page.locator("button[type=submit]").click();
    await page.goto(APP_URL + "/page/transactions");
    const panel = page.locator(".v9-transactions");
    const status = panel.getByRole("status");
    const rows = panel.locator("tbody tr");

    async function waitStatus(pattern) {
      await status.filter({ hasText: pattern }).waitFor();
    }
    await waitStatus(/Page 1 · 25/);
    assert.equal(await rows.count(), 25);
    await panel.getByRole("button", { name: "Next" }).click();
    await waitStatus(/Page 2 · 25/);
    await panel.getByRole("button", { name: "Previous" }).click();
    await waitStatus(/Page 1 · 25/);
    pass("Live Transactions page loads and pages through the owned ledger");

    await panel.getByLabel("Start date").fill("2025-01-02");
    await panel.getByLabel("End date").fill("2025-01-02");
    await panel.getByLabel("Transaction type").selectOption("expense");
    await panel.getByLabel("Keyword").fill((tag + " CAFÉ%_").toUpperCase());
    await panel.getByLabel("Keyword").focus();
    await page.keyboard.press("Enter");
    await waitStatus(/1 transaction shown/);
    assert.equal(await rows.count(), 1);
    assert.equal(await rows.first().locator("td").first().innerText(), match);
    pass("Keyboard submit combines UTC dates, type and literal case-insensitive keyword beyond newest 100 rows");

    await panel.getByLabel("End date").fill("2025-01-01");
    await panel.getByRole("button", { name: "Apply filters" }).click();
    await panel.getByRole("alert").filter({ hasText: "End date must be on or after start date." }).waitFor();
    assert.equal(await panel.getByLabel("End date").getAttribute("aria-invalid"), "true");
    pass("Reversed dates show an associated error");

    const invalid = await page.request.get(APP_URL + endpoint + "?from=2025-02-30");
    assert.equal(invalid.status(), 400);
    for (const query of ["?type=bad", "?page=0", "?q=a&q=b"]) {
      assert.equal((await page.request.get(APP_URL + endpoint + query)).status(), 400);
    }
    const foreign = await page.request.get(APP_URL + endpoint, {
      params: { q: match + " foreign", owner_id: String(other.id) },
    });
    assert.equal(foreign.status(), 200);
    assert.deepEqual((await foreign.json()).rows, []);
    pass("Server rejects invalid filter input and enforces session ownership");

    await panel.getByLabel("End date").fill("2025-01-02");
    await page.route("**/hikyu-v9/transactions?*", async route => {
      await route.fulfill({ status: 503, json: { error: "Synthetic outage. Try again." } });
    }, { times: 1 });
    await panel.getByRole("button", { name: "Apply filters" }).click();
    await panel.getByRole("alert").filter({ hasText: "Synthetic outage" }).waitFor();
    assert.match(await panel.getByLabel("Keyword").inputValue(), /CAFÉ%_/);
    await panel.getByRole("button", { name: "Retry" }).click();
    await waitStatus(/1 transaction shown/);
    pass("Injected HTTP failure retains filters and retry reaches the real API");

    await panel.getByLabel("Keyword").fill("No matches " + tag);
    await panel.getByRole("button", { name: "Apply filters" }).click();
    await waitStatus(/No transactions match/);
    await panel.getByRole("button", { name: "Clear filters" }).click();
    await waitStatus(/Page 1 · 25/);
    assert.equal(await panel.getByLabel("Keyword").inputValue(), "");
    pass("Empty results and reset return to the expected states");

    assert.ok(await panel.evaluate(el => el.scrollWidth <= el.clientWidth + 2));
    await panel.getByLabel("Keyword").focus();
    await page.keyboard.press("Tab");
    assert.equal(await page.evaluate(() => document.activeElement.textContent), "Apply filters");
    assert.deepEqual(browserErrors, []);
    pass("Mobile panel fits, Tab reaches Apply filters, and no page errors occur");

    const after = (await db.query("SELECT * FROM transactions WHERE id = ANY($1::int[]) ORDER BY id", [inserted])).rows;
    assert.deepEqual(after, before);
    pass("Filtering leaves synthetic transaction rows unchanged");
    console.log(`PASS ${checks.length} V9 integration checks`);
  } finally {
    if (browser) await browser.close();
    if (inserted.length) await db.query("DELETE FROM transactions WHERE id = ANY($1::int[])", [inserted]);
    await db.close();
  }
}

main().catch(error => { console.error(error); process.exitCode = 1; });
