const PAGE_SIZE = 25;
const TYPES = Object.freeze({
  income: "Income",
  expense: "Expense",
  transfer: "Transfer",
  peer_transfer: "Peer transfer",
  credit_payment: "Credit payment",
});

class InvalidFilters extends Error {}

function readText(query, key) {
  const value = query[key];
  if (value === undefined) return "";
  if (typeof value !== "string") throw new InvalidFilters("Provide one value per filter.");
  return value.trim();
}

function readDate(query, key, label) {
  const value = readText(query, key);
  if (!value) return "";
  const time = Date.parse(value);
  if (!/^(?!0000)\d{4}-\d{2}-\d{2}$/.test(value) ||
      !Number.isFinite(time) || new Date(time).toISOString().slice(0, 10) !== value) {
    throw new InvalidFilters(`${label} must be a valid date.`);
  }
  return value;
}

function transactionQuery(ownerId, query) {
  const from = readDate(query, "from", "Start date");
  const to = readDate(query, "to", "End date");
  const type = readText(query, "type");
  const keyword = readText(query, "q");
  const page = readText(query, "page") || "1";

  if (from && to && from > to) throw new InvalidFilters("End date must be on or after start date.");
  if (type && !Object.hasOwn(TYPES, type)) throw new InvalidFilters("Choose a listed transaction type.");
  if (keyword.length > 100 || keyword.includes("\0")) {
    throw new InvalidFilters("Enter a keyword of up to 100 characters without null characters.");
  }
  if (!/^[1-9]\d{0,7}$/.test(page)) throw new InvalidFilters("Page must be a positive integer.");

  const params = [ownerId];
  const bind = value => {
    params.push(value);
    return "$" + params.length;
  };
  const clauses = ["owner_id = $1"];
  if (from) clauses.push(`posted_date >= (${bind(from)}::date::timestamp AT TIME ZONE 'UTC')`);
  if (to) clauses.push(`posted_date < ((${bind(to)}::date + interval '1 day') AT TIME ZONE 'UTC')`);
  if (type) clauses.push(`kind = ${bind(type)}`);
  if (keyword) {
    const term = bind(keyword);
    clauses.push(`(strpos(lower(name), lower(${term})) > 0 OR strpos(lower(category), lower(${term})) > 0)`);
  }
  return {
    sql: `SELECT name, category, kind, amount_cents, to_char(posted_date AT TIME ZONE 'UTC', 'YYYY-MM-DD') AS date
          FROM transactions WHERE ${clauses.join(" AND ")}
          ORDER BY posted_date DESC NULLS LAST, id DESC
          LIMIT ${bind(PAGE_SIZE + 1)} OFFSET ${bind((Number(page) - 1) * PAGE_SIZE)}`,
    params,
    page: Number(page),
  };
}

module.exports = { transactionQuery, InvalidFilters, PAGE_SIZE, TYPES };
