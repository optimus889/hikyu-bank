const fs = require("node:fs");
const path = require("node:path");
const { transactionQuery, InvalidFilters, PAGE_SIZE, TYPES } = require("./filters.cjs");

const frontend = path.resolve(__dirname, "../../frontend/v9");
const PREFIX = "/hikyu-v9";
const assets = [
  ["transactions.css", "text/css"],
  ["transactions.js", "text/javascript"],
];

function routes(db) {
  return [
    ...assets.map(([file, type]) => ({
      method: "get",
      url: `${PREFIX}/${file}`,
      callback: (_req, res) => res.type(type).sendFile(path.join(frontend, file)),
    })),
    {
      method: "get",
      url: `${PREFIX}/transactions`,
      callback: async (req, res) => {
        res.set("Cache-Control", "private, no-store");
        if (!req.user?.id) return res.status(401).json({ error: "Sign in to view your transactions." });
        try {
          const { sql, params, page } = transactionQuery(req.user.id, req.query);
          const { rows } = await db.query(sql, params);
          return res.json({ rows: rows.slice(0, PAGE_SIZE), page, hasNext: rows.length > PAGE_SIZE });
        } catch (error) {
          if (error instanceof InvalidFilters) return res.status(400).json({ error: error.message });
          return res.status(500).json({ error: "Transactions could not be loaded. Try again." });
        }
      },
    },
  ];
}

function render() {
  const html = fs.readFileSync(path.join(frontend, "transactions.html"), "utf8");
  const choices = Object.entries(TYPES).map(([value, label]) => `<option value="${value}">${label}</option>`);
  return html.replace("<!-- transaction type options -->", choices.join(""));
}

module.exports = { routes, render };
