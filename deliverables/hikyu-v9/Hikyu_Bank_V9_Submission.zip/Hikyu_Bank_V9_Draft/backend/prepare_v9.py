#!/usr/bin/env python3
"""Start the standalone V9 demo with its own generated configuration."""
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent.parent
args = sys.argv[1:]
if args not in ([], ['--start-only'], ['--check']):
    raise SystemExit('Usage: prepare_v9.py [--check | --start-only]')

if args == ['--check']:
    for name in ('frontend/v9/transactions.html', 'frontend/v9/transactions.js', 'frontend/v9/transactions.css',
                 'backend/v9/transactions.cjs', 'backend/v9/filters.cjs'):
        if not (root / name).is_file():
            raise SystemExit('Missing V9 file: ' + name)
else:
    private = root / 'private'
    private.mkdir(exist_ok=True, mode=0o700)
    runtime = private / 'v8-runtime.json'
    if not runtime.exists():
        if (private / 'saltcorn-env.json').exists():
            raise SystemExit('Extract V9 to a separate directory for a fresh local installation.')
        runtime.write_text(json.dumps({'app_port': 8497, 'workflow_port': 8496}))
        runtime.chmod(0o600)
    (root / 'evidence').mkdir(exist_ok=True)

env = {
    **os.environ,
    'HIKYU_SITE_NAME': 'Hikyu Bank V9',
    'V6_DB_PORT': os.environ.get('V6_DB_PORT', '55606'),
}
subprocess.run([sys.executable, str(root / 'backend/prepare_v8.py'), *args], env=env, check=True)
if args != ['--check']:
    port = json.loads(runtime.read_text())['app_port']
    print(f'V9 Transactions: http://127.0.0.1:{port}/page/transactions')
