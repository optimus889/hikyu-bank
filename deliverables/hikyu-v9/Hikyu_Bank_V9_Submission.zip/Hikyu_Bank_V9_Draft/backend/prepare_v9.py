#!/usr/bin/env python3
"""Prepare or restart a standalone V9 demo."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
PRIVATE = ROOT / "private"
RUNTIME = PRIVATE / "v8-runtime.json"
READY = PRIVATE / "v9-ready.json"
REQUIRED_SOURCE = (
    "frontend/v9/transactions.html",
    "frontend/v9/transactions.js",
    "frontend/v9/transactions.css",
    "backend/v9/transactions.cjs",
    "backend/v9/filters.cjs",
)
STARTUP_FILES = (
    "private/saltcorn-env.json",
    "private/roles.json",
    "private/saltcorn-accounts.json",
    "private/v7-integration.json",
    "private/start-workflow.sh",
    "backend/saltcorn/node_modules/.bin/saltcorn",
    "backend/workflow/target/classes/demo/WorkflowServer.class",
    "backend/workflow/classpath.txt",
)


def run(script, env, *args):
    subprocess.run([sys.executable, str(ROOT / "backend" / script), *args], env=env, check=True)


def setup_signature():
    """Track files that affect installation, native metadata and compiled code."""
    paths = [
        ROOT / "backend" / name
        for name in (
            "prepare_v6.py",
            "prepare_v7.py",
            "prepare_v8.py",
            "prepare_v9.py",
            "local_db_auth.py",
            "compose.v6.yaml",
            "workflow/pom.xml",
            "workflow/mvnw",
            "workflow/.mvn/wrapper/maven-wrapper.properties",
            "saltcorn/package.json",
            "saltcorn/package-lock.json",
            "saltcorn/bootstrap.cjs",
            "saltcorn/setup-support.cjs",
            "saltcorn/setup-banking.cjs",
            "saltcorn/protect.cjs",
            "v7/setup-v7.cjs",
            "v8/setup-v8.cjs",
            "ai/local_classifier.py",
        )
    ]
    for folder in ("backend/saltcorn/hikyu-plugin", "backend/workflow/src"):
        paths.extend(path for path in (ROOT / folder).rglob("*") if path.is_file())
    digest = hashlib.sha256()
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode() + b"\0")
        digest.update(hashlib.sha256(path.read_bytes()).digest())
    for command in (["node", "--version"], ["npm", "--version"]):
        digest.update(subprocess.check_output(command))
    return digest.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--check", action="store_true", help="check source files only")
    mode.add_argument(
        "--start-only", action="store_true", help="start a completed installation"
    )
    mode.add_argument("--rebuild", action="store_true", help="run full setup again")
    mode.add_argument(
        "--repair-db-auth",
        action="store_true",
        help="align the existing local V9 database password",
    )
    args = parser.parse_args()

    for filename in REQUIRED_SOURCE:
        if not (ROOT / filename).is_file():
            raise SystemExit("Missing V9 file: " + filename)
    env = {
        **os.environ,
        "HIKYU_SITE_NAME": "Hikyu Bank V9",
        "HIKYU_DATABASE": "saltcorn_v8",
        "HIKYU_COMPOSE_PREFIX": "hikyu-v8",
        "V6_DB_PORT": os.environ.get("V6_DB_PORT", "55606"),
    }
    if args.check:
        run("prepare_v8.py", env, "--check")
        print("V9 source check passed. Use python3 backend/prepare_v9.py to start the app.")
        return

    if args.repair_db_auth:
        if not RUNTIME.is_file():
            raise SystemExit(
                "Run this command from the original V9 folder with its private configuration."
            )
        run("prepare_v6.py", env, "--repair-db-auth")
        return

    missing = [name for name in STARTUP_FILES if not (ROOT / name).is_file()]
    if args.start_only and (missing or not RUNTIME.is_file()):
        raise SystemExit(
            "Setup is incomplete. Run python3 backend/prepare_v9.py first. "
            f'Missing: {", ".join(missing or [str(RUNTIME.relative_to(ROOT))])}'
        )

    PRIVATE.mkdir(exist_ok=True, mode=0o700)
    if not RUNTIME.exists():
        if (PRIVATE / "saltcorn-env.json").exists():
            raise SystemExit(
                "Extract V9 to a separate directory for a fresh local installation."
            )
        with open(RUNTIME, "x", opener=opener_private) as file:
            json.dump({"app_port": 8497, "workflow_port": 8496}, file)
    signature = None if args.start_only else setup_signature()
    ready = READY.read_text().strip() if READY.is_file() else None
    if args.start_only or (not args.rebuild and not missing and ready == signature):
        print(
            "V9: starting existing database and services. Skipping npm and Maven.", flush=True
        )
        run("prepare_v6.py", env, "--start-only")
    else:
        READY.unlink(missing_ok=True)
        print(
            "V9: full setup. First-time dependency downloads may take several minutes.",
            flush=True,
        )
        run("prepare_v8.py", env)
        with open(READY, "w", opener=opener_private) as file:
            file.write(signature + "\n")
    port = json.loads(RUNTIME.read_text())["app_port"]
    print(f"V9 Transactions: http://127.0.0.1:{port}/page/transactions", flush=True)


def opener_private(path, flags):
    return os.open(path, flags, 0o600)


if __name__ == "__main__":
    try:
        main()
    except subprocess.CalledProcessError as error:
        sys.exit(error.returncode)
    except FileNotFoundError as error:
        sys.exit(f"V9 could not find a required command or file: {error.filename}")
