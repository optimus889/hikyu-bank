const { chromium } = require("playwright"),
  fs = require("fs"),
  assert = require("assert/strict"),
  crypto = require("crypto");
const { init, db } = require("./sdk.cjs");
const ROOT = require("path").resolve(__dirname, "../..");
(async () => {
  await init();
  const accounts = JSON.parse(fs.readFileSync(ROOT + "/private/saltcorn-accounts.json")),
    a = accounts.find((x) => x.key === "requester"),
    other = accounts.find((x) => x.key === "other_requester");
  const ac = (
      await db.query("SELECT * FROM accounts WHERE owner_id=$1 AND account_type='checking'", [
        a.id,
      ])
    ).rows[0],
    foreign = (
      await db.query("SELECT * FROM accounts WHERE owner_id=$1 AND account_type='checking'", [
        other.id,
      ])
    ).rows[0];
  const marker = "CSV-other-" + crypto.randomUUID();
  for (const [owner, account, name, note] of [
    [a.id, ac.id, "=1+1", "+synthetic formula"],
    [other.id, foreign.id, marker, "Private to another synthetic user"],
  ])
    await db.query(
      "INSERT INTO transactions(owner_id,source_v5_id,account_id,name,category,posted_date,amount_cents,kind,note) VALUES($1,$2,$3,$4,'Other',now(),0,'expense',$5)",
      [owner, crypto.randomUUID(), account, name, note],
    );
  const b = await chromium.launch({
      executablePath: "/usr/bin/chromium",
      args: ["--no-sandbox"],
    }),
    p = await b.newPage();
  let results = [];
  try {
    await p.goto(require("../v8/runtime.cjs").APP_URL + "/auth/login");
    await p.locator("[name=email]").fill(a.email);
    await p.locator("[name=password]").fill(a.password);
    await p.locator("button[type=submit]").click();
    await p.goto(require("../v8/runtime.cjs").APP_URL + "/page/transactions");
    const today = new Date().toISOString().slice(0, 10);
    const post = async (body) =>
      p.evaluate(async (body) => {
        const r = await fetch("/view/V6_Banking_transactions", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: new URLSearchParams({
            ...body,
            command: "statement",
            _csrf: document.querySelector("[name=_csrf]")?.value || window._sc_globalCsrf,
          }),
        });
        return { status: r.status, type: r.headers.get("content-type"), body: await r.text() };
      }, body);
    let r = await post({ from: today, to: today });
    assert.equal(r.status, 200);
    assert.match(r.type, /text\/csv/);
    assert.match(r.body, /Date,Name,Category,Amount/);
    results.push({
      test: "Real LCNC CSV endpoint exports inclusive UTC date data",
      status: "Pass",
    });
    assert.ok(r.body.includes('"\'=1+1"'));
    assert.ok(r.body.includes('"\'+synthetic formula"'));
    results.push({ test: "CSV text formula injection is neutralized", status: "Pass" });
    assert.ok(!r.body.includes(marker));
    results.push({ test: "Other user transaction is excluded from export", status: "Pass" });
    for (const dates of [
      { from: "", to: today },
      { from: "2026-02-30", to: today },
      { from: "2020-01-01", to: today },
    ]) {
      const r = await post(dates);
      assert.equal(r.status, 400);
    }
    results.push({
      test: "Blank, invalid and excessive statement date ranges rejected",
      status: "Pass",
    });
    r = await post({ from: today, to: today, account_id: foreign.id });
    assert.equal(r.status, 403);
    results.push({ test: "CSV export rejects a foreign account", status: "Pass" });
    fs.writeFileSync(
      ROOT + "/evidence/lcnc-csv-tests.json",
      JSON.stringify(
        {
          kind: "Real LCNC endpoint and browser; zero-value synthetic CSV fixtures",
          results,
          time: new Date().toISOString(),
        },
        null,
        2,
      ),
    );
    console.log("PASS " + results.length + " CSV checks");
  } finally {
    await b.close();
    await db.close();
  }
})().catch((e) => {
  console.error(e.stack);
  process.exit(1);
});
