const { chromium } = require("playwright"),
  fs = require("fs"),
  assert = require("assert/strict"),
  crypto = require("crypto"),
  { spawnSync } = require("child_process");
const { init, db, Table, User } = require("./sdk.cjs");
const integration = require("./integration.cjs");
const ROOT = require("path").resolve(__dirname, "../.."),
  accounts = JSON.parse(fs.readFileSync(ROOT + "/private/saltcorn-accounts.json"));
(async () => {
  await init();
  const b = await chromium.launch({
    executablePath: "/usr/bin/chromium",
    headless: true,
    args: ["--no-sandbox"],
  });
  const pages = {},
    results = [];
  async function page(key) {
    if (!pages[key]) {
      const c = await b.newContext(),
        p = await c.newPage(),
        a = accounts.find((x) => x.key === key);
      await p.goto(require("../v8/runtime.cjs").APP_URL + "/auth/login");
      await p.locator("[name=email]").fill(a.email);
      await p.locator("[name=password]").fill(a.password);
      await p.locator("button[type=submit]").click();
      pages[key] = p;
    }
    await pages[key].goto(require("../v8/runtime.cjs").APP_URL + "/page/support-requests");
    return pages[key];
  }
  async function post(key, data) {
    const p = await page(key);
    return p.evaluate(async (data) => {
      const r = await fetch("/view/V6_Support_Workflow", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          Accept: "application/json",
        },
        body: new URLSearchParams({
          ...data,
          _csrf: document.querySelector("[name=_csrf]")?.value || window._sc_globalCsrf,
        }),
      });
      return { status: r.status, body: await r.json() };
    }, data);
  }
  async function submit() {
    const p = await page("requester");
    const txn = await p.locator("[name=transaction_id]").first().inputValue();
    const bid = "v6-" + crypto.randomUUID();
    const r = await post("requester", {
      command: "submit",
      business_id: bid,
      transaction_id: txn,
      description: "My payment receipt is missing",
    });
    assert.equal(r.status, 200);
    return r.body.result;
  }
  async function row(id) {
    return (await db.query("SELECT * FROM support_requests WHERE id=$1", [id])).rows[0];
  }
  async function decision(key, r, choice, extras = {}) {
    return post(key, {
      command: "decide",
      id: r.id,
      expected_sequence: r.sequence,
      decision: choice,
      comment: "Synthetic resilience test",
      ...extras,
    });
  }
  async function until(id, state) {
    for (let i = 0; i < 50; i++) {
      const r = await row(id);
      if (r.state === state) return r;
      await new Promise((ok) => setTimeout(ok, 400));
    }
    throw new Error("State did not converge to " + state);
  }
  const record = (test, extra = {}) => results.push({ test, status: "Pass", ...extra });
  try {
    let r = await submit();
    let x = await decision("service_agent", r, "return");
    assert.equal(x.status, 200);
    r = await row(r.id);
    assert.equal(r.state, "RETURNED");
    x = await decision("requester", r, "continue", {
      description: "The synthetic transfer receipt is missing from history",
    });
    assert.equal(x.status, 200);
    r = await row(r.id);
    assert.equal(r.state, "SERVICE_REVIEW");
    x = await decision("service_agent", r, "reject");
    assert.equal(x.status, 200);
    r = await row(r.id);
    assert.equal(r.state, "REJECTED");
    record("Real LCNC return, requester resubmission and rejection", {
      business_id: r.business_id,
    });
    r = await submit();
    const stale = r.sequence;
    x = await decision("reviewer", r, "complete");
    assert.equal(x.status, 403);
    x = await decision("service_agent", r, "continue");
    assert.equal(x.status, 200);
    r = await row(r.id);
    x = await decision("reviewer", { ...r, sequence: stale }, "complete");
    assert.equal(x.status, 409);
    x = await decision("reviewer", r, "complete");
    assert.equal(x.status, 200);
    record("Incorrect role and stale decision versions rejected on live LCNC path");
    const requester = await User.findOne({
      id: accounts.find((x) => x.key === "requester").id,
    });
    const final = await row(r.id);
    await Table.findOne("support_requests").updateRow(
      { state: "SERVICE_REVIEW", sequence: 0 },
      r.id,
      requester,
    );
    assert.equal((await row(r.id)).state, "COMPLETED");
    record("Native field permissions block direct user status tampering", {
      kind: "Native model permission check against live database",
    });
    try {
      await integration.apply(r.id, {
        business_id: r.business_id,
        process_instance_id: final.process_instance_id,
        stage: "agentReview",
        sequence: 2,
      });
      throw new Error("Late projection accepted");
    } catch (e) {
      assert.equal(e.code, 409);
    }
    assert.equal((await row(r.id)).state, "COMPLETED");
    record("Late non-final projection cannot overwrite a final LCNC record", {
      kind: "Writeback component against live database",
    });
    const pids = JSON.parse(fs.readFileSync(ROOT + "/private/service-pids.json"));
    process.kill(-pids.workflow, "SIGTERM");
    await new Promise((ok) => setTimeout(ok, 500));
    r = await submit();
    assert.equal(r.state, "SUBMITTED");
    assert.ok(r.integration_error);
    record("Actual stopped workflow API leaves durable submitted record with pending retry", {
      business_id: r.business_id,
    });
    let restarted = spawnSync("python3", [ROOT + "/backend/start-services.py"], {
      encoding: "utf8",
      timeout: 25000,
    });
    assert.equal(restarted.status, 0);
    r = await until(r.id, "SERVICE_REVIEW");
    assert.ok(r.process_instance_id);
    record("Automatic retry recovers after actual workflow API restart", {
      business_id: r.business_id,
      process_instance_id: r.process_instance_id,
    });
    r = await submit();
    await db.query(
      `ALTER TABLE support_requests ADD CONSTRAINT v6_test_callback_failure CHECK(id<>${r.id} OR state<>'REVIEWER_REVIEW') NOT VALID`,
    );
    try {
      x = await decision("service_agent", r, "continue");
      assert.equal(x.status, 503);
      assert.equal((await row(r.id)).state, "SERVICE_REVIEW");
      const actual = await integration.wf("/requests/" + r.process_instance_id);
      assert.equal(actual.stage, "reviewerReview");
      record("Actual PostgreSQL callback constraint failure preserves committed engine task", {
        business_id: r.business_id,
      });
    } finally {
      await db.query(
        "ALTER TABLE support_requests DROP CONSTRAINT IF EXISTS v6_test_callback_failure",
      );
    }
    r = await until(r.id, "REVIEWER_REVIEW");
    x = await decision("reviewer", r, "complete");
    assert.equal(x.status, 200);
    const complete = await row(r.id);
    assert.equal(complete.state, "COMPLETED");
    record("Automatic status writeback recovers after real database write failure", {
      business_id: r.business_id,
      sequence: complete.sequence,
    });
    const ids = JSON.parse(fs.readFileSync(ROOT + "/private/service-pids.json"));
    process.kill(-ids.saltcorn, "SIGTERM");
    await new Promise((ok) => setTimeout(ok, 500));
    restarted = spawnSync("python3", [ROOT + "/backend/start-services.py"], {
      encoding: "utf8",
      timeout: 25000,
    });
    assert.equal(restarted.status, 0);
    const persisted = await row(r.id);
    assert.equal(persisted.state, complete.state);
    assert.equal(persisted.process_instance_id, complete.process_instance_id);
    assert.equal(persisted.sequence, complete.sequence);
    record("LCNC process restart retains same business ID, engine ID, final state and version");
    const rp = await page("requester");
    assert.match(
      await rp.locator(`article[data-business-id="${r.business_id}"]`).innerText(),
      /COMPLETED/,
    );
    await rp.screenshot({ path: ROOT + "/evidence/lcnc-recovery-refresh.png", fullPage: true });
    record("Browser refresh after LCNC restart shows recovered final state");
    fs.writeFileSync(
      ROOT + "/evidence/lcnc-resilience.json",
      JSON.stringify(
        {
          kind: "Real local platform, engine stop/restart and PostgreSQL fault injection; single-person role simulation",
          results,
          time: new Date().toISOString(),
        },
        null,
        2,
      ),
    );
    console.log("PASS: " + results.length + " resilience and security checks");
  } catch (e) {
    fs.writeFileSync(
      ROOT + "/evidence/lcnc-resilience-failure.json",
      JSON.stringify({ completed: results, error: e.message }, null, 2),
    );
    console.error(e.stack);
    process.exitCode = 1;
  } finally {
    await db
      .query("ALTER TABLE support_requests DROP CONSTRAINT IF EXISTS v6_test_callback_failure")
      .catch(() => {});
    await b.close();
    await db.close();
  }
})();
