const V8_ROOT = process.env.V6_ROOT;
if (!V8_ROOT)
  throw new Error("Start the application through its generated runtime configuration.");
const { db } = require(require("path").join(V8_ROOT, "backend/saltcorn/sdk.cjs")),
  integration = require(require("path").join(V8_ROOT, "backend/saltcorn/integration.cjs")),
  crypto = require("crypto");
const esc = (x) =>
  String(x ?? "").replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
  );
function form(name, req, inner) {
  return /* HTML */ `
    <form method="post" action="/view/${esc(name)}">
      <input type="hidden" name="_csrf" value="${esc(req.csrfToken())}" />
      ${inner}
    </form>
  `;
}
const template = {
  name: "Hikyu Support Review",
  display_state_form: false,
  tableless: true,
  get_state_fields: async () => [],
  configuration_workflow: () => null,
  run: async (t, name, c, state, { req }) => {
    const a = integration.actor(req.user);
    const rows = await integration.visibleRows(req.user);
    let html =
      '<section class="v6-panel"><h2>Transaction Support Review</h2><p>AI categorizes the request. A service agent and an independent reviewer decide the outcome.</p>';
    if (["requester", "other_requester"].includes(a.key)) {
      const transactions = (
        await db.query(
          "SELECT id,name,amount_cents FROM transactions WHERE owner_id=$1 ORDER BY id",
          [req.user.id],
        )
      ).rows;
      html += form(
        name,
        req,
        /* HTML */ `
          <input type="hidden" name="command" value="submit" />
          <input type="hidden" name="business_id" value="v6-${crypto.randomUUID()}" />
          <label>
            Transaction
            <select name="transaction_id" class="form-control" required>
              ${transactions
                .map(
                  (x) => /* HTML */ `
                    <option value="${x.id}">
                      ${esc(x.name)} · USD ${(x.amount_cents / 100).toFixed(2)}
                    </option>
                  `,
                )
                .join("")}
            </select>
          </label>
          <label>
            Description
            <textarea
              name="description"
              minlength="3"
              maxlength="2000"
              class="form-control"
              required
            ></textarea>
          </label>
          <p>
            Use synthetic information only. Do not enter bank credentials or identity documents.
          </p>
          <button class="btn btn-primary" type="submit">Submit support request</button>
        `,
      );
    }
    html += '</section><section class="v6-panel"><h2>Persistent request status</h2>';
    for (const r of rows) {
      html += `
        <article
          class="v6-panel"
          data-business-id="${esc(r.business_id)}"
          data-row-id="${r.id}"
        >
          <h3>${esc(r.business_id)}</h3>
          <p>${esc(r.description)}</p>
          <p>
            <strong>
              Status:
              <span class="support-status">${esc(r.state)}</span>
            </strong>
            · Version ${r.sequence} · Current role: ${esc(r.current_role)}
          </p>
          <p>
            AI category: ${esc(r.ai_category || "Pending")} · Confidence:
            ${esc(r.ai_confidence || "Not available")} · Model:
            ${esc(r.ai_model_version || "Pending")}
          </p>
          <p>
            Process instance: ${esc(r.process_instance_id || "Pending")} · Updated:
            ${esc(r.updated_at)}
          </p>
          <p>Latest comment: ${esc(r.last_comment || "None")}</p>
          ${require(require("path").join(V8_ROOT, "frontend/progress.cjs")).render(
            r,
          )}${r.integration_error
            ? '<p role="alert">Synchronization pending. The server will retry.</p>'
            : ""}
      `;
      const role = a.key === "other_requester" ? "requester" : a.key;
      if (r.current_role === role) {
        let opts =
          r.state === "SERVICE_REVIEW"
            ? [
                ["continue", "Send to reviewer"],
                ["return", "Return for information"],
                ["reject", "Reject"],
              ]
            : ["REVIEWER_REVIEW", "ESCALATED"].includes(r.state)
              ? [
                  ["complete", "Complete"],
                  ["reject", "Reject"],
                ]
              : [["continue", r.state === "RETURNED" ? "Resubmit" : "Send to service review"]];
        html += form(
          name,
          req,
          /* HTML */ `
            <input type="hidden" name="command" value="decide" />
            <input type="hidden" name="id" value="${r.id}" />
            <input type="hidden" name="expected_sequence" value="${r.sequence}" />
            ${r.state === "RETURNED"
              ? /* HTML */ `
                  <label>
                    Revised description
                    <textarea
                      name="description"
                      required
                      minlength="3"
                      maxlength="2000"
                      class="form-control"
                    >${esc(r.description)}</textarea>
                  </label>
                `
              : ""}
            <label>
              Processing comment
              <textarea
                name="comment"
                required
                maxlength="2000"
                class="form-control"
              ></textarea>
            </label>
            <label>
              Decision
              <select name="decision" class="form-control">
                ${opts
                  .map(
                    ([v, l]) => /* HTML */ `
                      <option value="${v}">${l}</option>
                    `,
                  )
                  .join("")}
              </select>
            </label>
            <button class="btn btn-primary" type="submit">Save decision</button>
          `,
        );
      }
      html += "</article>";
    }
    if (!rows.length) html += "<p>No requests are available for your role.</p>";
    return require(require("path").join(V8_ROOT, "frontend/common.cjs")).shell(
      "support",
      html + "</section>",
    );
  },
  runPost: async (t, n, c, s, b, { req, res }) => {
    try {
      const r =
        b.command === "submit"
          ? await integration.submit(req.user, b)
          : b.command === "decide"
            ? await integration.decide(req.user, b)
            : null;
      if (!r) throw new integration.Failure(400, "Unknown command.");
      if (req.get("Accept") === "application/json") {
        res.json({ ok: true, result: r });
      } else res.redirect(303, "/page/support-requests");
    } catch (e) {
      res
        .status(e.code || 500)
        .json({ error: e.code ? e.message : "Support operation failed." });
    }
  },
};
module.exports = {
  sc_plugin_api_version: 1,
  plugin_name: "hikyu-v6-local",
  routes: [
    ...require(require("path").join(V8_ROOT, "backend/v9/transactions.cjs")).routes(db),
    {
      method: "get",
      url: "/favicon.ico",
      callback: (_req, res) =>
        res
          .type("image/svg+xml")
          .set("Cache-Control", "public, max-age=3600")
          .send(
            require("fs").readFileSync(
              require("path").join(V8_ROOT, "frontend/favicon.svg"),
              "utf8",
            ),
          ),
    },
  ],
  viewtemplates: [
    template,
    require(require("path").join(V8_ROOT, "frontend/banking-view.js")),
    require(require("path").join(V8_ROOT, "backend/v7/plugin.cjs")).template,
  ],
};
