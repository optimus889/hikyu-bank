const { db, User } = require("./sdk.cjs"),
  crypto = require("crypto");
const { Failure } = require("./integration.cjs");
const CATEGORIES = [
  "Groceries",
  "Dining",
  "Transport",
  "Shopping",
  "Subscriptions",
  "Utilities",
  "Housing",
  "Health",
  "Entertainment",
  "Other",
];
const BILLERS = {
  electric: ["Demo Electric", "Utilities"],
  internet: ["Demo Internet", "Utilities"],
  water: ["Demo Water", "Utilities"],
  rent: ["Demo Rent", "Housing"],
};
const hash = (s) => crypto.createHash("sha256").update(s).digest("hex");
const money = (s) => {
  s = String(s ?? "").trim();
  if (!/^\d{1,7}(\.\d{1,2})?$/.test(s))
    throw new Failure(400, "Enter a positive amount with at most two decimals.");
  let [a, b = ""] = s.split(".");
  const n = Number(a) * 100 + Number(b.padEnd(2, "0"));
  if (n < 1 || n > 100000000)
    throw new Failure(400, "Amount must be between USD 0.01 and USD 1,000,000.");
  return n;
};
const id = (s) => {
  const n = Number(s);
  if (!Number.isSafeInteger(n) || n < 1) throw new Failure(400, "Choose a valid record.");
  return n;
};
const text = (s, max, required = true) => {
  s = String(s ?? "").trim();
  if ((required && !s) || s.length > max) throw new Failure(400, "Invalid or missing text.");
  return s;
};
async function own(table, uid, rid, lock = false) {
  const r = await db.query(
    `SELECT * FROM ${table} WHERE id=$1 AND owner_id=$2${lock ? " FOR UPDATE" : ""}`,
    [id(rid), uid],
  );
  if (!r.rows[0]) throw new Failure(403, "Record ownership mismatch.");
  return r.rows[0];
}
function pinHash(pin, salt = crypto.randomBytes(16).toString("hex")) {
  return salt + ":" + crypto.scryptSync(String(pin), salt, 32).toString("hex");
}
async function verifyPin(uid, pin) {
  const p = (await db.query("SELECT pin_hash FROM user_profiles WHERE owner_id=$1", [uid]))
    .rows[0];
  if (!p?.pin_hash || !/^\d{4}$/.test(String(pin)))
    throw new Failure(400, "A valid permanent four-digit card PIN is required.");
  const [salt, h] = p.pin_hash.split(":");
  if (
    !h ||
    !crypto.timingSafeEqual(
      Buffer.from(h, "hex"),
      Buffer.from(pinHash(pin, salt).split(":")[1], "hex"),
    )
  )
    throw new Failure(400, "Card PIN does not match.");
}
async function normalize(uid, b) {
  const kind = b.kind;
  if (!["transfer", "peer", "purchase", "repayment", "bill"].includes(kind))
    throw new Failure(400, "Choose a supported financial operation.");
  const p = {
    kind,
    source: id(b.source),
    target: b.target ? id(b.target) : null,
    amount: money(b.amount),
    note: text(b.note, 250, false),
    merchant: text(b.merchant, 100, false),
    category: String(b.category || "Other"),
    payee: b.payee ? id(b.payee) : null,
    recipient: String(b.recipient || "").trim(),
    request_key: String(b.request_key || ""),
  };
  if (!/^v6-[a-f0-9-]{36}$/.test(p.request_key)) throw new Failure(400, "Invalid request key.");
  const source = await own("accounts", uid, p.source);
  if (source.status !== "active") throw new Failure(400, "Use an active account.");
  if (kind === "transfer" || kind === "repayment") {
    if (p.target === p.source) throw new Failure(400, "Choose different accounts.");
    const target = await own("accounts", uid, p.target);
    if (
      !["checking", "savings"].includes(source.account_type) ||
      target.status !== "active" ||
      (kind === "transfer"
        ? !["checking", "savings"].includes(target.account_type)
        : target.account_type !== "credit")
    )
      throw new Failure(400, "Account types are not eligible.");
  }
  if (kind === "peer") {
    const recipient = (
      await db.query("SELECT owner_id FROM user_profiles WHERE username=$1", [p.recipient])
    ).rows[0];
    if (!recipient || recipient.owner_id === uid)
      throw new Failure(400, "Choose another verified Hikyu user.");
    const target = (
      await db.query(
        "SELECT * FROM accounts WHERE owner_id=$1 AND account_type='checking' AND status='active'",
        [recipient.owner_id],
      )
    ).rows[0];
    if (!target || !["checking", "savings"].includes(source.account_type))
      throw new Failure(400, "Recipient or source account is not eligible.");
    p.target = target.id;
    p.recipient_id = recipient.owner_id;
  }
  if (kind === "purchase") {
    if (
      !["checking", "credit"].includes(source.account_type) ||
      !p.merchant ||
      !CATEGORIES.includes(p.category) ||
      p.target ||
      p.payee
    )
      throw new Failure(400, "Enter a merchant, valid category and one card account.");
  }
  if (kind === "bill") {
    if (!["checking", "savings"].includes(source.account_type))
      throw new Failure(400, "Use a deposit account.");
    const payee = await own("saved_payees", uid, p.payee);
    if (
      payee.deleted ||
      payee.kind !== "biller" ||
      !BILLERS[payee.identifier] ||
      !payee.reference
    )
      throw new Failure(400, "Choose an active demo biller with a reference.");
    p.merchant = payee.alias + " · " + BILLERS[payee.identifier][0];
    p.category = BILLERS[payee.identifier][1];
    p.payee_reference = payee.reference;
  }
  if (kind === "repayment") {
    p.merchant = "Credit card repayment";
    p.category = "Credit payment";
  }
  if (kind === "transfer") p.category = "Transfer";
  p.fingerprint = hash(JSON.stringify(p));
  return p;
}
async function issue(user, b, session) {
  const p = await normalize(user.id, b);
  if (p.kind !== "transfer") await verifyPin(user.id, b.pin);
  if (!["sms", "email"].includes(b.method)) throw new Failure(400, "Choose SMS or email.");
  const recent = (
    await db.query(
      "SELECT count(*)::int n FROM payment_verifications WHERE owner_id=$1 AND created_at>now()-interval '10 minutes'",
      [user.id],
    )
  ).rows[0].n;
  if (recent >= 10) throw new Failure(429, "Too many verification requests. Try again later.");
  const code = String(crypto.randomInt(0, 1000000)).padStart(6, "0");
  const r = await db.query(
    "INSERT INTO payment_verifications(owner_id,session_id,fingerprint,code_hash,method,expires_at,attempts,consumed,created_at) VALUES($1,$2,$3,$4,$5,$6,0,false,now()) RETURNING id",
    [user.id, session, p.fingerprint, hash(code), b.method, new Date(Date.now() + 300000)],
  );
  return {
    challenge_id: r.rows[0].id,
    demo_code: code,
    message: "Simulation only. No SMS or email is sent.",
  };
}
async function execute(user, b, session) {
  const p = await normalize(user.id, b);
  if (p.kind !== "transfer") await verifyPin(user.id, b.pin);
  let result;
  await db.withTransaction(async () => {
    await db.query(
      "SELECT owner_id FROM user_profiles WHERE owner_id=ANY($1::int[]) ORDER BY owner_id FOR UPDATE",
      [[user.id, p.recipient_id || user.id]],
    );
    const old = (
      await db.query(
        "SELECT * FROM financial_operations WHERE owner_id=$1 AND idempotency_key=$2",
        [user.id, p.request_key],
      )
    ).rows[0];
    if (old) {
      if (old.request_hash !== p.fingerprint)
        throw new Failure(409, "The request key belongs to different operation details.");
      result = { id: old.id, status: "completed", replayed: true };
      return;
    }
    const challenge = (
      await db.query(
        "SELECT * FROM payment_verifications WHERE id=$1 AND owner_id=$2 FOR UPDATE",
        [id(b.challenge_id), user.id],
      )
    ).rows[0];
    if (
      !challenge ||
      challenge.session_id !== session ||
      challenge.fingerprint !== p.fingerprint ||
      challenge.consumed ||
      new Date(challenge.expires_at) < new Date() ||
      challenge.attempts >= 5
    )
      throw new Failure(
        400,
        "A current verification code bound to this session and exact request is required.",
      );
    if (hash(String(b.code || "")) !== challenge.code_hash) {
      await db.query("UPDATE payment_verifications SET attempts=attempts+1 WHERE id=$1", [
        challenge.id,
      ]);
      result = { failure: new Failure(400, "Incorrect verification code.") };
      return;
    }
    const ids = [p.source, ...(p.target ? [p.target] : [])].sort((a, b) => a - b);
    const locked = (
      await db.query("SELECT * FROM accounts WHERE id=ANY($1::int[]) ORDER BY id FOR UPDATE", [
        ids,
      ])
    ).rows;
    const source = locked.find((a) => a.id === p.source),
      target = locked.find((a) => a.id === p.target);
    if (
      source.owner_id !== user.id ||
      source.status !== "active" ||
      (target && target.status !== "active")
    )
      throw new Failure(403, "Account ownership or status changed.");
    if (p.target && p.kind !== "peer" && target.owner_id !== user.id)
      throw new Failure(403, "Target account ownership mismatch.");
    if (p.kind === "purchase") {
      const card = (
        await db.query("SELECT locked FROM card_controls WHERE account_id=$1 AND owner_id=$2", [
          source.id,
          user.id,
        ])
      ).rows[0];
      if (card?.locked) throw new Failure(409, "The card is locked.");
      if (source.account_type === "credit") {
        if (source.balance_cents + p.amount > source.credit_limit_cents)
          throw new Failure(409, "Credit limit exceeded.");
      } else if (source.balance_cents < p.amount) throw new Failure(409, "Insufficient funds.");
    } else if (source.balance_cents < p.amount) throw new Failure(409, "Insufficient funds.");
    if (p.kind === "repayment" && target.balance_cents < p.amount)
      throw new Failure(409, "Repayment exceeds the outstanding credit balance.");
    const op = (
      await db.query(
        "INSERT INTO financial_operations(owner_id,kind,source_account_id,target_account_id,payee_id,amount_cents,merchant,category,note,idempotency_key,request_hash,created_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,now()) RETURNING id",
        [
          user.id,
          p.kind,
          p.source,
          p.target,
          p.payee,
          p.amount,
          p.merchant || p.kind,
          p.kind === "peer" ? "Peer transfer" : p.category,
          p.note,
          p.request_key,
          p.fingerprint,
        ],
      )
    ).rows[0].id;
    await db.query("UPDATE accounts SET balance_cents=balance_cents+$1 WHERE id=$2", [
      p.kind === "purchase" && source.account_type === "credit" ? p.amount : -p.amount,
      source.id,
    ]);
    if (target)
      await db.query(
        "UPDATE accounts SET balance_cents=balance_cents+$1,minimum_due_cents=CASE WHEN $3 THEN GREATEST(0,COALESCE(minimum_due_cents,0)-$4) ELSE minimum_due_cents END WHERE id=$2",
        [
          p.kind === "repayment" ? -p.amount : p.amount,
          target.id,
          p.kind === "repayment",
          p.amount,
        ],
      );
    const kind =
      p.kind === "transfer"
        ? "transfer"
        : p.kind === "peer"
          ? "peer_transfer"
          : p.kind === "repayment"
            ? "credit_payment"
            : "expense";
    const leg = async (a, amount, name) =>
      db.query(
        "INSERT INTO transactions(owner_id,source_v5_id,account_id,name,category,posted_date,amount_cents,kind,note,operation_id) VALUES($1,$2,$3,$4,$5,now(),$6,$7,$8,$9)",
        [
          a.owner_id,
          crypto.randomUUID(),
          a.id,
          name,
          p.kind === "peer"
            ? "Peer transfer"
            : p.kind === "repayment"
              ? "Credit payment"
              : p.category,
          amount,
          kind,
          p.note,
          String(op),
        ],
      );
    await leg(source, -p.amount, p.merchant || "Transfer out");
    if (target)
      await leg(
        target,
        p.amount,
        p.kind === "repayment" ? "Credit repayment received" : "Transfer in",
      );
    if (p.kind === "transfer")
      await db.query(
        "INSERT INTO transfers(owner_id,source_account_id,target_account_id,amount_cents,note,idempotency_key,request_hash,created_at) VALUES($1,$2,$3,$4,$5,$6,$7,now())",
        [user.id, p.source, p.target, p.amount, p.note, p.request_key, p.fingerprint],
      );
    if (p.kind === "peer")
      await db.query(
        "INSERT INTO peer_payments(owner_id,recipient_id,source_account_id,target_account_id,amount_cents,note,idempotency_key,request_hash,created_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,now())",
        [
          user.id,
          p.recipient_id,
          p.source,
          p.target,
          p.amount,
          p.note,
          p.request_key,
          p.fingerprint,
        ],
      );
    await db.query("UPDATE payment_verifications SET consumed=true WHERE id=$1", [
      challenge.id,
    ]);
    for (const uid of new Set([user.id, ...(p.recipient_id ? [p.recipient_id] : [])]))
      await db.query(
        "INSERT INTO notifications(owner_id,title,body,created_at,source,is_read,resolved,event_key) VALUES($1,'Payment receipt',$2,now(),'banking',false,false,$3)",
        [uid, "Synthetic " + p.kind + " completed. Receipt " + op, "receipt-" + op + "-" + uid],
      );
    const rules = (
      await db.query(
        "SELECT a.*,x.balance_cents FROM alerts a JOIN accounts x ON x.id=a.account_id WHERE a.owner_id=$1 AND a.enabled=true AND a.account_id=ANY($2::int[])",
        [user.id, ids],
      )
    ).rows;
    for (const rule of rules) {
      const fire =
        (rule.alert_type === "low_balance" && rule.balance_cents < rule.amount_cents) ||
        (rule.alert_type === "large_transaction" && p.amount >= rule.amount_cents);
      if (fire) {
        const ev = await db.query(
          "INSERT INTO alert_events(owner_id,operation_id,alert_id,event_kind) VALUES($1,$2,$3,$4) ON CONFLICT DO NOTHING RETURNING id",
          [user.id, String(op), rule.id, "financial"],
        );
        if (ev.rows.length)
          await db.query(
            "INSERT INTO notifications(owner_id,account_id,title,body,created_at,source,is_read,resolved,event_key) VALUES($1,$2,$3,'A simulated operation triggered this reminder.',now(),'alert',false,false,$4)",
            [user.id, rule.account_id, rule.title, "alert-" + op + "-" + rule.id],
          );
      }
    }
    result = { id: op, status: "completed", amount_cents: p.amount, replayed: false };
  });
  if (result.failure) throw result.failure;
  return result;
}
async function update(user, b) {
  const cmd = b.command;
  if (cmd === "card") {
    const a = await own("accounts", user.id, b.account_id);
    if (!["checking", "credit"].includes(a.account_type) || a.status !== "active")
      throw new Failure(400, "Use an active card account.");
    await db.query("UPDATE card_controls SET locked=$1 WHERE owner_id=$2 AND account_id=$3", [
      b.locked === "true",
      user.id,
      a.id,
    ]);
    return { status: "saved" };
  }
  if (cmd === "nickname") {
    await own("accounts", user.id, b.account_id);
    await db.query("UPDATE accounts SET name=$1 WHERE id=$2", [
      text(b.name, 60),
      id(b.account_id),
    ]);
    return { status: "saved" };
  }
  if (cmd === "budget") {
    const category = text(b.category, 60);
    if (
      ![...CATEGORIES, "Peer transfer"].includes(category) ||
      !/^\d{4}-(0[1-9]|1[0-2])$/.test(b.month)
    )
      throw new Failure(400, "Choose a valid month and category.");
    await db.query(
      "INSERT INTO budgets(owner_id,month,category,limit_cents) VALUES($1,$2,$3,$4) ON CONFLICT(owner_id,month,category) DO UPDATE SET limit_cents=EXCLUDED.limit_cents",
      [user.id, b.month + "-01", category, money(b.limit)],
    );
    return { status: "saved" };
  }
  if (cmd === "delete_budget") {
    await own("budgets", user.id, b.id);
    await db.query("DELETE FROM budgets WHERE id=$1", [id(b.id)]);
    return { status: "deleted" };
  }
  if (cmd === "payee") {
    const kind = b.kind,
      identifier = text(b.identifier, 80),
      alias = text(b.alias, 60),
      reference = text(b.reference, 60, false);
    if (kind === "biller") {
      if (!BILLERS[identifier] || !reference)
        throw new Failure(400, "Choose a demo biller and reference.");
    } else if (kind === "peer") {
      const p = (
        await db.query("SELECT owner_id FROM user_profiles WHERE username=$1", [identifier])
      ).rows[0];
      if (!p || p.owner_id === user.id || reference)
        throw new Failure(400, "Choose another registered synthetic user.");
    } else throw new Failure(400, "Invalid recipient kind.");
    await db.query(
      "INSERT INTO saved_payees(owner_id,kind,identifier,alias,reference,deleted) VALUES($1,$2,$3,$4,$5,false) ON CONFLICT(owner_id,kind,identifier) DO UPDATE SET alias=EXCLUDED.alias,reference=EXCLUDED.reference,deleted=false",
      [user.id, kind, identifier, alias, reference],
    );
    return { status: "saved" };
  }
  if (cmd === "delete_payee") {
    await own("saved_payees", user.id, b.id);
    await db.query("UPDATE saved_payees SET deleted=true WHERE id=$1", [id(b.id)]);
    return { status: "deleted" };
  }
  if (cmd === "alert") {
    const a = await own("accounts", user.id, b.account_id),
      type = b.alert_type;
    if (
      ![
        "low_balance",
        "large_transaction",
        "savings_goal",
        "payment_due",
        "scheduled",
      ].includes(type)
    )
      throw new Failure(400, "Choose an alert type.");
    const monetary = ["low_balance", "large_transaction", "savings_goal"].includes(type);
    if (!monetary && !/^\d{4}-\d{2}-\d{2}$/.test(b.scheduled_date || ""))
      throw new Failure(400, "Choose a schedule date.");
    await db.query(
      "INSERT INTO alerts(owner_id,account_id,alert_type,title,channel,amount_cents,scheduled_date,enabled) VALUES($1,$2,$3,$4,$5,$6,$7,true)",
      [
        user.id,
        a.id,
        type,
        text(b.title, 80),
        ["Email", "SMS", "In-app", "Calendar"].includes(b.channel) ? b.channel : "In-app",
        monetary ? money(b.amount) : null,
        monetary ? null : b.scheduled_date,
      ],
    );
    return { status: "saved" };
  }
  if (cmd === "toggle_alert") {
    await own("alerts", user.id, b.id);
    await db.query("UPDATE alerts SET enabled=$1 WHERE id=$2", [
      b.enabled === "true",
      id(b.id),
    ]);
    return { status: "saved" };
  }
  if (cmd === "read_notification") {
    await own("notifications", user.id, b.id);
    await db.query("UPDATE notifications SET is_read=true,resolved=$1 WHERE id=$2", [
      b.resolved === "true",
      id(b.id),
    ]);
    return { status: "saved" };
  }
  throw new Failure(400, "Unsupported action.");
}
module.exports = {
  CATEGORIES,
  BILLERS,
  money,
  id,
  text,
  own,
  pinHash,
  verifyPin,
  normalize,
  issue,
  execute,
  update,
};
async function statement(user, b) {
  const from = String(b.from || ""),
    to = String(b.to || "");
  const valid = (s) =>
    /^\d{4}-\d{2}-\d{2}$/.test(s) &&
    !Number.isNaN(Date.parse(s)) &&
    new Date(s).toISOString().slice(0, 10) === s;
  if (
    !valid(from) ||
    !valid(to) ||
    from > to ||
    (Date.parse(to) - Date.parse(from)) / 86400000 > 366
  )
    throw new Failure(400, "Choose an inclusive date range of at most 367 days.");
  const params = [user.id, from, to];
  let account = "";
  if (b.account_id) {
    await own("accounts", user.id, b.account_id);
    params.push(id(b.account_id));
    account = " AND account_id=$4";
  }
  const rows = (
    await db.query(
      "SELECT id,name,category,posted_date,amount_cents,kind,note FROM transactions WHERE owner_id=$1 AND posted_date::date >=$2::date AND posted_date::date<=$3::date" +
        account +
        " ORDER BY posted_date,id LIMIT 10001",
      params,
    )
  ).rows;
  if (rows.length > 10000)
    throw new Failure(400, "The statement exceeds 10,000 records. Narrow the dates.");
  const q = (v, textCell = true) => {
    let s = String(v ?? "");
    if (textCell && /^[=+\-@\t\r\n]/.test(s)) s = "'" + s;
    return '"' + s.replace(/"/g, '""') + '"';
  };
  return [
    "Date,Name,Category,Amount,Kind,Note",
    ...rows.map((r) =>
      [
        q(new Date(r.posted_date).toISOString().slice(0, 10)),
        q(r.name),
        q(r.category),
        q((r.amount_cents / 100).toFixed(2), false),
        q(r.kind),
        q(r.note),
      ].join(","),
    ),
  ].join("\r\n");
}
module.exports.statement = statement;
