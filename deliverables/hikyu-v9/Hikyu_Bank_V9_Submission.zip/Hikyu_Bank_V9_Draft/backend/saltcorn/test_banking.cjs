const { chromium } = require("playwright"),
  fs = require("fs"),
  assert = require("assert/strict"),
  crypto = require("crypto");
const { init, db } = require("./sdk.cjs");
const ROOT = require("path").resolve(__dirname, "../.."),
  accounts = JSON.parse(fs.readFileSync(ROOT + "/private/saltcorn-accounts.json")),
  pins = JSON.parse(fs.readFileSync(ROOT + "/private/saltcorn-pins.json"));
(async () => {
  await init();
  const browser = await chromium.launch({
    executablePath: "/usr/bin/chromium",
    headless: true,
    args: ["--no-sandbox"],
  });
  const p = await browser.newPage({ viewport: { width: 1440, height: 1000 } }),
    a = accounts.find((a) => a.key === "requester"),
    other = accounts.find((a) => a.key === "other_requester");
  let results = [];
  async function post(body) {
    return p.evaluate(async (body) => {
      const r = await fetch("/view/V6_Banking_pay", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          Accept: "application/json",
        },
        body: new URLSearchParams({
          ...body,
          _csrf: document.querySelector("[name=_csrf]")?.value || window._sc_globalCsrf,
        }),
      });
      return { status: r.status, body: await r.json() };
    }, body);
  }
  const rec = (test, x = {}) => results.push({ test, status: "Pass", ...x });
  const read = async (id) =>
    (await db.query("SELECT * FROM accounts WHERE id=$1", [id])).rows[0];
  async function operation(kind, details = {}) {
    const own = (await db.query("SELECT * FROM accounts WHERE owner_id=$1", [a.id])).rows;
    return {
      kind,
      source: own.find((x) => x.account_type === "checking").id,
      amount: "1.00",
      note: "Synthetic V6 banking test",
      request_key: "v6-" + crypto.randomUUID(),
      method: "sms",
      pin: pins.requester,
      ...details,
    };
  }
  async function verify(payload) {
    const c = await post({ command: "issue", ...payload });
    assert.equal(c.status, 200, JSON.stringify(c.body));
    return {
      ...payload,
      challenge_id: c.body.result.challenge_id,
      code: c.body.result.demo_code,
    };
  }
  try {
    await p.goto(require("../v8/runtime.cjs").APP_URL + "/auth/login");
    await p.locator("[name=email]").fill(a.email);
    await p.locator("[name=password]").fill(a.password);
    await p.locator("button[type=submit]").click();
    await p.goto(require("../v8/runtime.cjs").APP_URL + "/page/pay-transfer");
    const own = (await db.query("SELECT * FROM accounts WHERE owner_id=$1", [a.id])).rows,
      checking = own.find((x) => x.account_type === "checking"),
      saving = own.find((x) => x.account_type === "savings"),
      credit = own.find((x) => x.account_type === "credit");
    let payload = await operation("transfer", { target: saving.id, amount: "25.01" }),
      verified = await verify(payload),
      x = await post({ command: "execute", ...verified });
    assert.equal(x.status, 200);
    const op = x.body.result.id;
    assert.equal((await read(checking.id)).balance_cents, checking.balance_cents - 2501);
    assert.equal((await read(saving.id)).balance_cents, saving.balance_cents + 2501);
    const legs = (
      await db.query(
        "SELECT count(*)::int n,sum(amount_cents)::int total FROM transactions WHERE operation_id=$1",
        [String(op)],
      )
    ).rows[0];
    assert.equal(legs.n, 2);
    assert.equal(legs.total, 0);
    rec("Own-account transfer atomically updates balances and two balanced ledger legs", {
      operation_id: op,
    });
    x = await post({ command: "execute", ...verified });
    assert.equal(x.status, 200);
    assert.equal(x.body.result.id, op);
    assert.equal(x.body.result.replayed, true);
    rec("Financial idempotency prevents duplicate debit");
    x = await post({ command: "execute", ...verified, amount: "25.02" });
    assert.equal(x.status, 409);
    rec("Changed financial payload conflicts with existing request key");
    payload = await operation("transfer", { target: saving.id, amount: "1000000.00" });
    verified = await verify(payload);
    const before = (await read(checking.id)).balance_cents;
    x = await post({ command: "execute", ...verified });
    assert.equal(x.status, 409);
    assert.equal((await read(checking.id)).balance_cents, before);
    rec("Insufficient funds causes no balance mutation");
    payload = await operation("transfer", { target: saving.id });
    verified = await verify(payload);
    x = await post({
      command: "execute",
      ...verified,
      code: verified.code === "000000" ? "111111" : "000000",
    });
    assert.equal(x.status, 400);
    const attempts = (
      await db.query("SELECT attempts,consumed FROM payment_verifications WHERE id=$1", [
        verified.challenge_id,
      ])
    ).rows[0];
    assert.equal(attempts.attempts, 1);
    assert.equal(attempts.consumed, false);
    rec("Wrong code attempt is counted and does not consume authorization");
    x = await post({ command: "card", account_id: checking.id, locked: "true" });
    assert.equal(x.status, 200);
    payload = await operation("purchase", {
      merchant: "Synthetic Store",
      category: "Groceries",
    });
    verified = await verify(payload);
    x = await post({ command: "execute", ...verified });
    assert.equal(x.status, 409);
    assert.match(x.body.error, /locked/);
    await post({ command: "card", account_id: checking.id, locked: "false" });
    x = await post({ command: "execute", ...verified });
    assert.equal(x.status, 200);
    rec("Locked debit card rejects purchase; unlocking permits the authorized purchase");
    payload = await operation("purchase", {
      source: credit.id,
      merchant: "Synthetic Credit Store",
      category: "Shopping",
      amount: "2.00",
    });
    verified = await verify(payload);
    const debt = (await read(credit.id)).balance_cents;
    x = await post({ command: "execute", ...verified });
    assert.equal(x.status, 200);
    assert.equal((await read(credit.id)).balance_cents, debt + 200);
    rec("Credit purchase increases outstanding debt within limit");
    payload = await operation("repayment", { target: credit.id });
    verified = await verify(payload);
    const prevDebt = (await read(credit.id)).balance_cents;
    x = await post({ command: "execute", ...verified });
    assert.equal(x.status, 200);
    assert.equal((await read(credit.id)).balance_cents, prevDebt - 100);
    const repaymentLegs = (
      await db.query(
        "SELECT sum(amount_cents)::int total FROM transactions WHERE operation_id=$1",
        [String(x.body.result.id)],
      )
    ).rows[0];
    assert.equal(repaymentLegs.total, 0);
    rec("Credit repayment reduces deposit and debt with linked balanced legs");
    payload = await operation("peer", { recipient: "other_requester" });
    verified = await verify(payload);
    const recipient = (
      await db.query("SELECT * FROM accounts WHERE owner_id=$1 AND account_type='checking'", [
        other.id,
      ])
    ).rows[0];
    x = await post({ command: "execute", ...verified });
    assert.equal(x.status, 200);
    assert.equal((await read(recipient.id)).balance_cents, recipient.balance_cents + 100);
    rec("PIN and code authorized peer payment credits the other synthetic user");
    x = await post({
      command: "payee",
      kind: "biller",
      identifier: "electric",
      alias: "Synthetic Electric",
      reference: "V6-SYNTHETIC-1",
    });
    assert.equal(x.status, 200);
    const payee = (
      await db.query("SELECT * FROM saved_payees WHERE owner_id=$1 AND identifier='electric'", [
        a.id,
      ])
    ).rows[0];
    payload = await operation("bill", { payee: payee.id });
    verified = await verify(payload);
    x = await post({ command: "execute", ...verified });
    assert.equal(x.status, 200);
    rec("Saved biller and simulated bill payment persist");
    // The native code issuance limit is ten per ten minutes. Clear only this test user's unused synthetic challenges before a separate negative test.
    await db.query("DELETE FROM payment_verifications WHERE owner_id=$1 AND consumed=false", [
      a.id,
    ]);
    x = await post({
      command: "budget",
      month: new Date().toISOString().slice(0, 7),
      category: "Groceries",
      limit: "1.00",
    });
    assert.equal(x.status, 200);
    assert.ok(
      (
        await db.query("SELECT id FROM budgets WHERE owner_id=$1 AND category='Groceries'", [
          a.id,
        ])
      ).rows.length,
    );
    rec("Owned monthly category budget is stored");
    x = await post({ command: "nickname", account_id: recipient.id, name: "Unauthorized" });
    assert.equal(x.status, 403);
    rec("Cross-user financial account mutation rejected");
    for (const amount of ["0", "-1", "1.001", "NaN", "1000000.01"]) {
      x = await post({
        command: "issue",
        ...(await operation("transfer", { target: saving.id, amount })),
      });
      assert.equal(x.status, 400);
    }
    rec("Zero, negative, overprecision, nonfinite and excessive amounts rejected");
    await p.goto(require("../v8/runtime.cjs").APP_URL + "/page/overview");
    assert.match(await p.locator("body").innerText(), /\$[0-9]/);
    await p.screenshot({ path: ROOT + "/evidence/lcnc-banking-overview.png", fullPage: true });
    await p.goto(require("../v8/runtime.cjs").APP_URL + "/page/insights");
    assert.match(await p.locator("body").innerText(), /Over budget/);
    await p.screenshot({ path: ROOT + "/evidence/lcnc-budgets.png", fullPage: true });
    rec("Formatted account cards and persisted budget results render in real browser");
    fs.writeFileSync(
      ROOT + "/evidence/lcnc-banking-tests.json",
      JSON.stringify(
        {
          kind: "Real native LCNC HTTP and PostgreSQL integration; generated synthetic account and PIN",
          results,
          time: new Date().toISOString(),
        },
        null,
        2,
      ),
    );
    console.log("PASS " + results.length + " LCNC banking checks");
  } catch (e) {
    fs.writeFileSync(
      ROOT + "/evidence/lcnc-banking-failure.json",
      JSON.stringify({ completed: results, error: e.message }, null, 2),
    );
    console.error(e.stack);
    process.exitCode = 1;
  } finally {
    await browser.close();
    await db.close();
  }
})();
