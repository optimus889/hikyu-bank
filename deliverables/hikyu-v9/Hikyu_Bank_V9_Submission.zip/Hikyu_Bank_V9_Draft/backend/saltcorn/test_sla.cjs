const { chromium } = require("playwright"),
  fs = require("fs"),
  assert = require("assert/strict"),
  crypto = require("crypto");
const { init, db } = require("./sdk.cjs");
const ROOT = require("path").resolve(__dirname, "../..");
(async () => {
  await init();
  const b = await chromium.launch({
    executablePath: "/usr/bin/chromium",
    args: ["--no-sandbox"],
  });
  const accounts = JSON.parse(fs.readFileSync(ROOT + "/private/saltcorn-accounts.json"));
  async function page(key) {
    const c = await b.newContext(),
      p = await c.newPage(),
      a = accounts.find((x) => x.key === key);
    await p.goto(require("../v8/runtime.cjs").APP_URL + "/auth/login");
    await p.locator("[name=email]").fill(a.email);
    await p.locator("[name=password]").fill(a.password);
    await p.locator("button[type=submit]").click();
    await p.goto(require("../v8/runtime.cjs").APP_URL + "/page/support-requests");
    return p;
  }
  async function post(p, body) {
    return p.evaluate(async (body) => {
      const r = await fetch("/view/V6_Support_Workflow", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          Accept: "application/json",
        },
        body: new URLSearchParams({
          ...body,
          _csrf: document.querySelector("[name=_csrf]")?.value || window._sc_globalCsrf,
        }),
      });
      return { status: r.status, body: await r.json() };
    }, body);
  }
  try {
    const p = await page("requester");
    let r = await post(p, {
      command: "submit",
      business_id: "v6-" + crypto.randomUUID(),
      transaction_id: await p.locator("[name=transaction_id]").first().inputValue(),
      description: "My payment receipt needs review",
    });
    assert.equal(r.status, 200);
    let row = r.body.result;
    const s = await page("service_agent");
    r = await post(s, {
      command: "decide",
      id: row.id,
      expected_sequence: row.sequence,
      decision: "continue",
      comment: "Please review this synthetic request",
    });
    assert.equal(r.status, 200);
    let escalated;
    for (let i = 0; i < 60; i++) {
      row = (await db.query("SELECT * FROM support_requests WHERE id=$1", [row.id])).rows[0];
      if (row.state === "ESCALATED") {
        escalated = row;
        break;
      }
      await new Promise((ok) => setTimeout(ok, 400));
    }
    assert.ok(escalated, "Real timer did not cause persisted escalation");
    const supervisor = await page("supervisor");
    await supervisor.locator(`article[data-business-id="${row.business_id}"]`).waitFor();
    r = await post(supervisor, {
      command: "decide",
      id: row.id,
      expected_sequence: row.sequence,
      decision: "complete",
      comment: "Supervisor resolved the overdue synthetic review",
    });
    assert.equal(r.status, 200);
    row = (await db.query("SELECT * FROM support_requests WHERE id=$1", [row.id])).rows[0];
    assert.equal(row.state, "COMPLETED");
    await p.reload();
    await p.screenshot({ path: ROOT + "/evidence/lcnc-human-timeout.png", fullPage: true });
    fs.writeFileSync(
      ROOT + "/evidence/lcnc-human-timeout.json",
      JSON.stringify(
        {
          status: "Pass",
          kind: "Real Flowable timer expiry with controlled PT2S test SLA; production default remains PT24H; single-person role simulation",
          business_id: row.business_id,
          process_instance_id: row.process_instance_id,
          escalated_version: escalated.sequence,
          final_version: row.sequence,
          last_comment: row.last_comment,
          time: new Date().toISOString(),
        },
        null,
        2,
      ),
    );
    console.log(
      "PASS actual timed escalation, supervisor handoff and persistent LCNC completion",
    );
  } finally {
    await b.close();
    await db.close();
  }
})().catch((e) => {
  console.error(e.stack);
  process.exit(1);
});
