const { chromium } = require("playwright"),
  fs = require("fs"),
  assert = require("assert/strict");
const ROOT = require("path").resolve(__dirname, "../..");
const accounts = JSON.parse(fs.readFileSync(ROOT + "/private/saltcorn-accounts.json"));
(async () => {
  const browser = await chromium.launch({
    executablePath: "/usr/bin/chromium",
    headless: true,
    args: ["--no-sandbox"],
  });
  const results = [];
  const sessions = {};
  async function session(key) {
    if (sessions[key]) return sessions[key];
    const c = await browser.newContext({ viewport: { width: 1440, height: 1000 } }),
      p = await c.newPage(),
      a = accounts.find((a) => a.key === key);
    await p.goto(require("../v8/runtime.cjs").APP_URL + "/auth/login");
    await p.locator("[name=email]").fill(a.email);
    await p.locator("[name=password]").fill(a.password);
    await p.locator("button[type=submit],input[type=submit]").first().click();
    await p.waitForTimeout(300);
    sessions[key] = p;
    return p;
  }
  async function page(key) {
    const p = await session(key);
    await p.goto(require("../v8/runtime.cjs").APP_URL + "/page/support-requests");
    await p.waitForTimeout(100);
    return p;
  }
  async function post(p, data) {
    return await p.evaluate(async (data) => {
      const csrf = document.querySelector("input[name=_csrf]").value;
      const r = await fetch("/view/V6_Support_Workflow", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          Accept: "application/json",
        },
        body: new URLSearchParams({ ...data, _csrf: csrf }),
      });
      return { status: r.status, body: await r.json() };
    }, data);
  }
  try {
    const r = await page("requester");
    const desc = "My card is locked and purchases are blocked";
    const bid = await r.locator("input[name=business_id]").first().inputValue();
    const transaction = await r.locator("select[name=transaction_id]").first().inputValue();
    await r.locator("textarea[name=description]").first().fill(desc);
    await r.getByRole("button", { name: "Submit support request" }).click();
    await r.waitForURL("**/page/support-requests");
    let article = r.locator(`article[data-business-id="${bid}"]`);
    await article.waitFor();
    assert.match(await article.innerText(), /SERVICE_REVIEW/);
    assert.match(await article.innerText(), /card_access/);
    const row = await article.getAttribute("data-row-id");
    await article.screenshot({ path: ROOT + "/evidence/lcnc-request-submitted-card.png" });
    await r.screenshot({
      path: ROOT + "/evidence/lcnc-request-submitted.png",
      fullPage: false,
    });
    results.push({
      test: "LCNC native submission and real runtime AI",
      status: "Pass",
      business_id: bid,
      row_id: row,
    });
    const s = await page("service_agent");
    article = s.locator(`article[data-business-id="${bid}"]`);
    assert.match(await article.innerText(), /SERVICE_REVIEW/);
    await article
      .locator("[name=comment]")
      .fill("Synthetic context checked. Please independently review the resolution.");
    await article.locator("[name=decision]").selectOption("continue");
    await article.getByRole("button", { name: "Save decision" }).click();
    await s.waitForURL("**/page/support-requests");
    results.push({ test: "Service agent hands task to reviewer", status: "Pass" });
    const v = await page("reviewer");
    article = v.locator(`article[data-business-id="${bid}"]`);
    assert.match(await article.innerText(), /REVIEWER_REVIEW/);
    await article.screenshot({ path: ROOT + "/evidence/lcnc-reviewer-handoff-card.png" });
    await v.screenshot({ path: ROOT + "/evidence/lcnc-reviewer-handoff.png", fullPage: false });
    await article
      .locator("[name=comment]")
      .fill("Independent synthetic review completed. No settled transaction was modified.");
    await article.locator("[name=decision]").selectOption("complete");
    await article.getByRole("button", { name: "Save decision" }).click();
    await v.waitForURL("**/page/support-requests");
    await r.reload();
    article = r.locator(`article[data-business-id="${bid}"]`);
    assert.match(await article.innerText(), /COMPLETED/);
    await article.screenshot({ path: ROOT + "/evidence/lcnc-completed-refresh-card.png" });
    await r.screenshot({
      path: ROOT + "/evidence/lcnc-completed-refresh.png",
      fullPage: false,
    });
    results.push({
      test: "Final status written to the same LCNC row and retained after refresh",
      status: "Pass",
      row_id: await article.getAttribute("data-row-id"),
    });
    const same = await post(r, {
      command: "submit",
      business_id: bid,
      description: desc,
      transaction_id: transaction,
    });
    assert.equal(same.status, 200);
    assert.equal(String(same.body.result.id), row);
    results.push({
      test: "Duplicate submission uses same persisted business record",
      status: "Pass",
    });
    const conflict = await post(r, {
      command: "submit",
      business_id: bid,
      description: "Different request content",
      transaction_id: transaction,
    });
    assert.equal(conflict.status, 409);
    results.push({ test: "Conflicting duplicate submission rejected", status: "Pass" });
    const invalid = await post(r, {
      command: "submit",
      business_id: "v6-" + require("crypto").randomUUID(),
      description: " ",
      transaction_id: transaction,
    });
    assert.equal(invalid.status, 400);
    results.push({ test: "Blank required input rejected server-side", status: "Pass" });
    const other = await page("other_requester");
    assert.ok(!(await other.locator("body").innerText()).includes(bid));
    const foreign = await post(other, {
      command: "submit",
      business_id: "v6-" + require("crypto").randomUUID(),
      description: "Synthetic transaction question",
      transaction_id: transaction,
    });
    assert.equal(foreign.status, 403);
    results.push({
      test: "Cross-user transaction reference rejected; other user cannot see business record",
      status: "Pass",
    });
    const denial = await post(other, {
      command: "decide",
      id: row,
      expected_sequence: 1,
      decision: "complete",
      comment: "Unauthorized attempt",
    });
    assert.equal(denial.status, 403);
    results.push({ test: "Unauthorized role decision rejected", status: "Pass" });
    fs.writeFileSync(
      ROOT + "/evidence/lcnc-e2e.json",
      JSON.stringify(
        {
          kind: "Real local Saltcorn + Flowable + local ML integration; one operator switches independent synthetic accounts; not real multi-person testing",
          results,
          business_id: bid,
          row_id: row,
          final_text: await r.locator(`article[data-business-id="${bid}"]`).innerText(),
          time: new Date().toISOString(),
        },
        null,
        2,
      ),
    );
    console.log(
      "PASS: " +
        results.length +
        " real LCNC integration checks; single-person role simulation",
    );
  } catch (e) {
    fs.writeFileSync(
      ROOT + "/evidence/lcnc-e2e-failure.json",
      JSON.stringify({ completed: results, error: e.message }, null, 2),
    );
    console.error(e.stack);
    process.exitCode = 1;
  } finally {
    await browser.close();
  }
})();
