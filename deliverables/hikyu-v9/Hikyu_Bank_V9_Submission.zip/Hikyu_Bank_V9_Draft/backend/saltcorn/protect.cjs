const { init, db, Table } = require("./sdk.cjs");
(async () => {
  await init();
  for (const n of [
    "accounts",
    "transactions",
    "financial_operations",
    "transfers",
    "peer_payments",
    "payment_verifications",
    "support_requests",
    "user_profiles",
    "alert_events",
  ]) {
    for (const f of Table.findOne(n).getFields())
      if (!f.primary_key)
        await f.update({ attributes: { ...f.attributes, min_role_write: 1 } });
  }
  console.log("Protected financial and workflow fields from generic end-user row writes");
  await db.close();
})();
