const { chromium } = require("playwright"),
  fs = require("fs"),
  assert = require("assert/strict"),
  crypto = require("crypto");
(async () => {
  const ROOT = require("path").resolve(__dirname, "../.."),
    mode = process.argv[2];
  const a = JSON.parse(fs.readFileSync(ROOT + "/private/saltcorn-accounts.json")).find(
    (x) => x.key === "requester",
  );
  const b = await chromium.launch({
      executablePath: "/usr/bin/chromium",
      args: ["--no-sandbox"],
    }),
    p = await b.newPage();
  try {
    await p.goto(require("../v8/runtime.cjs").APP_URL + "/auth/login");
    await p.locator("[name=email]").fill(a.email);
    await p.locator("[name=password]").fill(a.password);
    await p.locator("button[type=submit]").click();
    await p.goto(require("../v8/runtime.cjs").APP_URL + "/page/support-requests");
    const before = Date.now();
    const r = await p.evaluate(async (bid) => {
      const data = {
        command: "submit",
        business_id: bid,
        transaction_id: document.querySelector("[name=transaction_id]").value,
        description: "My payment receipt is missing",
        _csrf: document.querySelector("[name=_csrf]").value,
      };
      const r = await fetch("/view/V6_Support_Workflow", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          Accept: "application/json",
        },
        body: new URLSearchParams(data),
      });
      return { status: r.status, body: await r.json() };
    }, "v6-" + crypto.randomUUID());
    assert.equal(r.status, 200);
    assert.equal(r.body.result.state, "MANUAL_TRIAGE");
    const out = {
      fault_mode: mode,
      status: "Pass",
      elapsed_ms: Date.now() - before,
      kind: "Controlled AI process fault injection through live LCNC and Flowable; not a real successful AI output",
      business_id: r.body.result.business_id,
      process_instance_id: r.body.result.process_instance_id,
      lc_nc_state: r.body.result.state,
      ai_category: r.body.result.ai_category,
    };
    fs.writeFileSync(
      ROOT + "/evidence/ai-fault-" + mode + ".json",
      JSON.stringify(out, null, 2),
    );
    console.log(JSON.stringify(out));
  } finally {
    await b.close();
  }
})().catch((e) => {
  console.error(e.stack);
  process.exit(1);
});
