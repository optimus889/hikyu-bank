const { sc, init, db, Table, Field, View, Page, User, state } = require("./sdk.cjs");
const fs = require("fs"),
  crypto = require("crypto");
const root = require("path").resolve(__dirname, "../..");
(async () => {
  await init();
  const accountPath = root + "/private/saltcorn-accounts.json";
  let users = fs.existsSync(accountPath) ? JSON.parse(fs.readFileSync(accountPath)) : [];
  if (!users.length) {
    for (const [key, role_id] of [
      ["builder", 1],
      ["requester", 80],
      ["other_requester", 80],
      ["service_agent", 40],
      ["reviewer", 40],
      ["supervisor", 40],
    ]) {
      const email = key + ".v7@example.invalid";
      const password = "V7-" + crypto.randomBytes(24).toString("hex");
      const u = await User.create({ email, password, role_id });
      if (!u.id) throw new Error("User creation failed");
      users.push({ key, id: u.id, email, password, role_id });
    }
    fs.writeFileSync(accountPath, JSON.stringify(users, null, 2), { mode: 0o600 });
  }
  const S = (name, label, attrs = {}) => ({ name, label, type: "String", attributes: attrs }),
    I = (name, label) => ({ name, label, type: "Integer", attributes: {} }),
    B = (name, label) => ({ name, label, type: "Bool", attributes: {} }),
    D = (name, label) => ({ name, label, type: "Date", attributes: {} }),
    K = (name, label, to) => ({
      name,
      label,
      type: "Key",
      reftable_name: to,
      attributes: { summary_field: to === "users" ? "email" : "id" },
    });
  const specs = {
    user_profiles: [
      K("owner_id", "Owner", "users"),
      S("source_v5_id", "Source V5 ID"),
      S("username", "Username"),
      S("first_name", "First name"),
      S("last_name", "Last name"),
      S("pin_hash", "Private PIN hash"),
      S("masked_phone", "Masked phone"),
      S("masked_email", "Masked email"),
      I("auth_version", "Authentication version"),
    ],
    accounts: [
      K("owner_id", "Owner", "users"),
      S("source_v5_id", "Source V5 ID"),
      S("account_type", "Type", { options: "checking,savings,credit,loan,investment" }),
      S("name", "Name"),
      S("suffix", "Last four digits"),
      I("balance_cents", "Balance (cents)"),
      S("status", "Status", { options: "active,pending,closed" }),
      I("credit_limit_cents", "Credit limit (cents)"),
      I("minimum_due_cents", "Minimum due (cents)"),
      D("due_date", "Due date"),
    ],
    transactions: [
      K("owner_id", "Owner", "users"),
      S("source_v5_id", "Source V5 ID"),
      K("account_id", "Account", "accounts"),
      S("name", "Name"),
      S("category", "Category"),
      D("posted_date", "Posted date"),
      I("amount_cents", "Amount (cents)"),
      S("kind", "Kind", { options: "income,expense,transfer,peer_transfer,credit_payment" }),
      S("icon", "Icon"),
      S("note", "Note"),
      S("transfer_id", "Transfer ID"),
      S("peer_payment_id", "Peer payment ID"),
      S("operation_id", "Operation ID"),
    ],
    alerts: [
      K("owner_id", "Owner", "users"),
      K("account_id", "Account", "accounts"),
      S("alert_type", "Type", {
        options: "low_balance,large_transaction,savings_goal,payment_due,scheduled",
      }),
      S("title", "Title"),
      S("channel", "Channel", { options: "Email,SMS,In-app,Calendar" }),
      I("amount_cents", "Threshold (cents)"),
      D("scheduled_date", "Scheduled date"),
      B("enabled", "Enabled"),
    ],
    notifications: [
      K("owner_id", "Recipient", "users"),
      K("account_id", "Account", "accounts"),
      S("title", "Title"),
      S("body", "Message"),
      D("created_at", "Created at"),
      S("source", "Source"),
      B("is_read", "Read"),
      B("resolved", "Resolved"),
      S("event_key", "Event key"),
    ],
    user_preferences: [
      K("owner_id", "Owner", "users"),
      B("low_balance_enabled", "Low balance alerts"),
      B("large_transfer_enabled", "Large transfer alerts"),
    ],
    transfers: [
      K("owner_id", "Owner", "users"),
      K("source_account_id", "Source account", "accounts"),
      K("target_account_id", "Target account", "accounts"),
      I("amount_cents", "Amount (cents)"),
      S("note", "Note"),
      S("idempotency_key", "Request key"),
      S("request_hash", "Request hash"),
      D("created_at", "Created at"),
    ],
    peer_payments: [
      K("owner_id", "Sender", "users"),
      K("recipient_id", "Recipient", "users"),
      K("source_account_id", "Source account", "accounts"),
      K("target_account_id", "Target account", "accounts"),
      I("amount_cents", "Amount (cents)"),
      S("note", "Note"),
      S("idempotency_key", "Request key"),
      S("request_hash", "Request hash"),
      D("created_at", "Created at"),
    ],
    payment_verifications: [
      K("owner_id", "Owner", "users"),
      S("session_id", "Session binding"),
      S("fingerprint", "Request fingerprint"),
      S("code_hash", "Private code hash"),
      S("method", "Method", { options: "sms,email" }),
      D("expires_at", "Expires at"),
      I("attempts", "Attempts"),
      B("consumed", "Consumed"),
    ],
    saved_payees: [
      K("owner_id", "Owner", "users"),
      S("kind", "Kind", { options: "peer,biller" }),
      S("identifier", "Recipient or biller identifier"),
      S("alias", "Alias"),
      S("reference", "Reference"),
      B("deleted", "Deleted"),
    ],
    card_controls: [
      K("owner_id", "Owner", "users"),
      K("account_id", "Account", "accounts"),
      B("locked", "Locked"),
    ],
    budgets: [
      K("owner_id", "Owner", "users"),
      D("month", "Month"),
      S("category", "Category"),
      I("limit_cents", "Limit (cents)"),
    ],
    financial_operations: [
      K("owner_id", "Owner", "users"),
      S("kind", "Kind", { options: "purchase,repayment,bill" }),
      K("source_account_id", "Source account", "accounts"),
      K("target_account_id", "Target account", "accounts"),
      K("payee_id", "Payee", "saved_payees"),
      I("amount_cents", "Amount (cents)"),
      S("merchant", "Merchant"),
      S("category", "Category"),
      S("note", "Note"),
      S("idempotency_key", "Request key"),
      S("request_hash", "Request hash"),
      D("created_at", "Created at"),
    ],
    alert_events: [
      K("owner_id", "Owner", "users"),
      S("operation_id", "Operation ID"),
      K("alert_id", "Alert", "alerts"),
      S("event_kind", "Event kind"),
    ],
    support_requests: [
      K("owner_id", "Requester", "users"),
      S("business_id", "Business ID"),
      K("transaction_id", "Transaction", "transactions"),
      S("description", "Description"),
      S("process_instance_id", "Process instance ID"),
      S("state", "Status"),
      I("sequence", "State version"),
      S("ai_category", "AI category"),
      S("ai_confidence", "AI confidence"),
      S("ai_model_version", "AI model version"),
      S("current_role", "Current role"),
      D("created_at", "Created at"),
      D("updated_at", "Updated at"),
      S("outcome", "Outcome"),
      S("last_comment", "Latest processing comment"),
      S("integration_error", "Integration error"),
    ],
  };
  for (const [name, fields] of Object.entries(specs)) {
    let t = Table.findOne(name);
    if (!t)
      t = await Table.create(name, { min_role_read: 1, min_role_write: 1, versioned: false });
    for (const f of fields) {
      if (
        !Table.findOne(name)
          .getFields()
          .some((x) => x.name === f.name)
      )
        await Field.create({ ...f, table_id: t.id });
    }
    t = Table.findOne(name);
    const owner = t.getFields().find((x) => x.name === "owner_id");
    if (owner)
      await t.update({ ownership_field_id: owner.id, min_role_read: 1, min_role_write: 1 });
  }
  // Financial and support workflow changes are performed through authenticated actions, not unrestricted row editors.
  const safeLists = {
    accounts: ["name", "account_type", "suffix", "balance_cents", "status"],
    transactions: [
      "account_id",
      "name",
      "category",
      "posted_date",
      "amount_cents",
      "kind",
      "note",
    ],
    alerts: [
      "account_id",
      "alert_type",
      "title",
      "channel",
      "amount_cents",
      "scheduled_date",
      "enabled",
    ],
    notifications: ["title", "body", "created_at", "is_read", "resolved"],
    saved_payees: ["kind", "identifier", "alias", "reference"],
    card_controls: ["account_id", "locked"],
    budgets: ["month", "category", "limit_cents"],
    support_requests: [
      "business_id",
      "transaction_id",
      "description",
      "state",
      "sequence",
      "ai_category",
      "current_role",
      "updated_at",
      "outcome",
      "last_comment",
    ],
  };
  for (const [name, cols] of Object.entries(safeLists)) {
    const t = Table.findOne(name);
    const conf = await state.getState().viewtemplates.List.initial_config({ table_id: t.id });
    conf.columns = conf.columns.filter(
      (c) => cols.includes(c.field_name) || cols.some((n) => c.join_field?.startsWith(n + ".")),
    );
    conf.layout.besides = conf.layout.besides.filter(
      (c) =>
        cols.includes(c.contents.field_name) ||
        cols.some((n) => c.contents.join_field?.startsWith(n + ".")),
    );
    conf.default_state = { _limit: 50 };
    const vn = "V6_" + name;
    if (!View.findOne({ name: vn }))
      await View.create({
        name: vn,
        table_id: t.id,
        viewtemplate: "List",
        min_role: 80,
        configuration: conf,
      });
  }
  // Only synthetic data generated in this task is seeded.
  for (const u of users.filter((u) => ["requester", "other_requester"].includes(u.key))) {
    const at = Table.findOne("accounts");
    if (!(await at.getRows({ owner_id: u.id })).length) {
      for (const [type, balance] of [
        ["checking", 100000],
        ["savings", 20000],
        ["credit", 10000],
      ]) {
        const id = await at.insertRow({
          owner_id: u.id,
          source_v5_id: crypto.randomUUID(),
          account_type: type,
          name:
            type === "checking"
              ? "Everyday Checking"
              : type === "savings"
                ? "Everyday Saving"
                : "Demo Credit",
          suffix: String(crypto.randomInt(1000, 10000)),
          balance_cents: balance,
          status: "active",
          credit_limit_cents: type === "credit" ? 500000 : 0,
          minimum_due_cents: type === "credit" ? 2500 : 0,
        });
        if (["checking", "credit"].includes(type))
          await Table.findOne("card_controls").insertRow({
            owner_id: u.id,
            account_id: id,
            locked: false,
          });
        if (type === "checking")
          await Table.findOne("transactions").insertRow({
            owner_id: u.id,
            source_v5_id: crypto.randomUUID(),
            account_id: id,
            name: "Synthetic grocery purchase",
            category: "Groceries",
            posted_date: new Date(),
            amount_cents: -1250,
            kind: "expense",
            note: "Synthetic V6 fixture",
          });
      }
      await Table.findOne("user_profiles").insertRow({
        owner_id: u.id,
        source_v5_id: crypto.randomUUID(),
        username: u.key,
        first_name: "Synthetic",
        last_name: u.key === "requester" ? "Requester" : "Other",
        masked_phone: "***-***-0000",
        masked_email: "s***@example.invalid",
        auth_version: 0,
      });
    }
  }
  const nav = [
    ["Overview", "overview"],
    ["Transactions", "transactions"],
    ["Pay & Transfer", "pay-transfer"],
    ["Accounts & Cards", "accounts-cards"],
    ["Financial Insights", "insights"],
    ["Settings", "settings"],
    ["Demo Tools", "demo-tools"],
    ["Support Requests", "support-requests"],
  ];
  const header =
    '<nav class="v6-nav"><strong>HIKYU BANK</strong>' +
    nav.map(([l, n]) => `<a href="/page/${n}">${l}</a>`).join("") +
    "</nav>";
  const styles =
    "<style>body{background:#f5f8fc;color:#0c2f53;font-family:Arial,sans-serif}.v6-nav{background:#0b2c50;color:white;padding:22px;display:flex;gap:22px;flex-wrap:wrap}.v6-nav a{color:#dce9f6;font-size:14px}.v6-panel{background:white;border:1px solid #cadcf0;border-radius:9px;padding:24px;margin:18px 0}.v6-title{font-size:36px;font-weight:700;margin-top:38px}table{background:white}.btn-primary{background:#195eaa;border-color:#195eaa}footer{margin-top:45px;color:#627c96;font-size:13px}</style>";
  const blank = (s) => ({ type: "blank", contents: s, block: true });
  const view = (n) => ({ type: "view", view: "V6_" + n, block: true });
  const pages = {
    overview: [
      blank(
        '<p class="v6-title">Your money, in focus</p><p>Your accounts. One clear view.</p><p>USD · Simulated balances are stored as integer cents.</p>',
      ),
      view("accounts"),
      blank("<h2>Recent transactions</h2>"),
      view("transactions"),
    ],
    transactions: [
      blank(
        '<h1 class="v6-title">Transactions</h1><p>Review your persisted synthetic transaction history.</p>',
      ),
      view("transactions"),
    ],
    "pay-transfer": [
      blank(
        '<h1 class="v6-title">Pay & Transfer</h1><p>Between my accounts · To another person · Saved recipients · Bill Pay</p>',
      ),
      view("saved_payees"),
    ],
    "accounts-cards": [
      blank('<h1 class="v6-title">Accounts & Cards</h1>'),
      view("accounts"),
      blank("<h2>Cards</h2>"),
      view("card_controls"),
    ],
    insights: [
      blank(
        '<h1 class="v6-title">Financial Insights</h1><p>Budgets and AI-assisted support classification.</p>',
      ),
      view("budgets"),
    ],
    settings: [
      blank(
        '<h1 class="v6-title">Settings</h1><p>Use the native account menu to manage your password. Financial settings remain under reconstruction.</p>',
      ),
    ],
    "demo-tools": [
      blank(
        '<h1 class="v6-title">Demo Tools</h1><p>Simulation only · No real money is moved.</p>',
      ),
    ],
    "support-requests": [
      blank(
        '<h1 class="v6-title">Transaction Support Review</h1><p>Request assistance with a transaction. AI provides a category; people decide the outcome.</p>',
      ),
      view("support_requests"),
    ],
  };
  for (const [name, parts] of Object.entries(pages))
    if (!Page.findOne({ name }))
      await Page.create({
        name,
        title: nav.find((x) => x[1] === name)[0],
        description: "Hikyu V7 native editable LCNC page",
        min_role: 80,
        layout: {
          above: [
            blank(styles + header),
            ...parts,
            blank(
              "<footer>Hikyu Bank · Simulation only · No real banking transactions</footer>",
            ),
          ],
        },
      });
  await state.getState().setConfig("site_name", "Hikyu Bank V7");
  await state.getState().setConfig("allow_signup", false);
  await state
    .getState()
    .setConfig("home_page_by_role", {
      1: "overview",
      40: "support-requests",
      80: "overview",
      100: "",
    });
  fs.writeFileSync(
    root + "/evidence/saltcorn-bootstrap.json",
    JSON.stringify(
      {
        platform: "Saltcorn",
        version: "1.6.2",
        tables: Object.keys(specs),
        nativeViews: Object.keys(safeLists).map((n) => "V6_" + n),
        nativePages: Object.keys(pages),
        roles: users.map(({ key, id, role_id }) => ({ key, id, role_id })),
        status:
          "Native schema and read views created; write workflows require separate validation",
        time: new Date().toISOString(),
      },
      null,
      2,
    ),
  );
  console.log(
    "Created native Saltcorn data definitions, owned synthetic fixtures, views and pages",
  );
  await db.close();
})();
