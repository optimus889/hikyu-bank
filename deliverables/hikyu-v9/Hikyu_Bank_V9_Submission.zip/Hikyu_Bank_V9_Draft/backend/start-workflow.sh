#!/bin/bash
set -euo pipefail
backend_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if [[ -n "${JAVA_HOME:-}" ]]; then
  java_cmd="$JAVA_HOME/bin/java"
else
  java_cmd=java
fi
cd "$backend_dir/workflow"
exec "$java_cmd" -cp "target/classes:$(cat classpath.txt)" demo.WorkflowServer
