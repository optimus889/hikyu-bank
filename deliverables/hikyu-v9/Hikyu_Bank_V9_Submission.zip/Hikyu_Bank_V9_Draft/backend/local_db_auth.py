"""Verify that the local demo's stored password authenticates over TCP."""

import json
import re
import subprocess


def tcp_login(compose, env, config):
    # Use the Compose service address so the check exercises host authentication.
    return subprocess.run(
        [
            *compose,
            "exec",
            "-T",
            "-e",
            "PGPASSWORD",
            "-e",
            "PGCONNECT_TIMEOUT=5",
            "-e",
            "LC_ALL=C",
            "database",
            "psql",
            "-X",
            "-w",
            "-h",
            "database",
            "-p",
            "5432",
            "-U",
            config["PGUSER"],
            "-d",
            "postgres",
            "-tAc",
            "SELECT 1",
        ],
        env={**env, "PGPASSWORD": config["PGPASSWORD"]},
        capture_output=True,
        text=True,
        timeout=15,
    )


def verify_local_db(compose, env, config, project, repair=False):
    """Repair only the generated demo role, using the container's local socket."""
    result = tcp_login(compose, env, config)
    if result.returncode == 0:
        print("Database: local PostgreSQL password verified.", flush=True)
        return
    if "password authentication failed" not in result.stderr:
        raise SystemExit(
            "PostgreSQL did not accept the TCP connection. Check the local database "
            f"container with docker logs {project}-database-1."
        )
    if not repair:
        raise SystemExit(
            "PostgreSQL password mismatch (28P01). The local settings and database volume "
            "may have been created at different times. In this V9 directory run "
            "python3 backend/prepare_v9.py --repair-db-auth, then run setup again."
        )

    password = config["PGPASSWORD"]
    if (
        config["PGHOST"] != "127.0.0.1"
        or config["PGUSER"] != "v6_demo"
        or config["PGDATABASE"] != "saltcorn_v8"
        or not re.fullmatch(r"hikyu-v8-[0-9a-f]{10}", project)
        or not re.fullmatch(r"[A-Za-z0-9_-]{43,}", password)
    ):
        raise SystemExit(
            "Repair only supports the automatically generated V9 demo configuration."
        )

    container = subprocess.check_output(
        [*compose, "ps", "-q", "database"], env=env, text=True, timeout=15
    ).strip()
    if not re.fullmatch(r"[0-9a-f]{12,64}", container):
        raise SystemExit("Repair could not identify one running V9 database container.")
    mounts = json.loads(
        subprocess.check_output(
            ["docker", "inspect", "--format", "{{json .Mounts}}", container],
            env=env,
            text=True,
            timeout=15,
        )
    )
    if not any(
        item["Type"] == "volume"
        and item["Name"] == project + "_v6_data"
        and item["Destination"] == "/var/lib/postgresql/data"
        for item in mounts
    ):
        raise SystemExit("Repair could not verify the named V9 database volume.")

    # psql hashes the password client-side. Pass it via stdin, never the command line.
    reset = subprocess.run(
        [
            "docker",
            "exec",
            "-i",
            container,
            "psql",
            "-X",
            "-w",
            "-h",
            "/var/run/postgresql",
            "-U",
            "v6_demo",
            "-d",
            "postgres",
            "-v",
            "ON_ERROR_STOP=1",
            "-c",
            r"\password v6_demo",
        ],
        input=f"{password}\n{password}\n",
        env=env,
        capture_output=True,
        text=True,
        timeout=30,
    )
    if reset.returncode != 0 or tcp_login(compose, env, config).returncode != 0:
        raise SystemExit(
            "Password repair could not be confirmed. Keep the original volume. "
            "Use the separate local demo instructions in the README if needed."
        )
    print("Database: password aligned with the local V9 configuration. Existing data retained.")
