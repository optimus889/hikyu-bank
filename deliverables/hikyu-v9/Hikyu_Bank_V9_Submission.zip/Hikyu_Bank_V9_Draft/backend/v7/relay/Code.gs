/* Hikyu V7 authenticated relay. Deploy only this script as a Web App; never Saltcorn. */
const V7_TABLES = {
  IntakeQueue: ["id", "payload", "status", "updated_at"],
  OutcomeQueue: ["id", "payload", "status", "updated_at"],
  Receipts: ["id", "payload", "status", "updated_at"],
  Nonces: ["id", "expires_at"],
  Audit: ["time", "correlation", "operation", "result"],
  ExternalCases: ["case_id", "final_state", "state_version", "case_processed_at", "synced_at"],
};
function props() {
  return PropertiesService.getScriptProperties();
}
function book() {
  const id = props().getProperty("SPREADSHEET_ID");
  if (!id) throw fault(503, "RELAY_NOT_CONFIGURED", true);
  return SpreadsheetApp.openById(id);
}
function fault(status, code, retryable) {
  const e = new Error(code);
  e.status = status;
  e.code = code;
  e.retryable = !!retryable;
  return e;
}
function bootstrapV7() {
  if (props().getProperty("SPREADSHEET_ID"))
    throw new Error("Already initialized; use existing resources");
  const ss = SpreadsheetApp.create("Hikyu V7 Synthetic Integration");
  ss.setSpreadsheetTimeZone("Etc/UTC");
  const source = ss.getSheets()[0];
  source.setName("SourceEvents");
  source.appendRow([
    "source_type",
    "source_namespace",
    "source_event_id",
    "subject",
    "description",
    "submitted_at",
    "source_reference",
  ]);
  Object.keys(V7_TABLES).forEach((n) => ss.insertSheet(n).appendRow(V7_TABLES[n]));
  const form = FormApp.create("Hikyu V7 External Support Request");
  form.setDescription(
    "Synthetic test data only. No identity, account number, card number or transaction details. This creates an unverified draft.",
  );
  form.addTextItem().setTitle("Subject").setRequired(true);
  form.addParagraphTextItem().setTitle("Description").setRequired(true);
  props().setProperties({ SPREADSHEET_ID: ss.getId(), FORM_ID: form.getId() });
  ScriptApp.newTrigger("captureFormSubmission").forForm(form).onFormSubmit().create();
  /* URLs only; no keys. */ console.log("Spreadsheet: " + ss.getUrl());
  console.log("Form: " + form.getPublishedUrl());
}
function captureFormSubmission(e) {
  const r = e.response;
  const fields = r.getItemResponses();
  const row = [
    "form",
    props().getProperty("FORM_ID"),
    r.getId(),
    fields[0].getResponse(),
    fields[1].getResponse(),
    r.getTimestamp().toISOString(),
    "",
  ];
  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    book().getSheetByName("SourceEvents").appendRow(row);
  } finally {
    lock.releaseLock();
  }
}
function rows(name) {
  const s = book().getSheetByName(name);
  return s.getLastRow() < 2
    ? []
    : s
        .getRange(2, 1, s.getLastRow() - 1, s.getLastColumn())
        .getValues()
        .map((r, i) => ({ n: i + 2, values: r }));
}
function find(name, id) {
  return rows(name).find((r) => String(r.values[0]) === String(id));
}
function put(name, id, payload, status) {
  const s = book().getSheetByName(name),
    old = find(name, id),
    v = [id, JSON.stringify(payload), status, new Date().toISOString()];
  if (old) s.getRange(old.n, 1, 1, v.length).setValues([v]);
  else s.appendRow(v);
}
function items(name, status) {
  return rows(name)
    .filter((r) => r.values[2] === status)
    .slice(0, 50)
    .map((r) => ({ id: String(r.values[0]), payload: JSON.parse(r.values[1]) }));
}
function audit(correlation, operation, result) {
  book()
    .getSheetByName("Audit")
    .appendRow([
      new Date().toISOString(),
      String(correlation).slice(0, 200),
      operation,
      result,
    ]);
}
function text(v, n, max, min) {
  if (
    typeof v !== "string" ||
    v.trim().length < (min === undefined ? 1 : min) ||
    v.trim().length > max
  )
    throw fault(422, "INVALID_" + n.toUpperCase());
  return v.trim();
}
function iso(v) {
  v = text(v, "timestamp", 64);
  if (
    !/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{1,9})?(?:Z|[+-]\d\d:\d\d)$/.test(v) ||
    !isFinite(Date.parse(v)) ||
    Date.parse(v) > Date.now() + 300000
  )
    throw fault(422, "INVALID_TIMESTAMP");
  const p = v
    .match(/^(\d{4})-(\d\d)-(\d\d)T(\d\d):(\d\d):(\d\d)/)
    .slice(1)
    .map(Number);
  if (
    p[1] < 1 ||
    p[1] > 12 ||
    p[2] < 1 ||
    p[2] > new Date(Date.UTC(p[0], p[1], 0)).getUTCDate() ||
    p[3] > 23 ||
    p[4] > 59 ||
    p[5] > 59
  )
    throw fault(422, "INVALID_TIMESTAMP");
  return new Date(v).toISOString();
}
function intake(v) {
  const allowed = [
    "source_type",
    "source_namespace",
    "source_event_id",
    "subject",
    "description",
    "submitted_at",
    "source_reference",
  ];
  if (!v || typeof v !== "object" || Object.keys(v).some((k) => allowed.indexOf(k) < 0))
    throw fault(422, "UNSUPPORTED_FIELD");
  const p = {
    source_type: text(v.source_type, "source_type", 20),
    source_namespace: text(v.source_namespace, "source_namespace", 160),
    source_event_id: text(v.source_event_id, "source_event_id", 200),
    subject: text(v.subject, "subject", 200),
    description: text(v.description, "description", 2000, 3),
    submitted_at: iso(v.submitted_at),
    source_reference: v.source_reference
      ? text(v.source_reference, "source_reference", 200)
      : "",
  };
  if (["form", "email"].indexOf(p.source_type) < 0) throw fault(422, "INVALID_SOURCE_TYPE");
  return p;
}
function outcome(v) {
  const allowed = [
    "delivery_id",
    "case_id",
    "state_version",
    "final_state",
    "case_processed_at",
  ];
  if (!v || Object.keys(v).some((k) => allowed.indexOf(k) < 0))
    throw fault(422, "INVALID_OUTCOME");
  const p = {
    delivery_id: text(v.delivery_id, "delivery_id", 180),
    case_id: text(v.case_id, "case_id", 80),
    state_version: Number(v.state_version),
    final_state: text(v.final_state, "final_state", 20),
    case_processed_at: iso(v.case_processed_at),
  };
  if (!Number.isSafeInteger(p.state_version) || p.state_version < 1)
    throw fault(422, "INVALID_VERSION");
  if (["COMPLETED", "REJECTED"].indexOf(p.final_state) < 0)
    throw fault(422, "NON_TERMINAL_STATE");
  return p;
}
function hex(bytes) {
  return bytes.map((b) => ("0" + ((b + 256) % 256).toString(16)).slice(-2)).join("");
}
function hash(v) {
  return hex(
    Utilities.computeDigest(
      Utilities.DigestAlgorithm.SHA_256,
      JSON.stringify(v),
      Utilities.Charset.UTF_8,
    ),
  );
}
function authenticate(e) {
  let v;
  try {
    v = JSON.parse(e.postData.contents);
  } catch (_) {
    throw fault(400, "INVALID_JSON");
  }
  if (!v || typeof v !== "object" || Array.isArray(v)) throw fault(400, "INVALID_PAYLOAD");
  const key = props().getProperty(
    v.client === "app"
      ? "APP_SECRET"
      : v.client === "zapier"
        ? "ZAPIER_SECRET"
        : "INVALID_CLIENT",
  );
  if (
    !key ||
    typeof v.signature !== "string" ||
    !/^[a-f0-9]{64}$/.test(v.signature) ||
    typeof v.body !== "string" ||
    v.body.length > 65536 ||
    typeof v.nonce !== "string" ||
    !/^\w[\w-]{7,100}$/.test(v.nonce) ||
    !isFinite(Number(v.timestamp)) ||
    Math.abs(Date.now() - Number(v.timestamp)) > 300000
  )
    throw fault(401, "AUTH_REQUIRED");
  const expected = hex(
    Utilities.computeHmacSha256Signature(
      [v.client, String(v.timestamp), v.nonce, v.body].join("\n"),
      key,
      Utilities.Charset.UTF_8,
    ),
  );
  let diff = 0;
  for (let i = 0; i < 64; i++) diff |= expected.charCodeAt(i) ^ v.signature.charCodeAt(i);
  if (diff) throw fault(401, "INVALID_SIGNATURE");
  const s = book().getSheetByName("Nonces");
  const previous = rows("Nonces");
  if (previous.some((r) => r.values[0] === v.client + ":" + v.nonce))
    throw fault(409, "REPLAYED_ENVELOPE");
  previous
    .filter((r) => Number(r.values[1]) < Date.now())
    .reverse()
    .forEach((r) => s.deleteRow(r.n));
  s.appendRow([v.client + ":" + v.nonce, Date.now() + 600000]);
  let body;
  try {
    body = JSON.parse(v.body);
  } catch (_) {
    throw fault(400, "INVALID_JSON");
  }
  return { client: v.client, operation: body.operation, payload: body.payload || {} };
}
function handle(client, op, p) {
  const access = {
    app: [
      "intake.poll",
      "intake.ack",
      "intake.reject",
      "outcome.publish",
      "receipt.poll",
      "receipt.ack",
    ],
    zapier: ["intake.stage", "outcome.poll", "outcome.apply", "connection.test"],
  };
  if (!access[client] || access[client].indexOf(op) < 0)
    throw fault(403, "OPERATION_FORBIDDEN");
  if (op === "connection.test") return { connection: "Hikyu V7 relay", authenticated: true };
  if (op === "intake.stage") {
    const v = intake(p),
      id = hash([v.source_type, v.source_namespace, v.source_event_id]),
      old = find("IntakeQueue", id);
    if (old && hash(JSON.parse(old.values[1])) !== hash(v))
      throw fault(409, "SOURCE_EVENT_CONFLICT");
    if (!old) put("IntakeQueue", id, v, "PENDING");
    audit(v.source_event_id, op, old ? "DUPLICATE" : "STAGED");
    return { id, replayed: !!old };
  }
  if (op === "intake.poll") return { items: items("IntakeQueue", "PENDING") };
  if (op === "intake.ack" || op === "intake.reject") {
    const r = find("IntakeQueue", p.relay_id);
    if (!r) throw fault(404, "INTAKE_NOT_FOUND");
    put(
      "IntakeQueue",
      p.relay_id,
      JSON.parse(r.values[1]),
      op === "intake.ack" ? "IMPORTED" : "REJECTED",
    );
    audit(p.relay_id, op, op === "intake.ack" ? "IMPORTED" : "INVALID_INPUT");
    return { acknowledged: true };
  }
  if (op === "outcome.publish") {
    const v = outcome(p),
      old = find("OutcomeQueue", v.delivery_id);
    if (old && hash(JSON.parse(old.values[1])) !== hash(v))
      throw fault(409, "DELIVERY_CONFLICT");
    if (!old) put("OutcomeQueue", v.delivery_id, v, "READY");
    audit(v.case_id, op, "READY");
    return { id: v.delivery_id };
  }
  if (op === "outcome.poll")
    return {
      items: items("OutcomeQueue", "READY").map((i) => Object.assign({ id: i.id }, i.payload)),
    };
  if (op === "outcome.apply") {
    const v = outcome(p),
      queued = find("OutcomeQueue", v.delivery_id);
    if (!queued || hash(JSON.parse(queued.values[1])) !== hash(v))
      throw fault(409, "UNPUBLISHED_OUTCOME");
    const prior = find("Receipts", v.delivery_id);
    if (prior) {
      const saved = JSON.parse(prior.values[1]);
      if (saved.result === "FAILED") throw fault(409, "REPLAY_FROM_V7_REQUIRED", false);
      return saved;
    }
    const receipt = {
      receipt_id: v.delivery_id,
      delivery_id: v.delivery_id,
      case_id: v.case_id,
      state_version: v.state_version,
      final_state: v.final_state,
      case_processed_at: v.case_processed_at,
    };
    try {
      if (props().getProperty("FAIL_NEXT_EXTERNAL_WRITE") === "true") {
        props().deleteProperty("FAIL_NEXT_EXTERNAL_WRITE");
        throw fault(503, "EXTERNAL_WRITE_FAILED", true);
      }
      const s = book().getSheetByName("ExternalCases"),
        old = find("ExternalCases", v.case_id);
      if (old && Number(old.values[2]) > v.state_version) receipt.result = "STALE_IGNORED";
      else if (old && Number(old.values[2]) === v.state_version) {
        if (
          old.values[1] !== v.final_state ||
          new Date(old.values[3]).toISOString() !== v.case_processed_at
        )
          throw fault(409, "CASE_VERSION_CONFLICT");
        receipt.result = "ALREADY_APPLIED";
      } else {
        const line = [
          v.case_id,
          v.final_state,
          v.state_version,
          v.case_processed_at,
          new Date().toISOString(),
        ];
        if (old) s.getRange(old.n, 1, 1, 5).setValues([line]);
        else s.appendRow(line);
        receipt.result = "SYNCED";
      }
      receipt.external_record_id = "ExternalCases:" + v.case_id;
      receipt.synced_at = new Date().toISOString();
      put("Receipts", v.delivery_id, receipt, "PENDING");
      put("OutcomeQueue", v.delivery_id, v, "APPLIED");
      audit(v.case_id, op, receipt.result);
      return receipt;
    } catch (e) {
      receipt.result = "FAILED";
      receipt.error_code =
        e.code === "CASE_VERSION_CONFLICT" ? e.code : "EXTERNAL_WRITE_FAILED";
      put("Receipts", v.delivery_id, receipt, "PENDING");
      put("OutcomeQueue", v.delivery_id, v, "FAILED");
      audit(v.case_id, op, receipt.error_code);
      throw fault(
        e.status || 503,
        receipt.error_code,
        e.retryable === undefined ? !e.status || e.status >= 500 : e.retryable,
      );
    }
  }
  if (op === "receipt.poll")
    return { items: items("Receipts", "PENDING").map((x) => x.payload) };
  if (op === "receipt.ack") {
    const r = find("Receipts", p.receipt_id);
    if (!r) throw fault(404, "RECEIPT_NOT_FOUND");
    put("Receipts", p.receipt_id, JSON.parse(r.values[1]), "ACKNOWLEDGED");
    return { acknowledged: true };
  }
  throw fault(400, "UNKNOWN_OPERATION");
}
function doPost(e) {
  const lock = LockService.getScriptLock();
  let result;
  try {
    lock.waitLock(20000);
    const v = authenticate(e);
    result = { ok: true, data: handle(v.client, v.operation, v.payload) };
  } catch (err) {
    result = {
      ok: false,
      error: {
        status: err.status || 503,
        code: err.code || "RELAY_STORAGE_UNAVAILABLE",
        retryable: err.retryable === undefined ? true : err.retryable,
      },
    };
  } finally {
    if (lock.hasLock()) lock.releaseLock();
  }
  return ContentService.createTextOutput(JSON.stringify(result)).setMimeType(
    ContentService.MimeType.JSON,
  );
}
function doGet() {
  return ContentService.createTextOutput(
    JSON.stringify({
      ok: false,
      error: { status: 405, code: "SIGNED_POST_REQUIRED", retryable: false },
    }),
  ).setMimeType(ContentService.MimeType.JSON);
}
function injectOneSyntheticWriteFailure() {
  props().setProperty("FAIL_NEXT_EXTERNAL_WRITE", "true");
}
