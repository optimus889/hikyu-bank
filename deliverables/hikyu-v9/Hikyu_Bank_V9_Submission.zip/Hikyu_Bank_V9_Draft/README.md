# Hikyu Bank V9 — Submission draft

The Transactions page now combines inclusive UTC dates, transaction type and a literal case-insensitive keyword. It searches the signed-in user's ledger in PostgreSQL and lists 25 rows at a time. V8 displayed only the latest 100 rows on that page. Its date-based CSV export remains separate and continues to use the original server handler.

V9 rebuilds the existing transaction list and filters with native HTML, CSS and a JavaScript module. The Saltcorn plugin serves the view and a read-only JSON endpoint under the existing signed-in session. Filters are typed and bound in SQL, and the owner ID comes from the session. The V9 feature requires no database migration or change to transaction writes.

- [Use case and acceptance criteria](docs/V9_USE_CASE.md)
- [Baseline inspection and test results](docs/V9_VERIFICATION.md)
- [AI usage and manual review instructions](docs/AI_USAGE.md)
- [External sources](docs/EXTERNAL_SOURCES.md)
- [Student review record](docs/MANUAL_REVIEW.md)
- The English reflection draft is provided separately.
- [Inherited external integration setup](docs/V7_Setup_and_Demo_Guide.md)

## Baseline status

V9 uses the uploaded `Hikyu_Bank_V8.zip` as its source baseline. The baseline was recorded as local commit `378ef96` before applying V9. The supplied V5 project is a reference for the earlier Spring Boot local deployment. V9 retains V8's `frontend/` and `backend/` layout, Saltcorn sessions, PostgreSQL and Flowable workflow. The local classifier and the optional relay and Zapier adapter remain available as inherited V8 runtime components. See [baseline inspection](docs/V9_VERIFICATION.md) for details.

## Run locally

Use a fresh extraction directory with Node.js 22+, npm, Python 3, a JDK 17+ and Docker Compose. The installer uses the package registries declared in the npm lockfile and Maven Wrapper. The demo generates synthetic accounts, a dedicated local PostgreSQL database and private settings. The external synchronization relay defaults to disabled.

```sh
python3 backend/prepare_v9.py --check
python3 backend/prepare_v9.py
```

Open http://127.0.0.1:8497/page/transactions. Read the generated requester credentials locally in `private/saltcorn-accounts.json`. Use the `requester` entry and keep that file private. The default workflow port is 8496. PostgreSQL maps to 55606. Restart an existing installation with `python3 backend/prepare_v9.py --start-only`. For a separate instance, select unused app and workflow ports in a new `private/v8-runtime.json` and set `V6_DB_PORT` before the first full setup. Use only generated demo data for testing.

## Demonstrate and test

Open Transactions, enter a keyword copied from a visible transaction, and select its type and date range. Apply the filters together and verify that every remaining row matches. Clear filters and check that the results return. Try a keyword with no matches and a reversed date range. The separate CSV form accepts its own date range.

For automated verification, install the existing pinned Playwright dependency and use system Chromium. Set `CHROMIUM_PATH` for the new test if Chromium lives outside `/usr/bin/chromium`. The inherited CSV test expects `/usr/bin/chromium`. Execute from the standalone application root while the demo is running.

```sh
npm ci --prefix backend/v7/tests
export NODE_PATH="$PWD/backend/v7/tests/node_modules"
node backend/v9/tests/transactions.cjs
node backend/saltcorn/test_csv.cjs
node --test backend/v8/tests/unit.cjs
python3 backend/test_workflow_http.py
```

Expected from the recorded V9 runs: 9 integration checks, 5 CSV checks, 14 inherited V8 unit tests and 9 workflow HTTP tests pass. The full setup also runs 6 Flowable build tests. The V9 suite uses isolated synthetic browser fixtures and removes rows it inserts. The inherited CSV suite adds synthetic test rows to the demo database. The project uses historical version numbers in some runtime filenames because they are active dependencies of the V8 application. The submission excludes the separate legacy applications and old delivery archives.

## Changed implementation

- `frontend/v9/transactions.html`, `transactions.css` and `transactions.js` form the native UI.
- `backend/v9/filters.cjs` validates filters and builds the owner-scoped query. `transactions.cjs` connects the UI and read endpoint to Saltcorn.
- `backend/saltcorn/hikyu-plugin/index.js` registers the routes. `frontend/banking-view.js` mounts the UI on the existing Transactions page.
- `backend/prepare_v9.py` starts the application with isolated defaults. The existing setup accepts the V9 title and retains its colocated Maven Wrapper.
- `backend/v9/tests/transactions.cjs` exercises the integrated view, session and database.
