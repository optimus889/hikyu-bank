# Hikyu Bank V9 — Submission draft

The Transactions page now combines inclusive UTC dates, transaction type and a literal case-insensitive keyword. It searches the signed-in user's ledger in PostgreSQL and lists 25 rows at a time. V8 displayed only the latest 100 rows on that page. Its date-based CSV export remains separate and continues to use the original server handler.

V9 rebuilds the existing transaction list and filters with native HTML, CSS and a JavaScript module. The Saltcorn plugin serves the view and a read-only JSON endpoint under the existing signed-in session. Filters are typed and bound in SQL, and the owner ID comes from the session. The V9 feature requires no database migration or change to transaction writes.

- [Use case and acceptance criteria](docs/V9_USE_CASE.md)
- [Baseline inspection and test results](docs/V9_VERIFICATION.md)
- [AI usage and manual review instructions](docs/AI_USAGE.md)
- [External sources](docs/EXTERNAL_SOURCES.md)
- [Student review record](docs/MANUAL_REVIEW.md)
- The English reflection draft is provided separately.
- [Inherited external integration setup](docs/V7_Setup_and_Demo_Guide.md)

## Baseline status

V9 uses the uploaded `Hikyu_Bank_V8.zip` as its source baseline. The baseline was recorded as local commit `378ef96` before applying V9. The supplied V5 project is a reference for the earlier Spring Boot local deployment. V9 retains V8's `frontend/` and `backend/` layout, Saltcorn sessions, PostgreSQL and Flowable workflow. The local classifier and the optional relay and Zapier adapter remain available as inherited V8 runtime components. See [baseline inspection](docs/V9_VERIFICATION.md) for details.

## Run locally

Use a fresh extraction directory with Node.js 22+, npm, Python 3, a JDK 17+ and Docker Compose. The installer uses the package registries declared in the npm lockfile and Maven Wrapper. The demo generates synthetic accounts, a dedicated local PostgreSQL database and private settings. The external synchronization relay defaults to disabled.

```sh
python3 backend/prepare_v9.py --check
python3 backend/prepare_v9.py
```

Open http://127.0.0.1:8497/page/transactions. Read the generated requester credentials locally in `private/saltcorn-accounts.json`. Use the `requester` entry and keep that file private. The default workflow port is 8496. PostgreSQL maps to 55606. Run the same command again after setup succeeds. It reuses the generated database and installed build artifacts if the setup inputs still match. Use `--start-only` to explicitly restart an already prepared installation, or `--rebuild` to rerun setup with the existing local database. For a separate instance, select unused app and workflow ports in a new `private/v8-runtime.json` and set `V6_DB_PORT` before the first full setup. Use only generated demo data for testing.

## Startup progress and troubleshooting

First-time setup reports PostgreSQL, npm, native Saltcorn setup, the local classifier, the Flowable Maven build and service startup separately. npm and Maven can take longer when dependency caches are empty. The Maven Wrapper may be quiet during its initial download. Wait for the final `V9 Transactions:` line before opening the app. If the Maven build exceeds 15 minutes, setup exits with a message.

The npm deprecation and audit messages are separate from startup progress. An `added ... packages` line indicates that npm completed that installation step. This update preserves the pinned dependencies and does not resolve the reported audit findings. Do not apply a forced dependency upgrade as part of startup troubleshooting. Use the seeded demo locally.

For a first setup that stopped before the final URL, run the regular V9 setup command again. For an installation that has reached the URL previously, use `python3 backend/prepare_v9.py --start-only` if you only need to start services. If Saltcorn or Flowable exits during startup, the command points to its local log:

```sh
tail -n 60 private/workflow-server.log
tail -n 60 private/saltcorn-server.log
```

If neither log exists, the process may still be in an earlier setup phase. For diagnosis, retain the terminal output from the last named phase and redact credentials before sharing any local log. On macOS the setup uses the JDK reported by `/usr/libexec/java_home` when `JAVA_HOME` is unset. Set `JAVA_HOME` explicitly if you need to select a different installed JDK.

To update a local V9 folder while keeping its demo database, first stop the running setup command if one is still active. Replace only `backend/prepare_v9.py`, `backend/prepare_v6.py` and `backend/start-services.py` with the updated versions. Keep the original folder path and its `private/` directory. The Compose project name is tied to the folder path. Run `python3 backend/prepare_v9.py` in that same folder.

### PostgreSQL password authentication failed (28P01)

If the local container is healthy but Saltcorn reports a password failure for the demo role, the generated local configuration and the stored PostgreSQL role password do not agree. Recreating the container does not reinitialize an existing data volume.

Keep the original V9 folder and its `private/` directory. If updating the scripts in place, copy `backend/prepare_v6.py`, `backend/prepare_v9.py` and `backend/local_db_auth.py` from the updated ZIP to that folder. From the folder containing `README.md`, run:

```sh
python3 backend/prepare_v9.py --repair-db-auth &&
python3 backend/prepare_v9.py
```

The explicit repair targets the named Compose volume and the automatically generated demo role for this project. It confirms TCP authentication after aligning the password with the local settings. It does not delete the volume, run migrations or print the password. If the PostgreSQL socket rejects the local role or repair cannot be verified, keep the original volume for further diagnosis.

For a separate fresh demo, extract the archive to a new directory. Use distinct ports if the previous demo is still running. The example below is for a fresh extraction only:

```sh
mkdir -m 700 private
(umask 077; printf '%s\n' '{"app_port":8498,"workflow_port":8499}' > private/v8-runtime.json)
V6_DB_PORT=55607 python3 backend/prepare_v9.py
```

### Demo account creation failed after database authentication

If the old setup reports `User creation failed` after PostgreSQL authentication succeeds, the local database may already contain the seeded demo users while the generated `private/saltcorn-accounts.json` is missing or empty. Copy the updated `backend/saltcorn/bootstrap.cjs` into the same installation and retry:

```sh
python3 backend/prepare_v9.py --rebuild
```

When rebuilding the missing demo credential file, setup reuses the matching synthetic accounts and regenerates their local sign-in passwords. Existing user IDs and their records are retained. The generated passwords are saved in `private/saltcorn-accounts.json`. Use the current `requester` entry after startup.

### The login page rejects my demo email or password

Use the URL printed by the running V9 installation. From its original project folder, verify the saved requester login against its local database:

```sh
node backend/v9/check-login.cjs
```

If the tool reports a password mismatch, regenerate only the local requester password:

```sh
node backend/v9/check-login.cjs --reset-requester
```

Run `node backend/v9/check-login.cjs --show-password` to view the current password in your local terminal. Open the login URL printed by the tool and use the complete email address. The reset retains the user ID, transaction ownership and other demo passwords. If the local files or requester entry are missing or invalid, follow the setup messages before retrying. Do not share the password or the contents of the private account file.

## Demonstrate and test

Open Transactions, enter a keyword copied from a visible transaction, and select its type and date range. Apply the filters together and verify that every remaining row matches. Clear filters and check that the results return. Try a keyword with no matches and a reversed date range. The separate CSV form accepts its own date range.

For automated verification, install the existing pinned Playwright dependency and use system Chromium. Set `CHROMIUM_PATH` for the new test if Chromium lives outside `/usr/bin/chromium`. The inherited CSV test expects `/usr/bin/chromium`. Execute from the standalone application root while the demo is running.

```sh
npm ci --prefix backend/v7/tests
export NODE_PATH="$PWD/backend/v7/tests/node_modules"
node backend/v9/tests/transactions.cjs
node backend/saltcorn/test_csv.cjs
node --test backend/v8/tests/unit.cjs
python3 backend/test_workflow_http.py
```

Expected from the recorded V9 runs: 9 integration checks, 5 CSV checks, 14 inherited V8 unit tests and 9 workflow HTTP tests pass. The full setup also runs 6 Flowable build tests. The V9 suite uses isolated synthetic browser fixtures and removes rows it inserts. The inherited CSV suite adds synthetic test rows to the demo database. The project uses historical version numbers in some runtime filenames because they are active dependencies of the V8 application. The submission excludes the separate legacy applications and old delivery archives.

## Changed implementation

- `frontend/v9/transactions.html`, `transactions.css` and `transactions.js` form the native UI.
- `backend/v9/filters.cjs` validates filters and builds the owner-scoped query. `transactions.cjs` connects the UI and read endpoint to Saltcorn.
- `backend/saltcorn/hikyu-plugin/index.js` registers the routes. `frontend/banking-view.js` mounts the UI on the existing Transactions page.
- `backend/prepare_v9.py` starts the application with isolated defaults. The existing setup accepts the V9 title and retains its colocated Maven Wrapper.
- `backend/v9/tests/transactions.cjs` exercises the integrated view, session and database.
