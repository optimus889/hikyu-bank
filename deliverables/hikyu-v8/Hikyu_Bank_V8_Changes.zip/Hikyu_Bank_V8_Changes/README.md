# V8 Changes-Only Package

This is not a complete application. Apply only against confirmed repository baseline f1271f24330cf8aad0fe5f8dc43834ea49d3800a. Review CHANGES.json and preserve local edits. File paths under files/ are repository-relative. No deletion is required. Use Hikyu_Bank_V8.zip for a complete standalone installation.
