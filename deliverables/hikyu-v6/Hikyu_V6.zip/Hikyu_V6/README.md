# Hikyu Bank Project V6

A local LCNC + AI iBPM coursework demonstrator, combining the user-provided V5 source with new native Saltcorn pages/data/actions, a real Flowable human workflow, a real local supervised classifier, tests, documentation and screenshots.

**Start here:** `deliverables/V6_Setup_and_Demo_Guide.md`. For an independently prepared copy with Node.js, Python, Docker and JDK 17+ available:

```sh
python3 implementation/prepare_v6.py --check
python3 implementation/prepare_v6.py
```

The setup creates new private secrets and task-specific databases. It does not load `.env.supabase`, old database destinations or the original external V5 volume. Do not use the preserved V5 launchers as the V6 startup entry point.

- `implementation/v5-working/`: the supplied V5 Java/JavaScript source, preserved as the functional baseline, with private configuration and old build output excluded.
- `implementation/saltcorn/`: the updated LCNC application and source-controlled platform extensions.
- `implementation/workflow/`: real BPMN engine, delegates, authorization and task APIs.
- `implementation/ai/`: synthetic supervised model and actual runtime inference.
- `deliverables/`: English Word/Markdown report, test results, setup guide, reflection, coverage and native export.
- `evidence/`: actual safe logs, JSON records and unmodified browser screenshots.
- `research/`: inspected official documentation/license snapshots and retrieval records.

No passwords, PINs, service tokens, database files, node_modules or old binaries are included. Dependencies must be installed. The environment is locally deployed; no public hosting or environment publication is claimed.

This is a tested V6 demonstrator, not a claim of complete V5 equivalence: original login MFA, full registration/security/session behavior, original assistant/scheduled alerts, full transaction UI and mobile parity remain incomplete. Human workflow tests used one operator with separate role accounts. See the report before presenting results.
