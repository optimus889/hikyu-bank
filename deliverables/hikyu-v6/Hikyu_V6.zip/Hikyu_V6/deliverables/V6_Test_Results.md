# V6 Test Results

Date: 3 November 2026. All business data and test identities were generated in this task. Status vocabulary: **Pass**, **Fail**, **Blocked**, **Not tested**. A definition/configuration check is not an end-to-end pass. All multi-role results below are **single-person role simulation using separate accounts/browser sessions**, not different people participating.

## Executed suites and evidence

| ID | Scope and prerequisites | Steps and expected result | Actual result | Status / evidence |
|---|---|---|---|---|
| B01 | Fresh uploaded V5 working copy; new PostgreSQL database | Clean Maven package with the dedicated test DB; all selected backend tests execute | 93 tests; zero failures/errors/skips | Pass — `evidence/v5-backend.log` |
| B02 | Uploaded V5 frontend and Node | Execute `npm test`; selected files complete | Five test-file executions pass | Pass — `evidence/v5-frontend.log` |
| B03 | Uploaded V5 startup fixtures | Run existing Python startup suite | 14 tests pass | Pass — `evidence/v5-startup.log` |
| B04 | Fresh V5 demo DB and browser; newly registered account | Register, login, simulated SMS/PIN verification, load accounts and six routes | Registration/session/account data and routes work; no captured JS page errors | Pass — `evidence/v5-browser.json`, `v5-browser.log`, `v5-login.png`, `v5-overview.png` |
| B05 | Original uploaded archive remains available | Compare every extracted original file against its archive bytes | 651 files checked, zero changed | Pass — `evidence/baseline-integrity.json`, `source.json` |
| C01 | Saltcorn 1.6.2 installed in isolated directory | Inspect native types/roles/templates; create owned data, views and pages | Native editor/runtime, metadata and persistent fixtures created | Pass, configuration/runtime check — `evidence/saltcorn-capabilities.log`, `saltcorn-bootstrap.json` |
| C02 | New LCNC native account | Log in and render bound overview | Actual owner-specific data and page render | Pass — `evidence/saltcorn-browser-probe.log`, `lcnc-login.png`, `lcnc-overview.png` |
| W01 | Real Flowable 7.1.0 engine and local model | Execute BPMN success, handoff, return/resubmit, reject, AI-error boundary, timer path and role-wrapper denial | Six JUnit tests pass | Pass, engine integration — `evidence/workflow-build.log`; `workflow-success.txt` identifies the separate in-memory spike |
| W02 | Persistent workflow HTTP server and generated roles | Test runtime model, task decisions, same/changed duplicates, invalid input, anonymous/foreign/wrong-role/stale requests | Nine HTTP tests pass | Pass, local HTTP integration — `evidence/workflow-http-tests.log`, `workflow-http-events.json` |
| W03 | Completed engine record on disk | Restart server; compare ID, state, sequence, AI output, actor, comment and timestamp | Same durable values survive | Pass — `evidence/workflow-restart.json` |
| E01 | Saltcorn + Flowable + normal local model; requester/service/reviewer sessions | Submit from LCNC, observe AI, agent handoff, reviewer complete, refresh same row | Same LCNC row/business ID retains real process ID and completed outcome | Pass, real LCNC E2E / role simulation — `evidence/lcnc-e2e.json`, `lcnc-request-submitted.png`, `lcnc-reviewer-handoff.png`, `lcnc-completed-refresh.png` |
| E02 | Same real LCNC path | Replay unchanged submission; reuse key with changed text; submit blank text; use another owner's transaction; attempt unauthorized decision | Eight total E2E checks including E01 passed; duplicate uses same row, invalid operations rejected | Pass — `evidence/lcnc-e2e.json` |
| R01 | Real LCNC and engine | Return request, resubmit as requester, reject as agent | Each state persists on same business record | Pass — `evidence/lcnc-resilience.json` |
| R02 | Real LCNC task and wrong role/stale version | Attempt unauthorized review and stale decision; attempt direct native status write; project an old non-final state over final | Denied; final row unchanged | Pass; includes native-model/writeback-component checks against live DB — `evidence/lcnc-resilience.json` |
| R03 | New LCNC submission with actual workflow service stopped | Submit, inspect durable pending row, restart real service, allow automatic reconciliation | Same business record obtains the real process ID and service-review state | Pass — `evidence/lcnc-resilience.json` |
| R04 | Existing real LCNC/engine request; temporary constraint only on a synthetic row | Prevent reviewer-state DB update, commit engine handoff, observe 503/pending projection, remove constraint, allow reconciliation | Engine task retained; LCNC writeback recovers without duplicate task | Pass, actual PostgreSQL write failure — `evidence/lcnc-resilience.json` |
| R05 | Completed real LCNC record | Restart LCNC process, reload browser and inspect same row | IDs, final state and sequence retained | Pass — `evidence/lcnc-resilience.json`, `lcnc-recovery-refresh.png` |
| F01 | Trusted server-side test override, normal LCNC submit | Cause classifier subprocess to exceed actual five-second timeout | LCNC shows `MANUAL_TRIAGE`; no approval | Pass, controlled fault injection — `evidence/ai-fault-timeout.json` |
| F02 | Trusted server-side invalid-output fixture | Return an invalid category/confidence/review payload | Validated as failure and routed to manual triage | Pass, controlled fault injection — `evidence/ai-fault-malformed_output.json` |
| F03 | Trusted server-side failing subprocess fixture | Make process exit unsuccessfully | LCNC shows manual triage | Pass, controlled fault injection — `evidence/ai-fault-process_failure.json` |
| T01 | Real engine timer with controlled `PT2S` test SLA | Agent hands off; timer actually expires; supervisor completes; LCNC updates | Escalation and final result persist; normal server restored to `PT24H` | Pass, real timer / accelerated SLA test — `evidence/lcnc-human-timeout.json`, `lcnc-human-timeout.png` |
| A01 | Local supervised classifier | Train on 24 synthetic examples; classify six separate synthetic holdout examples | Six expected classifications; tiny nonrepresentative holdout only | Pass, bounded model check — `evidence/ai-holdout.json` |
| A02 | Normal workflow service task | Invoke actual trained model on synthetic request at runtime | Real input/output and model metadata recorded | Pass — `evidence/ai-live-*.json`; nominal E2E process correlation in `lcnc-e2e.json` |
| P01 | Native LCNC banking actions, owned synthetic accounts/PIN | Verify own transfer, exact balances, balanced legs, replay/conflict, insufficient funds, wrong-code counter, lock/unlock, credit purchase/repayment, peer payment, bill payee/payment, budget, cross-user denial, invalid amounts and browser cards/budget | 14 banking checks pass | Pass — `evidence/lcnc-banking-tests.json`, `lcnc-banking-overview.png`, `lcnc-budgets.png` |
| P02 | Native statement endpoint and zero-value synthetic CSV fixtures | Export inclusive dates; formula-text neutralization; exclude other user's row; reject blank/invalid/excessive dates and foreign account | Five CSV checks pass | Pass — `evidence/lcnc-csv-tests.json` |
| X01 | Native current LCNC configuration | Take fresh platform snapshot and export definitions without row data or credentials | Native tables/views/pages exported | Pass, export check — `evidence/platform-export.json`, `deliverables/Saltcorn_V6_Application_Pack.json` |

The ten resilience checks, eight E2E checks, fourteen banking checks and five CSV checks are scenario assertions in their respective live integration scripts. They are not presented as additional independent participants or as the same test runner as the 93 V5 JUnit tests. Normal AI evidence and AI fault fixtures are kept distinct.

## Failures diagnosed during implementation

| Observation | Diagnosis and correction | Final disposition |
|---|---|---|
| Bubble/other vendor official web pages returned proxy 403 | Access limitation; official GitHub snapshots used where available; user changed LCNC platform | Bubble editing/pricing verification Blocked and superseded; no invented entitlements |
| Budibase application container could not be created | Actual `no space left on device` under Docker vfs | Failed approach; task-created unused resources removed; Saltcorn selected instead |
| Initial Saltcorn schema command prompted and exited | New empty DB needed documented noninteractive `add-schema -f` | Corrected; actual instance works |
| First LCNC support submit did not create a row | `current_role` is a PostgreSQL keyword and needed quoting | Corrected; nominal E2E rerun passes; old failure artifact retained as resolved history |
| Resilience harness could not find a CSRF hidden input when a role had no task form | Harness now uses the native CSRF global as fallback, keeping CSRF protection enabled | Corrected; ten checks pass |
| Early workflow dependency/compiler/deployment configuration errors | Maven proxy/system trust, valid Flowable API chaining and deployment name configured | Corrected; engine and live tests pass |

## Outstanding and unrun checks

| Requirement/check | Status | Reason / next action |
|---|---|---|
| Different people actually receiving/completing tasks | Not tested | Only one operator used separate synthetic accounts, as the user requested; arrange participant-run acceptance later |
| Public Internet deployment, HTTPS/domain and external access | Not tested | Current deployment is local self-hosting; no public infrastructure was purchased or configured |
| Exact V5 username/password + simulated login MFA parity | Not tested / incomplete implementation | Native LCNC email/password authentication is used; financial code/PIN checks are separate |
| Full original V5 registration, password/PIN change and global session revocation | Not tested / incomplete implementation | Requires further native authentication/profile workflow work |
| Full original assistant and every alert preference/scheduled reminder | Not tested / incomplete implementation | V6 runtime classification and financial receipt/alert foundations do not equal the original assistant/scheduler |
| Complete transaction search, stable pagination/sorting/detail UI equivalence | Not tested / incomplete implementation | Basic history and protected CSV are implemented; full source behavior has not been ported |
| Complete account-opening, layout/mobile and accessibility equivalence | Not tested / incomplete implementation | Eight pages/core desktop components exist; no complete parity/mobile audit was run |
| Concurrent multi-instance/load/penetration/production tests | Not tested | Local functional tests establish only their documented scope |
| Restore native pack into a separate fresh installation | Not tested | Export structure is checked; artifact generation is not a restoration pass |
| A real 24-hour wall-clock timeout wait | Not tested | The real engine timer path was exercised with an explicitly accelerated two-second test deadline |
