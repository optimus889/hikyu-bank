# V5 to LCNC reconstruction and acceptance specification

Basis: this task's uploaded `Hikyu-Bank-Project-V5.zip`, extracted source and fresh V5 runtime only. The user subsequently replaced the Bubble-only requirement with permission to use another editable LCNC platform. Final target: self-hosted Saltcorn 1.6.2; Budibase failed to fit the managed vfs storage. This document is a specification; it does not certify that the target has passed.

## UI and application logic

| Actual V5 feature and source | LCNC reconstruction | Acceptance criterion |
|---|---|---|
| `frontend/login.html`, `register.html`, `verify.html`, `js/auth/*` | Native authenticated users plus a deliberately separate simulated verification step; retain registration, sign-in, validation and English labels | New user registers, wrong password fails, code and permanent PIN required, replay/expiry rejected. Native authentication alone does not replicate simulated MFA. |
| `frontend/index.html`, `css/figma-web.css`, `js/app.js` | Shared navy navigation, white/blue cards, English headings, desktop horizontal navigation and responsive menu | Compare actual captured V5 overview at 1440 px; test mobile separately. Source `<aside>` does not imply a visible desktop sidebar. |
| `components/overview.js`, `accounts.js`, `open-account.js` | Bound account cards, recent activity, account details, create-account action and alerts panel | Show persisted owner-specific accounts, amounts and status; prohibit a second open checking/savings account. |
| `views/transactions-view.js`, `TransactionQueryController` | Search/filter/sort/page list, read-only detail and CSV export | Inclusive dates, stable pagination, owner scoping, CSV formula protection and date/record limits preserved. |
| `views/transfers-view.js`, `PaymentController`, `PaymentVerificationController`, `ExtensionController` | Own-account transfer, recipient verification, saved recipients, simulated code/PIN confirmation, durable receipts | Preserve insufficient-funds, account ownership, code binding, concurrency, idempotency and two balanced ledger legs. Hiding a button is insufficient. |
| `views/banking-navigation.js`, `BankingController`, `BankingService` | Pay & Transfer tabs: Between my accounts, To another person, Saved recipients, Bill Pay | Real data binding and workflows for each; no invented standalone Banking page as the only navigation. |
| Same banking source | Accounts & Cards: Your accounts, Cards; credit repayment reached from account detail | Locked cards reject purchases; transfers/repayments follow actual V5 rules; overpayment rejected. |
| Same banking source | Financial Insights: Budgets, AI assistant | UTC month boundaries, owned budgets, excluded internal/credit repayments; assistant demo mode clearly distinguished from runtime V6 classifier. |
| Same banking source | Demo Tools: Simulate purchase | Review, permanent PIN + demo code, receipt and persisted financial operation; no real payment network. |
| `views/settings-view.js`, `SecurityController` | Nickname/preferences, password/PIN changes, session invalidation | Wrong current credentials rejected; no password/PIN returned; cross-user changes rejected. |
| `components/alerts.js`, `notification-inbox.js` | Alerts and recipient-specific inbox | Threshold and schedule validation; enable/disable, event deduplication, read/resolve persistence. |
| New V6 extension | Transaction Support Review plus staff task views | Selected transaction belongs to requester; runtime classifier; agent-to-reviewer handoff; return/reject/complete/escalation; durable LCNC status and refresh. Does not modify a settled transaction. |

## Data and constraints

Authoritative observed metadata: `evidence/v5-observed-schema.json`; schema-only export: `implementation/V5_Observed_Schema.sql`. Applied migrations V1–V8 are source version numbers, not the V6 assignment version.

| Actual V5 entity | LCNC representation | Required constraints and migration rule |
|---|---|---|
| users | Native platform identity plus private UserProfile | Keep source UUID as `source_v5_id` and platform user ID separately. Do not import password/PIN hashes as usable platform passwords. Register new synthetic users. |
| accounts | Account linked to UserProfile | Checking/savings/credit/loan/investment enum; nonnegative finite money; four-digit suffix; owned records; one active/pending deposit account per type. |
| transactions | Transaction linked to Account and optional operation | Immutable settled entries; signed exact money; supported kind; related transfer/payment/operation IDs; unique ledger leg per account. |
| alerts | Alert linked to owned Account | Appropriate threshold or schedule, valid type/channel, enable flag. |
| notifications; notification_recipients; notification_account_links | Notification, NotificationRecipient, optional Account link | Recipient ownership; resolving implies read; event deduplication. |
| user_preferences | UserPreference | Private per user; settings persist. |
| transfers; alert_events | Transfer and TransferAlertEvent | Positive exact amount; different source/target; owner; unique owner+idempotency key; atomic ledger pair and alert event. |
| peer_payments; peer_alert_events | PeerPayment and PeerAlertEvent | Different sender/recipient; idempotent request hash; masked recipient verification; two owned ledger legs. |
| payment_verifications | Private PaymentVerification | Hash-only secret, expiry, attempts and lockout; bound session+request fingerprint; do not expose all records to client. |
| saved_payees | SavedPayee | Owned; peer/biller; owner+kind+identifier unique; soft deletion retains history. |
| card_controls | CardControl linked one-to-one to Account | Owned card; lock flag; purchase validation performed on server. |
| budgets | Budget | Unique owner+month+category; first day of UTC calendar month; positive limit. |
| financial_operations; financial_alert_events | FinancialOperation and FinancialAlertEvent | purchase/repayment/bill; owned account/payee references; required relationships; positive amount; durable idempotency and balanced repayment. |
| New V6 SupportRequest | LCNC-owned business record | `business_id`, requester, owned transaction ID, description, process_instance_id, state, sequence, ai_category, ai_confidence, ai_model_version, current_role, created_at, updated_at, outcome, comments. Source of truth for business request. |
| New V6 Process projection | Flowable-owned execution data | Instance, active task, assignee/candidate groups, timer, history and AI execution evidence. It must not become a competing financial ledger. |

LCNC string IDs and source UUIDs are different identifiers. Store explicit mapping; do not equate them. Unique indexes, row locks, multi-record atomic updates and exact monetary arithmetic must be verified in the chosen persistence layer. A series of visual update actions is not evidence of equivalent atomicity. Retaining PostgreSQL constraints through a supported datasource is preferable to weakening V5 behavior.

## Access acceptance

Requesters may see only their own accounts, transactions, support requests and requester-correction tasks. Service agents see assigned support context, not all financial tables. Reviewers see review tasks and minimal required context. Supervisors see escalations. Builder privileges are separate and never granted to demo requesters. All row ownership and task-role checks must occur on the server, with two-account negative tests. No anonymous financial endpoints or client-side service keys are permitted.
