# Hikyu Bank V6 — LCNC and AI iBPM Assignment Report

**Status:** Working local V6 demonstrator with a tested LCNC–AI–human workflow. This is not a claim of complete V5 feature equivalence, public hosting, production banking readiness, or real multi-person testing.

**Evidence date:** 3 November 2026. **Source boundary:** Only the uploaded `Hikyu-Bank-Project-V5.zip`, this task's instructions, official sources inspected during this task, and newly generated synthetic data. No old deployment, account, database destination or earlier test result was used. A private environment file in the archive was preserved but not loaded. All 651 extracted archive files were checked unchanged.

## Step 1 — Select and set up an LCNC platform

The original instruction selected Bubble. The user subsequently authorized switching to another editable LCNC platform. The final platform is **Saltcorn 1.6.2**, installed from the official npm package under a locked dependency manifest. Its official repository describes an open-source no-code database application builder with views, layouts, datatypes and actions; its license is MIT. The native editor, PostgreSQL-backed data, page definitions, reusable views and application actions run in this task's new environment.

Bubble pricing/API pages could not be retrieved through the environment policy. No Bubble project editing, preview, live release, upgrade or trial occurred. Exact current Bubble plan entitlements therefore remain unverified and are superseded by the platform-change instruction.

Budibase was evaluated first. Its official deployment images exhausted the managed Docker vfs storage during application-container creation. The failed task-created deployment and its unused images were removed. Saltcorn was chosen after successful installation and actual editing/data/workflow verification, rather than claiming the failed Budibase deployment worked.

The selected combination uses free self-hosted software and existing task compute. Hosting, operations, backups and any future public domain remain separate costs. No permanent free public hosting is claimed, no paid module was purchased, and no external AI subscription is required. The local service is a self-hosted deployment, not a publicly reachable website. No environment version was published by the agent.

## Step 2 — Reconstruct the V5 components

The uploaded V5 uses Spring Boot 3.5.16, Java 17 compilation, native JavaScript modules, PostgreSQL and Flyway migrations V1–V8. V6 assignment numbering is independent of SQL migration numbering. The archive's previously generated binaries/results were not trusted: a clean working copy excluded private environment files and build outputs, then compiled and tested against a newly created database.

Fresh baseline validation passed 93 backend tests, five frontend test-file executions and 14 startup tests. A newly registered synthetic V5 account passed a real browser login/code/PIN flow and loaded six routes. The rendered desktop interface has horizontal navy navigation; the source `<aside>` tag was not mistaken for a visible desktop sidebar.

The LCNC application contains eight native pages, native data definitions and reusable views. Its page layouts can be edited in Saltcorn; custom reusable view/action extensions supply security-sensitive business behavior. The build used the platform SDK/CLI and browser validation, not an invented manual drag-and-drop experience. See [the detailed mapping](V5_to_LCNC_Mapping.md).

Implemented and tested financial components include owned account cards, persistent transactions, exact integer-cent amounts, own-account transfers, peer payments, debit/credit purchases, credit repayment, saved demo billers, bill payment, card locking, budgets and CSV statements. The native action implementation serializes users/accounts in PostgreSQL transactions, stores idempotency hashes, binds simulated authorization codes to sessions and request fingerprints, and writes linked ledger legs. PINs use salted scrypt hashes; no PIN is returned by a financial action. Direct user writes to financial and workflow state fields are restricted.

V5 UUIDs and Saltcorn integer row IDs are separate identifiers. Synthetic `source_v5_id` values are explicitly separate from native IDs; no claim is made that real V5 records were migrated. The normalized V5 notification-recipient and financial-event tables are represented using owned notification rows and a unified event table. This is a documented representation change, not byte-identical schema migration.

**Parity gaps:** Native email/password sign-in replaces V5 username/password plus simulated login MFA; payment code/PIN checks are implemented separately. Full original registration/profile/security/session-management behavior, all alert scheduling/preferences, the original financial assistant, complete transaction filtering/pagination/detail behavior, account-opening behavior and complete mobile/layout equivalence have not been fully ported and verified. These remain incomplete, not silently marked passed.

### Development experience

V5 expresses constraints and transactions in Java/SQL, with Maven compilation and JUnit tests. Saltcorn exposes tables, fields, ownership and page/view metadata directly and provides a live editor and native export pack. These generated views made the data structure visible quickly. Exact monetary behavior, authorization-code binding and transaction atomicity still required a coded extension and real database tests; a visual sequence of row updates would not have preserved the guarantees. CLI changes required reloading the application to refresh process-local metadata. Debugging included a real SQL keyword collision and a test harness CSRF-source issue, both corrected and retested. Configuration export aids version review, but no time-saving percentage or measured productivity gain is claimed.

## Step 3 — Compare and select an AI iBPM platform

[Platform_Comparison.md](Platform_Comparison.md) compares **Flowable Open Source** and **n8n Community**, using inspected official repository documentation. Criteria cover task assignment, human review, modeling, automation, state, audit, exceptions, AI, integration, licensing and hosting.

Flowable 7.1.0 was selected after the actual Saltcorn → runtime AI → service-agent/reviewer handoff → persisted Saltcorn writeback chain passed. Its Apache 2.0 engine provides executable BPMN, human tasks, gateway branches, timers and history. This implementation adds AI through a real service delegate; it does not claim that the open-source engine includes a hosted generative-AI entitlement. The n8n comparison found documented AI human-review support and indefinite Community self-hosting, but also Community limits on projects, sharing and governance. n8n was researched, not executed.

## Step 4 — Implement a multi-participant workflow

**Business case:** Transaction Support Review, derived from V5's actual owned transaction history and card/payment features. It adds support handling without changing a settled transaction or making a real credit decision.

| Participant | Task | Handoff |
|---|---|---|
| Requester | Select an owned transaction; describe a synthetic issue; supply missing information if returned | Service agent |
| Service agent | Review the runtime AI category and transaction context; continue, return or reject | Independent reviewer or requester |
| Reviewer | Independently complete or reject the proposed handling | Final result |
| Supervisor | Handle an overdue review | Final result |

The executable definition is `implementation/workflow/src/main/resources/transaction-support.bpmn20.xml`. The deployment binds the AI service delegate, stage-version listener and final-state listener. Real task history records assignees. Candidate groups alone are not treated as sufficient authorization: the service checks the authenticated role, business-record ownership, active task and expected version. The agent and final reviewer must be different identities.

```mermaid
flowchart TD
    A[Requester submits] --> AI[Local ML classification]
    AI --> S[Service agent checks context]
    AI -->|Failure or invalid output| M[Manual triage]
    M --> S
    S -->|Return| R[Requester adds information]
    R --> AI
    S -->|Reject| X[Rejected]
    S -->|Continue| V[Independent reviewer]
    V -->|Complete| C[Completed]
    V -->|Reject| X
    V -->|Task timeout| E[Supervisor handles escalation]
    E --> C
    E --> X
```

Uniform displayed states are `SUBMITTED`, `MANUAL_TRIAGE`, `SERVICE_REVIEW`, `RETURNED`, `REVIEWER_REVIEW`, `ESCALATED`, `COMPLETED` and `REJECTED`. Integration errors are separate synchronization metadata, not a fabricated successful business state. Return goes back to classification; final states cannot be overwritten by late non-final projections. The normal reviewer deadline is 24 hours. A controlled two-second test deadline caused a real timer expiry and persisted escalation; no claim is made that a 24-hour wait was observed.

All role testing was performed by one operator using separate newly created accounts/browser contexts. Actual participation by different people remains Not tested.

## Step 5 — Integrate the LCNC application and workflow

```mermaid
flowchart LR
    U[Authenticated Saltcorn page] --> B[Server-side action and ownership checks]
    B --> D[(Saltcorn business data in PostgreSQL)]
    B --> F[Authenticated Flowable API]
    F --> H[(Persistent engine history and tasks)]
    F --> L[Local supervised classifier]
    F --> B
    Q[Server-side reconciliation worker] --> F
    Q --> D
    D --> U
```

`implementation/openapi.yaml` documents process submission, status retrieval and task decisions. The LCNC server creates the business row first and submits its stable `business_id`; Flowable returns `process_instance_id`. AI, stage, sequence, timestamp and comments are projected into that same LCNC row. Browser refresh reads persisted data. The LCNC owns the business record and financial ledger; Flowable owns execution/tasks/timers/history. Its status response is a projection, not a competing banking database.

Generated role tokens and native account passwords are stored only in the task's private directory and server process configuration. Browsers receive native session cookies and CSRF protection, not workflow service tokens. Submitted text is data, never executable instructions. Errors use explicit HTTP statuses. Duplicate requests with unchanged content return the original record/process; changed content under the same key returns conflict. Task versions reject duplicate/late decisions. Correlation checks reject another process/business ID pairing.

A persistent database record precedes network submission. A background reconciliation worker uses exponential backoff (capped at 60 seconds) after failures and reads durable engine state after service recovery. Real tests stopped the API, restarted it, imposed a temporary PostgreSQL callback constraint, removed that constraint and observed automatic convergence. This is polling/reconciliation integration, not a claimed external webhook deployment. Polling and loopback HTTP are local-demo choices; a public deployment needs HTTPS, managed secrets, authentication hardening and hosting configuration.

### Actual AI implementation

The task uses a trained **multinomial Naive Bayes text classifier**, not mock output and not an LLM. Its three bounded labels are `card_access`, `payment_tracking` and `general_support`, with `unclassified` for entirely unknown tokens. Training uses 24 synthetic sentences. All six small synthetic holdout examples were classified as expected; this is not a production accuracy estimate or calibrated confidence guarantee.

The BPMN service task actually starts the Python classifier during execution, supplies only the description over standard input, validates its JSON schema/labels/confidence/model metadata and persists input/output evidence. No names, PINs, passwords, account balances or demographic fields are needed by the model. Every output requires human review; the model cannot approve or move funds.

Actual failure-mechanism tests used explicitly labeled controlled process fixtures for timeout, malformed output and process failure. All three reached `MANUAL_TRIAGE` through the live LCNC/engine chain. These fixtures are failure tests, not successful AI outputs. Normal classification was restored afterward.

## Step 6 — Reflect, evaluate and govern

[V6_Reflection.md](V6_Reflection.md) provides the required short English reflection. [V6_Test_Results.md](V6_Test_Results.md) separates baseline tests, real LCNC/engine integration, fault injection, role simulation, unresolved parity and unrun real-person/public-hosting checks. [V6_Requirements_Coverage.md](V6_Requirements_Coverage.md) maps every requirement group to evidence.

The system uses synthetic data, record ownership, minimal model input, server-side credentials, human review, bounded classification, task history, idempotency and monotonic state versions. Remaining concerns include weak generalization from a tiny training set, uncalibrated confidence, incomplete V5 authentication parity, code-extension maintenance, loopback-only HTTP and untested production load. The local demo is not suitable for real banking or automated credit decisions.

## Official sources and artifacts

Official-source URLs, inspected snapshots, version/commit records, unavailable pricing-page observations and research date are in [Platform_Comparison.md](Platform_Comparison.md). Saltcorn README/license/package metadata, Flowable README/license, and the pinned n8n official documentation are retained in `research/`. The native LCNC configuration export is [Saltcorn_V6_Application_Pack.json](Saltcorn_V6_Application_Pack.json); it contains definitions, not account passwords or business rows. Setup, restoration prerequisites and demo steps are in [V6_Setup_and_Demo_Guide.md](V6_Setup_and_Demo_Guide.md).
