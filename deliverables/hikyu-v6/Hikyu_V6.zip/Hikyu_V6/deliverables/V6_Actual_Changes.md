# Actual Changes and Export Inventory

All task work is under `/workspace/hikyu-v6`. No older repository or deployment was modified. The original uploaded archive is preserved; 651 extracted original files were verified unchanged.

## New runnable components

- Saltcorn 1.6.2: native tables, field ownership/write protections, eight native pages, reusable list/support/banking views, generated synthetic role accounts, persistent synthetic data and local plugin configuration.
- `implementation/saltcorn/banking.cjs`: integer-cent validation, request-bound code/PIN authorization, transaction/row locking, idempotency, transfers, peer payments, purchase/repayment/bill operations, receipts, recipients, card lock, budgets, alert foundations and CSV protection.
- `implementation/saltcorn/integration.cjs`: authenticated process calls, stable business/process correlation, monotonic LCNC projection and retry metadata.
- `implementation/saltcorn/sync.cjs`: server-side status reconciliation after connection or callback failure.
- `implementation/saltcorn/hikyu-plugin/`: actual local platform extension providing reusable support and banking view templates. Native page layouts embed these components; this is a low-code extension, not an assertion that every control was built without code.
- `implementation/workflow/`: Flowable 7.1.0 engine, executable BPMN, persistent task/history API, role/ownership checks, real classifier invocation and error/timer paths.
- `implementation/ai/`: trained local supervised model, synthetic training examples, inference code and held-out examples.
- `implementation/start-services.py`: current-instance startup/readiness/reconciliation instructions; no environment publication.
- Existing V5 source copied into an independent working tree for clean rebuilding/testing, excluding private environment files and old generated outputs. The submission combines that source with the V6 implementation without overwriting the original attachment.

## Actual platform exports

- `Saltcorn_V6_Application_Pack.json`: native configuration definitions, without passwords, tokens or business rows.
- `transaction-support.bpmn20.xml`: executable workflow definition; requires the included delegates/listeners/configuration.
- `openapi.yaml`: workflow interface contract.
- `V5_Observed_Schema.sql` and `v5-observed-schema.json`: actual structure-only observations from this task's fresh V5 database.
- `V6_Delivery_Manifest.json`: generated file/checksum inventory and exclusion record accompanying the packaged source.

## Deliberately excluded from submission ZIP

Private `.env` files from the upload; this task's `private/` directory; local passwords/PINs/tokens/session cookies; H2/PG business database files; node_modules; Maven caches; old `target/` binaries/results; Git metadata; failed Budibase images; old deployment destinations. Example configuration names and secure setup instructions are included instead.

## Known incompleteness

The archive is a runnable V6 local demonstrator plus preserved V5 source, not a fully verified drop-in replacement for every V5 function. Native login differs from V5 login MFA; original registration/profile/session workflows, every alert/scheduler/assistant function, full transaction UI behavior, account opening and mobile fidelity remain incomplete. Separate-host restoration and public hosting are unverified. These are listed in the coverage and test documents rather than hidden by screenshots.
