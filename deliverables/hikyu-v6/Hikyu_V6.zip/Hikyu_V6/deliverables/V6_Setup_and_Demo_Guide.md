# V6 Setup and Demo Guide

## Scope

This guide operates only on `/workspace/hikyu-v6`, created for this task. It does not use the older checkout or an old deployment. The user authorized an alternative LCNC platform; the implementation uses **Saltcorn 1.6.2 + Flowable 7.1.0 + a local supervised classifier**. It is a local self-hosted demonstrator, not a public URL. Do not purchase a plan or start a trial to follow this guide.

## Current prepared environment

Prerequisites already verified here: Node.js 24, Python 3, Java/JDK 21 (compiles the Java 17 target), managed Docker, and the isolated PostgreSQL 17 Compose project. Native LCNC dependencies and Maven dependencies are installed. Processes do not survive every environment reconnection and must be checked/restarted.

From `/workspace/hikyu-v6`, start the task-created database with:

```sh
docker compose -p hikyu-v6-independent -f implementation/compose.v6.yaml up -d --wait
python3 implementation/start-services.py
```

`start-services.py` starts/checks the workflow API, native LCNC server and reconciliation worker. It uses private configuration, independent process sessions and health requests. Runtime service addresses are loopback ports **8096** (workflow API) and **8097** (LCNC). These are local diagnostic addresses, not published hosting links. The native LCNC login route is `/auth/login`; the application overview route is `/page/overview`.

The prepared JDK executable was freshly verified at `/workspace/hikyu-setup/jdk`; no previous application setup script or database configuration is loaded. On another machine, use an independently installed JDK 17+ and adapt the launcher path. Keep TLS verification and the environment's CA trust enabled.

## Private configuration names

No secret values are included in this guide or the submission bundle.

| File/configuration | Names/purpose |
|---|---|
| `private/saltcorn-env.json` | `PGHOST`, `PGPORT`, `PGDATABASE`, `PGUSER`, `PGPASSWORD`, `SALTCORN_SESSION_SECRET`, `SALTCORN_JWT_SECRET`, `SALTCORN_FILE_STORE`, `SALTCORN_NWORKERS`, isolated XDG paths |
| `private/saltcorn-accounts.json` | Generated local role accounts; never submit or publicly share this file |
| `private/saltcorn-pins.json` | Generated synthetic card PINs used only for this task's bank simulation; excluded from export |
| `private/roles.json` | Server-side workflow identity/role/token bindings; never send to a browser |
| `V6_ROOT` | Root directory for the workflow runtime; default is the task directory |
| `V6_TOKENS_PATH` | Trusted server-side role-binding file path |
| `V6_AI_SCRIPT` | Optional trusted classifier executable path; default is the real local classifier. Used temporarily for fault testing only |
| `V6_REVIEW_TIMEOUT` | Reviewer SLA; default `PT24H`. `PT2S` is used only by the explicit accelerated test |
| Maven settings | `implementation/maven-settings.xml` uses the inherited managed proxy; Java uses `/etc/ssl/certs/java/cacerts` |

The sanitized submission's Compose file expects `V6_DB_PASSWORD` to be supplied securely. The live environment's local synthetic database configuration is excluded from the bundle. Do not point this Compose project at any existing banking database or volume.

## Accounts and roles

All current accounts were generated during this task. Logical roles are Builder, Requester, Other Requester, Service Agent, Reviewer and Supervisor. Application roles are resolved on the server using native user IDs, not user-supplied role labels. Separate browser contexts were used in tests. One operator switching accounts is **role simulation**, not actual multi-person participation.

Use the local secure credential store/editor for the generated demo accounts. Do not paste passwords, PINs or tokens into chat, reports or screenshots. To create an additional builder safely, the native CLI can prompt for a new password:

```sh
node implementation/saltcorn/run.cjs create-user --admin --email YOUR_NEW_LOCAL_BUILDER_EMAIL
```

For future real participants, create separate native accounts, assign only their intended application role, bind their native IDs to server-side workflow identities and reload the workflow service. No real participant invitations or emails were sent by the agent. The generated test accounts are not evidence of real people participating.

## Demonstrate the LCNC core

1. Sign in as Requester. Open Overview: account cards show persisted USD balances, not hard-coded display values.
2. Open Pay & Transfer. Between my accounts performs an own-account transfer; review requests a six-digit simulated SMS/email code. Enter the displayed code and confirm. This workflow does not need the card PIN. No real SMS/email is sent.
3. For peer payment, purchase, bill payment or credit repayment, supply the task's generated permanent PIN and simulated code. The confirmation screen does not echo the PIN.
4. Test a locked debit card: Accounts & Cards can lock/unlock; the purchase action rejects a locked card. Transfers and repayment follow their own account rules.
5. Save a synthetic biller using code `electric`, `internet`, `water` or `rent` and a synthetic reference. Complete a mock bill payment.
6. Save a budget in Financial Insights. Expense/peer-transfer spending is counted; internal transfer and credit-payment kinds are excluded.
7. Transactions provides basic owned history and a CSV statement form with inclusive dates, a 367-day range limit, a 10,000-record limit and formula-text protection.
8. Refresh: balances, history, cards, budgets, recipients and support state are database-backed.

This is a selected functional reconstruction. The full source login MFA, original assistant, scheduled alerts, registration/security/session workflows and full transaction UI parity remain incomplete; see the report and test results.

## Demonstrate the AI human workflow

1. As Requester, open Support Requests, select an owned synthetic transaction and submit “My card is locked and purchases are blocked”. The server creates the LCNC business record before contacting the engine.
2. Observe `SERVICE_REVIEW`, the real process instance ID, local model category and state version on that record. AI categorization is advisory.
3. In an independent Service Agent session, open the same page. Add a processing comment and choose Send to reviewer. Alternatively choose Return for information or Reject.
4. In Reviewer, independently review and complete or reject. The engine checks the active task, actor and expected version.
5. Return to Requester and refresh. Confirm the same business ID/row now holds the final state and comment.
6. For a return, the Requester supplies revised information. Classification runs again and the task returns to service review.
7. Normally a reviewer task expires after 24 hours and routes to Supervisor. The dedicated test uses a two-second SLA and a real timer; do not describe it as a 24-hour observation.

## Re-run meaningful checks

Run from the prepared environment; tests create additional synthetic data. Do not point them at another database. Preserve each command's exit code.

```sh
node implementation/saltcorn/test_e2e.cjs
node implementation/saltcorn/test_resilience.cjs
node implementation/saltcorn/test_banking.cjs
node implementation/saltcorn/test_csv.cjs
python3 implementation/test_ai_faults.py
python3 implementation/test_sla.py
```

The financial suite exercises a ten-codes-per-ten-minutes limit; repeated immediate runs may correctly hit rate limiting. Use a fresh dedicated synthetic fixture/user or wait for the actual window; do not disable the limit to manufacture a pass. The fault suites stop/restart only the task's workflow service, restore the normal classifier/default SLA and remove their temporary database constraint. They are controlled fault-injection tests, not reports of natural provider failures.

The local classifier can be rebuilt without provider credentials:

```sh
python3 implementation/ai/local_classifier.py --train
```

This overwrites only the task's synthetic local model. Six small holdout successes do not establish production accuracy.

## Export and reproduction

`deliverables/Saltcorn_V6_Application_Pack.json` is a real native configuration pack. It contains table/field/view/page/plugin definitions, not passwords or business rows. The local plugin source and its integration/service code must be installed alongside the pack; the BPMN needs its Java delegates/listeners and the local model.

For a separate new installation, install the pinned Saltcorn CLI, configure a new database and private secrets, initialize with `add-schema -f`, install the local plugin using `install-plugin --directory`, then use the native `install-pack --file` command. The included pack is not a standalone web ZIP and does not create account passwords. Separate-installation restoration has **not** been tested; do not report an export check as a restore pass.

## Troubleshooting and limitations

Inspect private runtime logs locally; do not upload them without checking for secrets. `evidence/` contains selected safe test outputs and real screenshots. A pending integration error means a durable row exists and the reconciliation worker will retry; it does not mean the process completed. After a reconnect, start services and verify readiness before repeating a test.

Budibase could not fit the managed Docker vfs storage and is not the deployed application. Saltcorn runs without those large service images. Public HTTPS, production authentication, multiple application instances, complete V5 parity, and real-person acceptance remain separate work. No environment publication is necessary for viewing the current local results, and the agent did not publish an environment version.
