# Requirements Coverage

Status terms: Pass, Fail, Blocked, Not tested. “Partial” below means the requirement is not fully complete even though identified subchecks passed.

| Assignment requirement | Implementation location | Verification evidence | Completion status |
|---|---|---|---|
| Use only this task's V5 and newly verified information | `baseline/`, isolated working copy and new databases | `source.json`, `baseline-integrity.json` | Pass |
| Preserve original files and avoid old deployments | Original 651 files unchanged; no private environment configuration loaded | `baseline-integrity.json`, isolated Compose/project names | Pass |
| English application and submission materials | Native page/view definitions and English reports | Platform screenshots and deliverables | Pass for implemented content |
| Choose an editable LCNC platform with UI/data/logic | Saltcorn 1.6.2 native editor, PostgreSQL definitions and view/action extensions | Native editor screenshots, package/license records, bootstrap metadata | Pass; user authorized replacing Bubble |
| Verify current Bubble plan and live deployment | Not used after user-authorized switch | Proxy 403 retrieval evidence and decision record | Blocked / superseded, not misrepresented |
| Free-plan/cost distinction; no purchase/trial | MIT Saltcorn, Apache Flowable, CPU-only local model | Official source snapshots; actual local install | Pass for self-hosted software; no free permanent hosting claim |
| V5 UI/data/logic reconstruction | Native eight-page application, data types, money/code/payment actions | 14 banking checks, five CSV checks and real screenshots | Partial; full V5 parity remains incomplete |
| Explicit original/native ID mapping | Separate `source_v5_id`, native integer IDs, business IDs and process IDs | Native metadata, schema export and E2E correlation | Pass for implemented synthetic mapping; real migration Not tested |
| Ownership/role permissions and negative tests | Native ownership and field permissions; server action checks | E2E, resilience and banking/CSV negative checks | Pass for tested paths; complete original authentication parity incomplete |
| Compare at least two iBPM candidates using official sources | Flowable/n8n comparison | Pinned official repository documentation | Pass; exact commercial pricing not invented |
| Select after checking the LCNC→workflow→AI→writeback chain | Actual Saltcorn and Flowable local implementation | `lcnc-e2e.json` | Pass |
| Multiple participant tasks and actual handoff | Requester, service agent, independent reviewer, supervisor | Task history, role browser contexts, handoff screenshots | Pass as role simulation; real different people Not tested |
| Trigger, assignment, AI, human decision, branches and return/reject | Executable BPMN and authenticated wrapper | Engine tests, nominal E2E and resilience return/reject | Pass |
| Consistent states and persistent correlation/comments/timestamps | `support_requests` and engine variables/history | Refresh/restart evidence and real request card | Pass |
| Exception and human timeout path | Error boundary, timer boundary, reconciliation worker | Three AI fault tests; actual accelerated timer test | Pass for controlled fault mechanisms |
| Real business-runtime AI | Trained local Naive Bayes subprocess invoked by service task | Real AI input/output files and E2E model projection | Pass; not an LLM or mock success |
| Check model output; no automatic high-impact decision | Fixed labels/schema/confidence/model metadata; human always required | Malformed-output fault test and human task path | Pass for tested boundary |
| AI costs/permissions and privacy/governance | No external model account; synthetic descriptions only | Local model/data/code and report | Pass for local demonstration |
| Integration authentication and protected credentials | Native session/CSRF; private server-side role tokens | Anonymous/role/ownership denials; sanitized export | Pass for local tested paths; public TLS Not tested |
| Duplicate clicks, retries, stale updates | Stable business/request key, DB uniqueness, task versions, final-state guard | E2E duplicates, resilience, financial replay tests | Pass for tested local cases; multi-instance load Not tested |
| Durable status writeback and recovery | Same LCNC row, monotonic projection, retry worker | Actual stopped API and failed DB callback recovery | Pass |
| Required input/illegal data validation | Financial/support API validation | Blank/amount/date/ownership tests | Pass for covered cases; exhaustive fuzzing Not tested |
| Real multi-person participation | Not performed | Explicit role-simulation labels | Not tested; requires independent participants |
| 100–200-word English reflection | `V6_Reflection.md`; Word report appendix | Automated word-count record | Pass |
| Full English report, test results and guide | Required Markdown files and Word report | Document/artifact validation manifest | Pass for actual-results documentation |
| Screenshots as evidence | Real native editor, data editor, submitted/reviewer/final records and banking views | PNGs with evidence references in Word | Pass; not fabricated screenshots |
| Combine V5 and updates into V6 ZIP | V6 root manifest, V5 source/reference and added implementation | Archive manifest, secret scan and source provenance | Delivered; fresh-machine restoration separately noted |
| Original registration/security/session/assistant/scheduler/full filtering/mobile parity | Not fully implemented | Explicit report and test-results gaps | Not tested / incomplete |
