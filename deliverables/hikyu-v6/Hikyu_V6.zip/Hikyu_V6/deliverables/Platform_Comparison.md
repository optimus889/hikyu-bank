# Platform research and decision record

Research date: 3 November 2026 (America/New_York). Source snapshots are under `research/`. Treat unavailable pages as unverified, not as evidence of current pricing.

## LCNC requirement change

The original request fixed Bubble as the LCNC platform. During this task, the user explicitly authorized another editable LCNC platform. Budibase was evaluated and failed to deploy within the managed vfs storage limit. The final target is self-hosted Saltcorn 1.6.2, successfully installed and tested. No claim is made that the supplied Bubble project was edited, previewed or deployed. Bubble pricing and manual requests returned HTTP 403 at the environment proxy. Its exact current free plan, backend workflow/API allowances and live-deployment price remain unverified. A preview must never be reported as a live deployment. No Bubble upgrade, trial or purchase occurred.

Budibase's current official repository describes Apps, Automations, external data integration, native data and self-hosting. Its root license says licensing is package-specific and Budibase can be considered GPLv3 overall; generated applications do not package GPLv3 code. This is not a promise that every commercial module is free. No paid license key or external AI provider was enabled during that failed evaluation. Budibase feature entitlements were not certified because its application container could not be created.

The all-in-one image was abandoned because the managed Docker daemon uses vfs and image-layer copies consumed excessive disk. The official multi-container attempt also exhausted disk during application-container creation; its task-created unused resources were removed. It is not the delivered deployment. The repository version tag did not exist for every Docker image; use actual image digests rather than equating source tags with container tags. Native LiteLLM is a deployment dependency, not the assignment's AI implementation, and no provider is configured there.

## iBPM candidates

| Criterion | Flowable Open Source 7.1.0 | n8n Community self-hosted |
|---|---|---|
| License and duration | Official repository: Apache 2.0 open-source engine, no time-limited engine trial | Official current docs: free Community indefinitely, optional free registration; Community/Sustainable Use license, not unrestricted Apache-style OSS |
| Human task assignment | BPMN user tasks, assignees/candidate groups; actually executed in this task | AI tool human-review pause and approve/deny are documented. A complete role-scoped business task inbox still needs design and testing |
| Process modeling | Executable BPMN; Java/REST integration | Visual automation nodes and waits; not inherently BPMN |
| Automatic routing | Gateways/service tasks; actual continue/return/reject paths tested | Conditions, wait and automation orchestration documented; not installed in this task |
| State tracking | Durable engine execution/task/history; local file database restart tested | Execution persistence/wait resumption; executions alone are not the business source of truth |
| Audit and governance | Engine history is available; authentication and business authorization must be enforced at the integration boundary | Logging included; log streaming, projects, workflow/credential sharing, SSO and Git version control excluded from Community according to current docs |
| Exceptions/timeouts | BPMN error boundary and interrupting timer; failure-to-human and timer execution tested locally | Error handling and Wait node exist; full task timeout/reassignment policies must be implemented |
| AI functionality | This implementation adds a real supervised local classifier as a BPMN service delegate; not a built-in generative AI entitlement | Built-in AI nodes and HITL tools documented; external providers may cost money, local models require infrastructure |
| LCNC integration | Authenticated service API; submit business ID, return process ID; server-side status projection and writeback required | Webhook + HTTP request/API integration; secret storage and role authorization still required |
| Multi-actor limitation | Engine API does not automatically enforce all candidate-group permissions. This task's local wrapper checks roles and record ownership; LCNC identity binding was tested through separate generated native role accounts | Community users cannot freely share workflows/credentials. Do not confuse a resumable webhook with a secure multi-user approval portal |
| Actual evidence | 6 real engine tests; 9 real HTTP tests; live LCNC handoff/writeback, resilience, AI faults and actual timer escalation; real model evidence | Official-source comparison only; no execution or E2E claim |
| Hosting/AI cost | Engine license has no fee; hosting/operations remain a cost. Small local classifier uses existing task CPU, no API charges | Software can be free under its license; hosting/operations and any external model remain additional costs |

**Validated selection:** Flowable with the real local classifier was selected after the Saltcorn submission → AI → service-agent/reviewer handoff → same-row writeback chain actually passed. Nominal and recovery evidence is in the test results. No completely free permanent public hosted combination has been established. Self-hosted software and this task's provisioned compute must not be described as free permanent public hosting. No school license or time-limited cloud trial is assumed.

## Official sources inspected

1. Flowable README: https://github.com/flowable/flowable-engine/blob/main/README.md — retrieved successfully; `research/flowable-readme.md`.
2. Flowable license: https://github.com/flowable/flowable-engine/blob/main/LICENSE — retrieved successfully; `research/flowable-license.md`.
3. n8n edition comparison: https://github.com/n8n-io/n8n-docs/blob/master/docs/deploy/host-n8n/community-edition-features.md — inspected at the exact commit in `research/n8n-docs-commit.txt`; snapshot `research/community-edition-features.md`.
4. n8n human review: https://github.com/n8n-io/n8n-docs/blob/master/docs/build/integrate-ai/ai-examples/human-in-the-loop-for-tools.md — same pinned official repository; snapshot `research/human-in-the-loop-for-tools.md`.
5. n8n license FAQ: https://github.com/n8n-io/n8n-docs/blob/master/docs/n8n-community-license/license-faq.md — snapshot `research/license-faq.md`.
6. n8n Wait node: https://github.com/n8n-io/n8n-docs/blob/master/docs/integrations/builtin/core-nodes/n8n-nodes-base.wait.md — snapshot retained.
7. Budibase README, license and official deployment: https://github.com/Budibase/budibase — commit in `research/budibase-commit.txt`; snapshots `budibase-readme.md`, `budibase-license.txt`, `budibase-compose.yaml`, `budibase-single.md`.
8. Bubble pricing https://bubble.io/pricing and API guide https://manual.bubble.io/help-guides/integrations/api — access blocked on research date; see `research/retrieval.json`. These are outstanding verification sources, not successfully inspected pricing evidence.

Earlier guessed n8n documentation paths returned 404. The successful current paths were discovered from the official repository tree, and only those successful snapshots support the comparison. Pricing pages remain the authority for exact commercial feature entitlements.

## Final LCNC selection: Saltcorn 1.6.2

The official repository describes a no-code database application builder with views, datatypes, layouts and actions, with Node/PostgreSQL self-hosting. The inspected license is MIT. The installed version and npm integrity/repository metadata are retained in `research/saltcorn-package.json`; dependency versions are locked. The actual native editor, sixteen native table definitions (including the platform user table), sixteen views and eight pages were exported. Real LCNC–Flowable–model integration passed. This verifies the selected local feature set, not every possible plugin or a guaranteed free cloud service.

Official sources inspected on 3 November 2026: https://github.com/saltcorn/saltcorn/blob/master/README.md and https://github.com/saltcorn/saltcorn/blob/master/LICENSE (`research/saltcorn-readme.md`, `saltcorn-license.txt`), plus https://www.npmjs.com/package/@saltcorn/cli metadata retrieved through the npm registry. The README distinguishes its free exploration host (no availability/security guarantees) from separately paid hosting. No exploration host or paid host was used.
