# Reflection

Rebuilding Hikyu Bank showed that low-code tooling can make data and workflow structure easier to inspect, but it does not automatically preserve banking safeguards. Native pages and owned records were useful foundations. Exact money handling, authorization-code binding and durable state synchronization still required explicit code and tests.

The local classifier added a visible category during each support request, giving reviewers a starting point without deciding the outcome. This demonstrated runtime AI integration, but the small synthetic training set cannot justify claims about production accuracy or measured efficiency gains. High confidence from this model should not be confused with reliable financial judgment.

Automation also moved responsibility into less visible components. Duplicate handling, failed callbacks and overdue tasks needed durable records and recovery paths. Human review, minimal model input and separate role checks helped limit harm, while real fault tests made those safeguards observable. I would retain these controls even if they make the process slower, and complete authentication parity and independent participant testing before extending the demonstration.
