from pathlib import Path
import re,json
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from PIL import Image
ROOT=Path('/workspace/hikyu-v6');OUT=ROOT/'output';OUT.mkdir(exist_ok=True)
doc=Document();sec=doc.sections[0];sec.top_margin=Inches(.7);sec.bottom_margin=Inches(.65);sec.left_margin=sec.right_margin=Inches(.75)
normal=doc.styles['Normal'];normal.font.name='Calibri';normal.font.size=Pt(10.5);normal.paragraph_format.space_after=Pt(6)
for name in ['Title','Heading 1','Heading 2','Heading 3']:
 doc.styles[name].font.name='Calibri';doc.styles[name].font.color.rgb=RGBColor.from_string('0B2C50')
sec.header.paragraphs[0].text='HIKYU BANK V6  |  LCNC + AI iBPM'
sec.header.paragraphs[0].style=doc.styles['Caption']
f=sec.footer.paragraphs[0];f.alignment=2;f.add_run('Coursework demonstrator · 3 November 2026 · Page ')
fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');f._p.append(fld)
def inline(p,text):
 for part in re.split(r'(\*\*.*?\*\*|`[^`]+`|\[[^\]]+\]\([^)]+\))',text):
  if not part:continue
  if part.startswith('**'):
   r=p.add_run(part[2:-2]);r.bold=True
  elif part.startswith('`'):
   r=p.add_run(part[1:-1]);r.font.name='Consolas';r.font.size=Pt(9)
  elif re.match(r'^\[[^\]]+\]\(',part):
   m=re.match(r'\[([^\]]+)\]\(([^)]+)\)',part);p.add_run(m.group(1)+' ('+m.group(2)+')')
  else:p.add_run(part)
def table(lines):
 rows=[[x.strip() for x in line.strip().strip('|').split('|')] for line in lines if not re.match(r'^\s*\|[\s:|\-]+\|\s*$',line)]
 if not rows:return
 n=max(map(len,rows));t=doc.add_table(rows=0,cols=n);t.style='Light Shading Accent 1'
 for i,row in enumerate(rows):
  cells=t.add_row().cells
  for j,value in enumerate(row):
   p=cells[j].paragraphs[0];inline(p,value)
   for run in p.runs:run.font.size=Pt(9)
   if i==0:
    for run in p.runs:run.bold=True
  if i==0:
   trPr=t.rows[-1]._tr.get_or_add_trPr();repeat=OxmlElement('w:tblHeader');repeat.set(qn('w:val'),'true');trPr.append(repeat)
 doc.add_paragraph()
def picture(name,caption):
 p=ROOT/'evidence'/name
 if not p.exists():raise RuntimeError('Missing real screenshot '+name)
 w,h=Image.open(p).size;width=6.65;height=width*h/w
 if height>7.7:width=7.7*w/h
 doc.add_picture(str(p),width=Inches(width));doc.add_paragraph(caption,'Caption')
def md(text):
 lines=text.splitlines();i=0
 while i<len(lines):
  line=lines[i]
  if line.startswith('```'):
   lang=line[3:];code=[];i+=1
   while i<len(lines) and not lines[i].startswith('```'):code.append(lines[i]);i+=1
   if lang=='mermaid':
    p=doc.add_paragraph();inline(p,'Process/architecture diagram: see the Markdown report for the editable Mermaid definition. Main flow: requester → runtime AI → service agent → independent reviewer → persisted LCNC outcome; exceptions route to manual triage or supervisor.')
   else:
    for x in code:
     p=doc.add_paragraph();r=p.add_run(x);r.font.name='Consolas';r.font.size=Pt(8.5)
  elif line.startswith('|'):
   group=[]
   while i<len(lines) and lines[i].startswith('|'):group.append(lines[i]);i+=1
   table(group);continue
  elif line.startswith('#'):
   level=len(line)-len(line.lstrip('#'));doc.add_heading(line[level:].strip(),min(level,3))
  elif line.startswith('- '):inline(doc.add_paragraph(style='List Bullet'),line[2:])
  elif line.strip():inline(doc.add_paragraph(),line.strip())
  i+=1
# Cover: no claim of full parity or actual people participating.
doc.add_heading('Hikyu Bank V6',0);doc.add_paragraph('LCNC + AI iBPM Assignment Report','Subtitle');doc.add_paragraph('Saltcorn 1.6.2 • Flowable 7.1.0 • Real local supervised classification')
doc.add_paragraph('Prepared from the V5 archive supplied in this task. Evidence date: 3 November 2026.')
p=doc.add_paragraph();r=p.add_run('Validated local functional demonstrator. Human workflow tests use separate accounts operated by one person. Full V5 equivalence, real-person acceptance and public hosting are not claimed.');r.bold=True
summary=[['Verified scope','Actual evidence'],['Uploaded V5 baseline','93 backend tests, five frontend test-file executions, 14 startup tests; new-account browser smoke'],['Live V6 human workflow','8 LCNC E2E checks + 10 resilience/security checks'],['Native banking reconstruction','14 live banking checks + 5 protected CSV checks'],['AI and task failures','3 controlled AI-fault E2E checks + actual accelerated human-task timer escalation'],['Artifacts','Native LCNC application pack, executable BPMN, source, safe evidence and setup guide']]
table(['| '+' | '.join(r)+' |' for r in summary]);doc.add_paragraph('The short reflection is a separate 166-word appendix. The full report is intentionally longer than 200 words.')
doc.add_page_break();md((ROOT/'deliverables/V6_Assignment_Report.md').read_text())
doc.add_page_break();doc.add_heading('Appendix A — Actual Platform and Test Evidence',1);doc.add_paragraph('All figures below are direct screenshots of the installed platform or its persisted application records. They were captured during this task. Screenshots illustrate specific observations; the accompanying logs/JSON contain the actual test assertions. No account password, PIN or workflow token is shown.')
picture('lcnc-native-page-editor.png','Figure 1. Actual Saltcorn native page editor: eight V6 pages and role-based home-page configuration. This is a configuration/editability observation, not an E2E pass by itself.')
doc.add_page_break();picture('lcnc-native-data-editor.png','Figure 2. Actual native data editor: domain tables with ownership, plus the platform user table. Financial/workflow write protection is additionally verified by negative tests.')
doc.add_page_break();picture('lcnc-banking-overview.png','Figure 3. Real LCNC account cards and owned database-backed values after financial scenario checks. Evidence: lcnc-banking-tests.json. All values are synthetic.')
doc.add_page_break();e2e=json.loads((ROOT/'evidence/lcnc-e2e.json').read_text());bid=e2e['business_id'];doc.add_paragraph('The following three figures concern the same actual business record: '+bid+'. The different sessions are role simulation, not different people.')
picture('lcnc-request-submitted-card.png','Figure 4. Persisted submission after the real local classifier ran: category, confidence, model version, service-review stage and engine instance are visible.')
picture('lcnc-reviewer-handoff-card.png','Figure 5. Same record handed from service agent to independent reviewer. A reviewer decision/comment is required; AI does not approve.')
picture('lcnc-completed-refresh-card.png','Figure 6. Same record after reviewer completion and requester refresh: COMPLETED, a later version, persisted processing comment and the same process instance.')
doc.add_page_break();doc.add_heading('Appendix B — Test Results and Boundaries',1)
for title,file in [('Live LCNC E2E','lcnc-e2e.json'),('Recovery/security','lcnc-resilience.json'),('Native banking','lcnc-banking-tests.json'),('CSV','lcnc-csv-tests.json')]:
 d=json.loads((ROOT/'evidence'/file).read_text());doc.add_heading(title,2)
 table(['| Scenario | Actual result |','|---|---|']+['| '+x['test']+' | '+x['status']+' |' for x in d['results']])
doc.add_paragraph('AI timeout, invalid output and subprocess failure were controlled fault injection through the live LCNC/engine path; all reached MANUAL_TRIAGE. The human-review timer was an actual expiry with a controlled PT2S test deadline; normal PT24H configuration was restored. These tests are not successful AI outputs or a 24-hour observation.')
doc.add_paragraph('Not fully implemented/verified: original V5 login MFA, full registration/profile/security/session workflows, original assistant and complete scheduled alerts, full transaction UI and mobile parity. Real different-person testing, public hosting and separate-install restoration remain unverified. See V6_Test_Results.md for the complete scope and evidence index.')
doc.add_heading('Appendix C — Reflection (166 words)',1);md((ROOT/'deliverables/V6_Reflection.md').read_text().split('\n\n',1)[1])
doc.add_heading('Appendix D — Delivery and Setup',1);doc.add_paragraph('The V6 ZIP combines the clean V5 source baseline and all new LCNC/workflow/model/test source, documentation, native application export and actual evidence. Start with README.md and V6_Setup_and_Demo_Guide.md. Private configuration, secrets, databases, dependency folders and old compiled outputs are excluded. The report is not a claim of a public deployment.')
doc.save(OUT/'V6_Assignment_Report.docx');print('Created',OUT/'V6_Assignment_Report.docx')
