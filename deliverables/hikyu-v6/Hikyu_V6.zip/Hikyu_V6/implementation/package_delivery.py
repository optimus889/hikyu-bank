from pathlib import Path
import zipfile,json,hashlib,re,datetime,shutil
from lxml import etree
from docx import Document
ROOT=Path('/workspace/hikyu-v6');OUT=ROOT/'output';OUT.mkdir(exist_ok=True);PREFIX='Hikyu-Bank-Project-V6/'
# Inspect the actual Word package and embedded screenshot count.
word=OUT/'V6_Assignment_Report.docx';d=Document(word)
with zipfile.ZipFile(word) as z:
 assert z.testzip() is None
 for name in z.namelist():
  if name.endswith('.xml'):etree.fromstring(z.read(name))
 media=[n for n in z.namelist() if n.startswith('word/media/')];assert len(media)>=6
assert any('COMPLETED' in p.text for p in d.paragraphs)
items={}; exclusions=[]
def add(path,rel=None,data=None):items[rel or str(path.relative_to(ROOT))]=data if data is not None else path.read_bytes()
def ignore(p):
 if any(x in p.parts for x in ['node_modules','target','__pycache__','.git','private','baseline','attachments','downloads']):return True
 if p.name.startswith('.env') or p.name in ['.DS_Store','classpath.txt','maven-settings.xml']:return True
 if p.suffix in ['.pyc','.class','.jar','.war','.mv.db','.trace.db','.dump','.backup']:return True
 return False
for base in ['implementation','deliverables','evidence']:
 for p in (ROOT/base).rglob('*'):
  if not p.is_file():continue
  if ignore(p):exclusions.append(str(p.relative_to(ROOT)));continue
  if base=='implementation' and 'budibase' in p.parts:continue
  if p.name in ['diagnose-support.cjs','ai-runtime-4.json']:continue
  data=p.read_bytes()
  if p.relative_to(ROOT).as_posix()=='implementation/compose.v6.yaml':
   text=data.decode();text=re.sub(r'POSTGRES_PASSWORD:.*','POSTGRES_PASSWORD: ${V6_DB_PASSWORD:?Set a private V6_DB_PASSWORD}',text);text=text.replace('127.0.0.1:55436:5432','127.0.0.1:${V6_DB_PORT:-55436}:5432');data=text.encode()
  add(p,data=data)
# Official documentation snapshots, not Git checkouts or unused fetched implementation source.
research_keep=['source.json','retrieval.json','github-retrieval.json','official-github.json','flowable-readme.md','flowable-license.md','community-edition-features.md','license-faq.md','human-in-the-loop-for-tools.md','n8n-nodes-base.wait.md','n8n-docs-commit.txt','saltcorn-readme.md','saltcorn-license.txt','saltcorn-package.json','budibase-readme.md','budibase-license.txt','budibase-single.md','budibase-commit.txt']
for name in research_keep:
 p=ROOT/'research'/name
 if p.is_file():add(p)
add(ROOT/'README_V6.md','README.md');add(word,'deliverables/V6_Assignment_Report.docx')
items['VERSION']=b'6.0.0-local-coursework\n'
items['V6_Project.json']=json.dumps({'version':'V6','basis':'User-uploaded V5 source supplied in this task','lcnc':'Saltcorn 1.6.2','ibpm':'Flowable 7.1.0','ai':'Real local supervised multinomial Naive Bayes classifier','deployment':'Local self-hosted, not public hosting','participants':'Single-person role simulation','full_v5_parity':False,'private_configuration_included':False,'primary_setup':'python3 implementation/prepare_v6.py','current_runtime_start':'python3 implementation/start-services.py'},indent=2).encode()
# Scan for the actual generated strong private credentials, not merely the word "token" in source.
secrets=[];private=ROOT/'private'
for name,field in [('saltcorn-accounts.json','password'),('roles.json','token')]:
 if (private/name).exists():secrets += [x[field] for x in json.loads((private/name).read_text()) if x.get(field)]
if (private/'saltcorn-env.json').exists():
 cfg=json.loads((private/'saltcorn-env.json').read_text());secrets += [v for k,v in cfg.items() if any(x in k for x in ['PASSWORD','SECRET'])]
hits=[]
for rel,data in items.items():
 for value in secrets:
  if len(str(value))>=12 and str(value).encode() in data:hits.append(rel);break
assert not hits, 'Private credential value found in: '+str(hits)
assert not any('/node_modules/' in x or '/target/' in x or '/private/' in x for x in items)
assert any(x.startswith('implementation/v5-working/backend/src/main/') for x in items)
assert any(x.startswith('implementation/v5-working/frontend/') for x in items)
manifest={'version':'V6','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'contents':'Uploaded V5 clean source + V6 LCNC/workflow/model implementation + Word/Markdown reports + real evidence','private_directories_excluded':True,'generated_private_credential_scan':'Pass: known generated strong password/token values absent','dependencies_and_old_outputs_excluded':True,'embedded_word_screenshots':len(media),'files':[{'path':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for rel,data in sorted(items.items())]}
items['V6_Delivery_Manifest.json']=json.dumps(manifest,indent=2).encode()
archive=OUT/'Hikyu-Bank-Project-V6.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for rel,data in sorted(items.items()):z.writestr(PREFIX+rel,data)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
quality={'word_file':word.name,'word_bytes':word.stat().st_size,'embedded_real_screenshots':len(media),'word_xml_validation':'Pass','zip_file':archive.name,'zip_bytes':archive.stat().st_size,'zip_members':len(items),'zip_integrity':'Pass','known_private_credential_scan':'Pass','contains_v5_source':True,'contains_new_v6_source':True,'fresh_installation_of_packaged_setup':'Not tested; current-instance components and setup --check verified'}
(ROOT/'evidence/delivery-validation.json').write_text(json.dumps(quality,indent=2));(OUT/'V6_Delivery_Manifest.json').write_text(json.dumps(manifest,indent=2));print(json.dumps(quality,indent=2))
